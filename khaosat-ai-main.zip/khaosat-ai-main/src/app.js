// Router API (Cloudflare Pages Functions).
// Vai tro: Khach (chua dang nhap) | Nguoi dung | HR (tao hop thu gop y) | Admin. Vai tro luu o cot users.role.
import { HttpError, json, readJson, now, randomHex, sha256, vnDay } from "./http.js";
import { ensureSchema } from "./db.js";
import { hashPassword, verifyPassword, DUMMY_HASH, normEmail, USERNAME_RE, usernameEmail, createSession, sessionCookie,
  currentUser, requireUser, requireAdmin, ipKey, countHits, addHit, limit } from "./auth.js";
import { TOPICS, CHOICE_TYPES, NUMERIC_TYPES, searchNorm, validateMeta, assertPublishable, cleanAnswers } from "./questions.js";
import { config, listModels, LLMError, WaitSignal } from "./llm.js";
import { suggestQuestions, computeStats, analyzeOpenText, summarize } from "./survey.js";
import { TEMPLATES } from "./templates.js";
import { googleEnabled, googleStart, googleCallback, redirect } from "./google.js";
import { handleFeedback } from "./feedback.js";

const DEFAULT_QUOTA = { gen: 10, ana: 5 };
const PAGE_SIZE = 20;

// ------------------------------------------------------------ khao sat ----
async function loadSurvey(db, id) {
  if (!/^[a-f0-9]{10}$/.test(id || "")) return null;
  const s = await db.prepare(
    `SELECT s.*, u.name AS owner_name, u.locked AS owner_locked FROM surveys s JOIN users u ON u.id = s.owner_id WHERE s.id = ?`)
    .bind(id).first();
  if (!s) return null;
  s.questions = JSON.parse(s.questions);
  s.anonymous = !!s.anonymous;
  s.hidden = !!s.hidden;
  return s;
}

async function mustLoad(db, id) {
  const s = await loadSurvey(db, id);
  if (!s) throw new HttpError(404, "Không tìm thấy khảo sát.");
  return s;
}

const isOwner = (u, s) => !!u && u.id === s.owner_id;
const canManage = (u, s) => isOwner(u, s) || !!u?.is_admin;

function assertOwner(u, s) {
  if (!isOwner(u, s)) throw new HttpError(403, "Chỉ người tạo khảo sát mới được làm việc này.");
}
function assertManage(u, s) {
  if (!canManage(u, s)) throw new HttpError(403, "Bạn không có quyền với khảo sát này.");
}

const topicLabel = (t) => TOPICS[t] || TOPICS.khac;

async function getResponses(db, id) {
  const { results } = await db.prepare("SELECT answers FROM responses WHERE survey_id = ? ORDER BY id").bind(id).all();
  return results.map(r => JSON.parse(r.answers));
}

// Han chot: khao sat da qua closes_at -> chuyen sang "da dong" (lam luoi, khi co request lien quan; khong can tac vu dinh ky)
const closeExpired = (db) => db.prepare(`UPDATE surveys SET status = 'closed', closed_at = closes_at, updated = ?
  WHERE status = 'published' AND closes_at IS NOT NULL AND closes_at <= ?`).bind(now(), now()).run();
const MAX_DEADLINE_DAYS = 366;
function parseDeadline(v) {
  if (v === null || v === undefined || v === "") return null;
  const t = Math.floor(Number(v));
  if (!Number.isFinite(t) || t < now() + 60) throw new HttpError(400, "Hạn chót phải là một thời điểm trong tương lai.");
  if (t > now() + MAX_DEADLINE_DAYS * 86400) throw new HttpError(400, "Hạn chót tối đa 1 năm kể từ hôm nay.");
  return t;
}

const countResponses = async (db, id) =>
  (await db.prepare("SELECT COUNT(*) AS n FROM responses WHERE survey_id = ?").bind(id).first())?.n || 0;

// ------------------------------------------------------------- han muc ----
function quotaLimit(env, user, kind) {
  if (user.is_admin) return null; // khong gioi han
  const own = kind === "gen" ? user.quota_gen : user.quota_ana;
  if (own !== null && own !== undefined) return own;
  return parseInt(env[kind === "gen" ? "QUOTA_GEN" : "QUOTA_ANA"], 10) || DEFAULT_QUOTA[kind];
}

async function usageToday(db, userId) {
  const { results } = await db.prepare("SELECT kind, count, tokens FROM ai_usage WHERE user_id = ? AND day = ?").bind(userId, vnDay()).all();
  const out = { gen: { count: 0, tokens: 0 }, ana: { count: 0, tokens: 0 } };
  for (const r of results) out[r.kind] = { count: r.count, tokens: r.tokens };
  return out;
}

async function quotaInfo(db, env, user) {
  const u = await usageToday(db, user.id);
  return { gen: { used: u.gen.count, limit: quotaLimit(env, user, "gen") }, ana: { used: u.ana.count, limit: quotaLimit(env, user, "ana") } };
}

async function assertQuota(db, env, user, kind) {
  const q = (await quotaInfo(db, env, user))[kind];
  if (q.limit !== null && q.used >= q.limit) {
    throw new HttpError(429, kind === "gen"
      ? `Bạn đã dùng hết ${q.limit} lượt AI gợi ý câu hỏi hôm nay. Hãy thử lại vào ngày mai hoặc tạo câu hỏi thủ công.`
      : `Bạn đã dùng hết ${q.limit} lượt phân tích AI hôm nay. Hãy thử lại vào ngày mai.`);
  }
}

async function addUsage(db, userId, kind, count, tokens) {
  await db.prepare(`INSERT INTO ai_usage (user_id, day, kind, count, tokens) VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT (user_id, day, kind) DO UPDATE SET count = count + excluded.count, tokens = tokens + excluded.tokens`)
    .bind(userId, vnDay(), kind, count, tokens).run();
}

// Moi lan phan tich = 1 "run" (tinh 1 luot); cac buoc trong run bi gioi han so lan goi AI
async function checkRun(db, runId, s, user) {
  const run = await db.prepare("SELECT * FROM analysis_runs WHERE id = ?").bind(String(runId || "")).first();
  if (!run || run.survey_id !== s.id || run.user_id !== user.id || run.created < now() - 3600) {
    throw new HttpError(400, "Phiên phân tích không hợp lệ hoặc đã hết hạn. Hãy bấm phân tích lại.");
  }
  const maxSteps = s.questions.filter(q => q.type === "open_text").length * 2 + 3;
  if (run.steps >= maxSteps) throw new HttpError(429, "Phiên phân tích đã dùng quá số bước cho phép. Hãy bấm phân tích lại.");
  return run;
}

// Chay mot buoc AI trong run: chi tinh buoc khi thuc su goi AI (khong tinh khi phai cho gioi han)
async function runStep(db, run, user, fn) {
  await db.prepare("UPDATE analysis_runs SET steps = steps + 1 WHERE id = ?").bind(run.id).run();
  const usage = { tokens: 0, calls: 0 };
  try {
    const result = await fn(usage);
    await addUsage(db, user.id, "ana", 0, usage.tokens);
    return { result, usage };
  } catch (e) {
    if (e instanceof WaitSignal) await db.prepare("UPDATE analysis_runs SET steps = steps - 1 WHERE id = ?").bind(run.id).run();
    if (usage.tokens) await addUsage(db, user.id, "ana", 0, usage.tokens);
    throw e;
  }
}

// ---------------------------------------------------------- tien ich ----
const publicUser = (u, extra = {}) => (u ? { id: u.id, name: u.name, email: u.email, username: u.username, role: u.role,
  is_admin: u.is_admin, is_hr: u.is_hr, has_password: u.has_password, avatar: u.avatar || null, via: u.via, needs_terms: !u.terms_at, ...extra } : null);
// Chi chuyen huong ve duong dan noi bo (chong open redirect)
const safeNext = (n) => (typeof n === "string" && n.startsWith("/") && !n.startsWith("//") && !n.startsWith("/\\") ? n : "/dashboard");

function filterResponses(responses, questions, fq, fv) {
  const q = questions.find(q => q.id === fq);
  if (!q || fv === null || fv === undefined || fv === "") return responses;
  if (q.type === "multiple_choice") return responses.filter(r => Array.isArray(r[fq]) && r[fq].includes(fv));
  if (NUMERIC_TYPES.includes(q.type)) return responses.filter(r => r[fq] === Number(fv));
  return responses.filter(r => r[fq] === fv);
}

const csvCell = (v) => {
  const t = Array.isArray(v) ? v.join("; ") : String(v ?? "");
  return /[",\n\r]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t;
};
const fmtTime = (ts) => new Date((ts + 7 * 3600) * 1000).toISOString().replace("T", " ").slice(0, 19);

function likeTerms(q) {
  return searchNorm(q).split(" ").filter(Boolean).slice(0, 5).map(w => `%${w.replace(/[\\%_]/g, c => "\\" + c)}%`);
}

// -------------------------------------------------------------- routes ----
async function route(request, env) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  const method = request.method;
  const db = env.DB;
  if (!db) throw new HttpError(500, "Chưa gắn database D1 (binding DB).");
  await ensureSchema(db, Object.keys(TOPICS));
  if (/^\/api\/(search|public\/|my\/|surveys|admin\/)/.test(path)) await closeExpired(db);
  const cfg = config(env);
  const llm = { provider: cfg.defaultProvider, model: cfg.models[cfg.defaultProvider] };
  let m;

  // ======================= Tai khoan =======================
  if (path === "/api/me" && method === "GET") {
    const u = await currentUser(request, env);
    // Hop thu gop y: HR tao duoc; nguoi bi go quyen HR van quan ly duoc hop thu cu
    const boxes = u && !u.is_hr ? (await db.prepare("SELECT COUNT(*) AS n FROM fb_boxes WHERE owner_id = ?").bind(u.id).first()).n : 0;
    return json({ user: publicUser(u, u ? { can_feedback: u.is_hr || boxes > 0 } : {}), google: googleEnabled(env) });
  }

  // ---- Dang nhap Google ----
  if (path === "/api/auth/google/start" && method === "GET") {
    return googleStart(request, env, safeNext(url.searchParams.get("next")));
  }
  if (path === "/api/auth/google/callback" && method === "GET") {
    let g;
    try { g = await googleCallback(request, env); }
    catch (e) { if (e.oauth) return redirect(`/login?error=${e.oauth}`, { "Set-Cookie": e.clear }); throw e; }
    const { profile: p, clear } = g;
    let u = await db.prepare("SELECT id, locked, avatar, terms_at FROM users WHERE google_sub = ?").bind(p.sub).first();
    if (!u) {
      // Gmail da co tai khoan (dang ky bang mat khau) -> gop vao tai khoan cu
      u = await db.prepare("SELECT id, locked, avatar, terms_at, google_sub FROM users WHERE email = ?").bind(p.email).first();
      if (u && u.google_sub) return redirect("/login?error=linked", { "Set-Cookie": clear });
      if (u) {
        await db.prepare("UPDATE users SET google_sub = ?, avatar = COALESCE(avatar, ?) WHERE id = ?").bind(p.sub, p.picture, u.id).run();
      } else {
        const r = await db.prepare("INSERT INTO users (email, name, pass_hash, avatar, google_sub, created) VALUES (?, ?, '', ?, ?, ?)")
          .bind(p.email, p.name, p.picture, p.sub, now()).run();
        u = { id: r.meta.last_row_id, locked: 0, terms_at: null };
      }
    } else if (p.picture && p.picture !== u.avatar) {
      await db.prepare("UPDATE users SET avatar = ? WHERE id = ?").bind(p.picture, u.id).run();
    }
    if (u.locked) return redirect("/login?error=locked", { "Set-Cookie": clear });
    const token = await createSession(db, u.id, "google");
    const headers = new Headers({ Location: u.terms_at ? g.next : `/welcome?next=${encodeURIComponent(g.next)}`, "Cache-Control": "no-store" });
    headers.append("Set-Cookie", sessionCookie(request, token));
    headers.append("Set-Cookie", clear);
    return new Response(null, { status: 302, headers });
  }

  if (path === "/api/register" && method === "POST") {
    const ipk = `reg:${await ipKey(env, request)}`;
    await limit(db, ipk, 10, 3600, "Bạn đã đăng ký quá nhiều tài khoản. Vui lòng thử lại sau.");
    const b = await readJson(request);
    const name = String(b.name || "").replace(/\s+/g, " ").trim().slice(0, 80);
    const email = normEmail(b.email);
    const password = String(b.password || "");
    if (name.length < 2) throw new HttpError(400, "Họ tên cần ít nhất 2 ký tự.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200) throw new HttpError(400, "Email không hợp lệ.");
    if (password.length < 8 || password.length > 200) throw new HttpError(400, "Mật khẩu cần từ 8 đến 200 ký tự.");
    if (b.accept_terms !== true) throw new HttpError(400, "Bạn cần đồng ý với Điều khoản sử dụng và Chính sách quyền riêng tư.");
    const exists = await db.prepare("SELECT 1 FROM users WHERE email = ?").bind(email).first();
    if (exists) throw new HttpError(409, "Email này đã được đăng ký.");
    const r = await db.prepare("INSERT INTO users (email, name, pass_hash, terms_at, created) VALUES (?, ?, ?, ?, ?)")
      .bind(email, name, await hashPassword(password), now(), now()).run();
    await addHit(db, ipk);
    const id = r.meta.last_row_id;
    const token = await createSession(db, id);
    return json({ user: { id, name, email } }, 200, { "Set-Cookie": sessionCookie(request, token) });
  }

  if (path === "/api/login" && method === "POST") {
    const b = await readJson(request);
    // O dang nhap nhan email HOAC ten dang nhap. Ten dang nhap phan biet hoa thuong (so sanh chinh xac).
    const ident = String(b.email ?? "").trim().slice(0, 200);
    const email = normEmail(ident);
    const ipk = `login:${await ipKey(env, request)}`, ek = `login-email:${await sha256(ident.includes("@") ? email : ident)}`;
    for (const k of [ipk, ek]) await limit(db, k, 10, 900, "Đăng nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút.");
    const u = ident.includes("@")
      ? await db.prepare("SELECT id, name, email, pass_hash, locked FROM users WHERE email = ? AND username IS NULL").bind(email).first()
      : await db.prepare("SELECT id, name, email, pass_hash, locked FROM users WHERE username = ?").bind(ident).first();
    const ok = await verifyPassword(String(b.password || ""), u?.pass_hash || DUMMY_HASH);
    if (!u || !ok) {
      await addHit(db, ipk); await addHit(db, ek);
      if (u && !u.pass_hash) throw new HttpError(401, "Tài khoản này đăng nhập bằng Google. Hãy bấm \"Đăng nhập bằng Google\".");
      throw new HttpError(401, "Tên đăng nhập / email hoặc mật khẩu không đúng.");
    }
    if (u.locked) throw new HttpError(403, "Tài khoản của bạn đã bị quản trị viên khóa.");
    const token = await createSession(db, u.id);
    return json({ user: { id: u.id, name: u.name, email: u.email } }, 200,
      { "Set-Cookie": sessionCookie(request, token) });
  }

  if (path === "/api/logout" && method === "POST") {
    const u = await currentUser(request, env);
    if (u) await db.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(await sha256(u.token)).run();
    return json({ ok: true }, 200, { "Set-Cookie": sessionCookie(request, "", 0) });
  }

  // ======================= Cong khai =======================
  if (path === "/api/topics" && method === "GET") return json(TOPICS);

  if (path === "/api/templates" && method === "GET") {
    const { results } = await db.prepare("SELECT key, value FROM kv WHERE key LIKE 'tpl_used:%'").all();
    const used = Object.fromEntries(results.map(r => [r.key.slice(9), parseInt(r.value, 10) || 0]));
    const items = Object.values(TEMPLATES).map(t => ({ ...t, topic_label: topicLabel(t.topic), used: used[t.key] || 0 }));
    // "Pho bien": 3 mau duoc dung nhieu nhat (it nhat 3 lan)
    const top = [...items].sort((a, b) => b.used - a.used).filter(t => t.used >= 3).slice(0, 3).map(t => t.key);
    return json(items.map(t => ({ ...t, popular: top.includes(t.key) })));
  }

  if (path === "/api/search" && method === "GET") {
    const user = await currentUser(request, env);
    const terms = likeTerms(url.searchParams.get("q") || "");
    const topic = TOPICS[url.searchParams.get("topic")] ? url.searchParams.get("topic") : "";
    const sort = url.searchParams.get("sort") === "popular" ? "n DESC, s.published_at DESC" : "s.published_at DESC";
    const page = Math.max(0, parseInt(url.searchParams.get("page"), 10) || 0);
    const where = ["s.status = 'published'", "s.visibility = 'public'", "s.hidden = 0", "u.locked = 0",
      ...terms.map(() => "s.search_text LIKE ? ESCAPE '\\'"), ...(topic ? ["s.topic = ?"] : [])];
    const { results } = await db.prepare(
      `SELECT s.id, s.title, s.description, s.topic, s.published_at, s.closes_at, s.anonymous, u.name AS owner_name,
              (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id) AS n,
              EXISTS (SELECT 1 FROM responses r2 WHERE r2.survey_id = s.id AND r2.user_id = ?) AS answered
       FROM surveys s JOIN users u ON u.id = s.owner_id
       WHERE ${where.join(" AND ")} ORDER BY ${sort} LIMIT ? OFFSET ?`)
      .bind(user?.id || 0, ...terms, ...(topic ? [topic] : []), PAGE_SIZE + 1, page * PAGE_SIZE).all();
    return json({
      items: results.slice(0, PAGE_SIZE).map(r => ({ ...r, description: r.description.slice(0, 200), topic_label: topicLabel(r.topic),
        anonymous: !!r.anonymous, answered: !!r.answered })),
      more: results.length > PAGE_SIZE, page,
    });
  }

  m = /^\/api\/public\/surveys\/([a-f0-9]{10})(?:\/(responses|report))?$/.exec(path);
  if (m) {
    const [, id, sub] = m;
    const user = await currentUser(request, env);
    const s = await loadSurvey(db, id);
    if (!s || s.owner_locked) throw new HttpError(404, "Không tìm thấy khảo sát.");
    const owner = isOwner(user, s);
    if (s.status === "draft" && !owner) throw new HttpError(404, "Không tìm thấy khảo sát.");

    if (method === "GET" && !sub) {
      let successor = null;
      if (s.successor_id) {
        const nx = await db.prepare("SELECT id, status FROM surveys WHERE id = ?").bind(s.successor_id).first();
        if (nx && nx.status !== "draft") successor = nx.id;
      }
      const answered = user ? !!await db.prepare("SELECT 1 FROM responses WHERE survey_id = ? AND user_id = ?").bind(id, user.id).first() : false;
      const reported = user ? !!await db.prepare("SELECT 1 FROM reports WHERE survey_id = ? AND user_id = ?").bind(id, user.id).first() : false;
      return json({ id, title: s.title, description: s.description, topic_label: topicLabel(s.topic), questions: s.questions,
        status: s.status, anonymous: s.anonymous, owner_name: s.owner_name, successor, preview: s.status === "draft", closes_at: s.closes_at,
        viewer: { logged_in: !!user, is_owner: owner, answered, reported } });
    }
    if (method !== "POST") throw new HttpError(405, "Phương thức không hỗ trợ.");
    if (!user) throw new HttpError(401, "Bạn cần đăng nhập để trả lời khảo sát.");

    if (sub === "responses") {
      if (owner) throw new HttpError(403, "Bạn là người tạo khảo sát nên không thể tự trả lời. Hãy dùng chế độ Xem trước.");
      if (s.status !== "published" || (s.closes_at && s.closes_at <= now())) throw new HttpError(403, "Khảo sát này đã đóng, không nhận thêm câu trả lời.");
      const body = await readJson(request);
      const answers = cleanAnswers(s.questions, body.answers);
      const d = parseInt(body.duration, 10);
      const duration = Number.isFinite(d) && d > 0 ? Math.min(d, 86400) : null; // do trinh duyet do, chi de tham khao
      const r = await db.prepare("INSERT OR IGNORE INTO responses (survey_id, user_id, answers, created, duration) VALUES (?, ?, ?, ?, ?)")
        .bind(id, user.id, JSON.stringify(answers), now(), duration).run();
      if (!r.meta.changes) throw new HttpError(409, "Bạn đã trả lời khảo sát này rồi. Cảm ơn bạn!");
      return json({ ok: true });
    }
    if (sub === "report") {
      const reason = String((await readJson(request)).reason || "").trim().slice(0, 500);
      if (reason.length < 5) throw new HttpError(400, "Hãy mô tả lý do báo cáo (ít nhất 5 ký tự).");
      const r = await db.prepare("INSERT OR IGNORE INTO reports (survey_id, user_id, reason, created) VALUES (?, ?, ?, ?)")
        .bind(id, user.id, reason, now()).run();
      if (!r.meta.changes) throw new HttpError(409, "Bạn đã báo cáo khảo sát này rồi.");
      return json({ ok: true });
    }
  }

  // ======================= Hop thu gop y (src/feedback.js) =======================
  if (path.startsWith("/api/fb/")) {
    return handleFeedback({ request, env, url, path, method, db, cfg, llm, quota: {
      assert: (u, kind) => assertQuota(db, env, u, kind),
      add: (userId, kind, count, tokens) => addUsage(db, userId, kind, count, tokens),
      info: (u) => quotaInfo(db, env, u),
    } });
  }

  // ======================= Nguoi dung =======================
  if (!path.startsWith("/api/")) throw new HttpError(404, "Không tìm thấy.");
  const user = await requireUser(request, env);

  if (path === "/api/my/quota" && method === "GET") return json(await quotaInfo(db, env, user));

  if (path === "/api/me/password" && method === "POST") {
    const b = await readJson(request);
    const row = await db.prepare("SELECT pass_hash FROM users WHERE id = ?").bind(user.id).first();
    if (!row.pass_hash) throw new HttpError(400, "Tài khoản này đăng nhập bằng Google nên không có mật khẩu để đổi.");
    const k = `pw:${user.id}`;
    await limit(db, k, 10, 900, "Nhập sai mật khẩu hiện tại quá nhiều lần. Vui lòng thử lại sau 15 phút.");
    if (!await verifyPassword(String(b.current || ""), row.pass_hash)) { await addHit(db, k); throw new HttpError(400, "Mật khẩu hiện tại không đúng."); }
    const pw = String(b.password || "");
    if (pw.length < 8 || pw.length > 200) throw new HttpError(400, "Mật khẩu mới cần từ 8 đến 200 ký tự.");
    if (pw === b.current) throw new HttpError(400, "Mật khẩu mới phải khác mật khẩu hiện tại.");
    // Dang xuat moi phien khac (giu phien hien tai)
    await db.batch([
      db.prepare("UPDATE users SET pass_hash = ? WHERE id = ?").bind(await hashPassword(pw), user.id),
      db.prepare("DELETE FROM sessions WHERE user_id = ? AND token_hash != ?").bind(user.id, await sha256(user.token)),
    ]);
    return json({ ok: true });
  }

  if (path === "/api/me/terms" && method === "POST") {
    if ((await readJson(request)).accept !== true) throw new HttpError(400, "Bạn cần đồng ý với điều khoản để tiếp tục.");
    await db.prepare("UPDATE users SET terms_at = COALESCE(terms_at, ?) WHERE id = ?").bind(now(), user.id).run();
    return json({ ok: true });
  }

  if (path === "/api/my/surveys" && method === "GET") {
    const { results } = await db.prepare(
      `SELECT id, title, status, visibility, anonymous, topic, hidden, created, updated, published_at, closed_at, closes_at, root_id, parent_id,
              (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id) AS n,
              ROW_NUMBER() OVER (PARTITION BY root_id ORDER BY created) AS version
       FROM surveys s WHERE owner_id = ? ORDER BY updated DESC`).bind(user.id).all();
    return json(results.map(r => ({ ...r, anonymous: !!r.anonymous, hidden: !!r.hidden, topic_label: topicLabel(r.topic) })));
  }

  if (path === "/api/my/answered" && method === "GET") {
    const { results } = await db.prepare(
      `SELECT s.id, s.title, s.status, u.name AS owner_name, r.created FROM responses r
       JOIN surveys s ON s.id = r.survey_id JOIN users u ON u.id = s.owner_id
       WHERE r.user_id = ? ORDER BY r.created DESC`).bind(user.id).all();
    return json(results);
  }

  if (path === "/api/ai/suggest" && method === "POST") {
    await assertQuota(db, env, user, "gen");
    const b = await readJson(request);
    const purpose = String(b.purpose || "").trim().slice(0, 1000);
    if (purpose.length < 5) throw new HttpError(400, "Hãy mô tả mục đích khảo sát (ít nhất 5 ký tự).");
    const count = Math.max(3, Math.min(15, parseInt(b.count, 10) || 8));
    const usage = { tokens: 0, calls: 0 };
    const out = await suggestQuestions({ db, cfg, usage }, llm, {
      purpose, count, audience: String(b.audience || "").trim().slice(0, 300), decision: String(b.decision || "").trim().slice(0, 500),
    });
    await addUsage(db, user.id, "gen", 1, usage.tokens);
    return json({ ...out, quota: await quotaInfo(db, env, user) });
  }

  if (path === "/api/surveys" && method === "POST") {
    const b = await readJson(request);
    let src = b;
    if (b.template !== undefined) {
      const t = TEMPLATES[b.template];
      if (!t) throw new HttpError(400, "Mẫu khảo sát không tồn tại.");
      src = { title: t.title, description: t.description, topic: t.topic, purpose: t.description, questions: t.questions, anonymous: true };
    }
    const meta = validateMeta({ title: src.title || "", description: src.description || "", topic: src.topic || "khac",
      purpose: src.purpose || "", questions: src.questions || [], anonymous: !!src.anonymous });
    const id = randomHex(5);
    const stmts = [db.prepare(`INSERT INTO surveys (id, owner_id, title, description, topic, anonymous, purpose, questions, search_text, root_id, created, updated)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(id, user.id, meta.title, meta.description, meta.topic, meta.anonymous, meta.purpose, JSON.stringify(meta.questions),
        searchNorm(`${meta.title} ${meta.description}`), id, now(), now())];
    if (b.template !== undefined) {
      stmts.push(db.prepare(`INSERT INTO kv (key, value) VALUES (?, '1')
                             ON CONFLICT (key) DO UPDATE SET value = CAST(value AS INTEGER) + 1`).bind(`tpl_used:${b.template}`));
    }
    await db.batch(stmts);
    return json({ id });
  }

  m = /^\/api\/surveys\/([a-f0-9]{10})(?:\/([a-z/]+))?$/.exec(path);
  if (m) {
    const [, id, action = ""] = m;
    const s = await mustLoad(db, id);

    if (!action && method === "GET") {
      assertManage(user, s);
      const { results: versions } = await db.prepare(
        `SELECT id, status, created, published_at, (SELECT COUNT(*) FROM responses r WHERE r.survey_id = v.id) AS n,
                ROW_NUMBER() OVER (ORDER BY created) AS version
         FROM surveys v WHERE root_id = ? ORDER BY created`).bind(s.root_id).all();
      const a = await db.prepare("SELECT data FROM analyses WHERE survey_id = ?").bind(id).first();
      const { search_text, owner_locked, ...rest } = s;
      return json({ ...rest, topic_label: topicLabel(s.topic), responses: await countResponses(db, id), versions,
        version: versions.find(v => v.id === id)?.version || 1, is_owner: isOwner(user, s), analysis: a ? JSON.parse(a.data) : null });
    }

    if (!action && method === "PUT") {
      assertOwner(user, s);
      if (s.status !== "draft") throw new HttpError(409, "Khảo sát đã đăng không thể sửa. Hãy dùng \"Sửa nội dung\" để tạo phiên bản mới.");
      const meta = validateMeta(await readJson(request));
      const merged = { ...s, ...meta };
      const cols = Object.keys(meta);
      const vals = cols.map(c => (c === "questions" ? JSON.stringify(meta.questions) : meta[c]));
      await db.prepare(`UPDATE surveys SET ${[...cols.map(c => `${c} = ?`), "search_text = ?", "updated = ?"].join(", ")} WHERE id = ?`)
        .bind(...vals, searchNorm(`${merged.title} ${merged.description}`), now(), id).run();
      return json({ ok: true, questions: merged.questions });
    }

    if (method === "POST" && action === "publish") {
      assertOwner(user, s);
      if (s.status !== "draft") throw new HttpError(409, "Khảo sát này đã được đăng.");
      assertPublishable(s);
      const stmts = [db.prepare("UPDATE surveys SET status = 'published', published_at = ?, updated = ? WHERE id = ?").bind(now(), now(), id)];
      if (s.parent_id) {
        // Phien ban cu tu dong dong khi phien ban moi duoc dang
        stmts.push(db.prepare(`UPDATE surveys SET status = CASE WHEN status = 'published' THEN 'closed' ELSE status END,
                               closed_at = COALESCE(closed_at, ?), successor_id = ?, updated = ? WHERE id = ? AND owner_id = ?`)
          .bind(now(), id, now(), s.parent_id, user.id));
      }
      await db.batch(stmts);
      return json({ ok: true });
    }

    if (method === "POST" && action === "close") {
      assertManage(user, s);
      if (s.status !== "published") throw new HttpError(409, "Chỉ khảo sát đang nhận trả lời mới đóng được.");
      await db.prepare("UPDATE surveys SET status = 'closed', closed_at = ?, updated = ? WHERE id = ?").bind(now(), now(), id).run();
      return json({ ok: true });
    }

    // Dat / doi / bo han chot (khao sat dang nhan tra loi)
    if (method === "POST" && action === "deadline") {
      assertManage(user, s);
      if (s.status !== "published") throw new HttpError(409, "Chỉ đặt hạn chót cho khảo sát đang nhận trả lời.");
      const closes = parseDeadline((await readJson(request)).closes_at);
      await db.prepare("UPDATE surveys SET closes_at = ?, updated = ? WHERE id = ?").bind(closes, now(), id).run();
      return json({ ok: true, closes_at: closes });
    }

    // Mo lai khao sat da dong (gia han), tru khi da co phien ban moi duoc dang
    if (method === "POST" && action === "reopen") {
      assertManage(user, s);
      if (s.status !== "closed") throw new HttpError(409, "Chỉ mở lại được khảo sát đã đóng.");
      if (s.successor_id) {
        const nx = await db.prepare("SELECT status FROM surveys WHERE id = ?").bind(s.successor_id).first();
        if (nx && nx.status !== "draft") throw new HttpError(409, "Khảo sát này đã có phiên bản mới được đăng nên không mở lại được.");
      }
      const closes = parseDeadline((await readJson(request)).closes_at);
      await db.prepare("UPDATE surveys SET status = 'published', closed_at = NULL, closes_at = ?, updated = ? WHERE id = ?").bind(closes, now(), id).run();
      return json({ ok: true, closes_at: closes });
    }

    if (method === "POST" && action === "revise") {
      assertOwner(user, s);
      if (s.status === "draft") throw new HttpError(409, "Bản nháp có thể sửa trực tiếp.");
      const existing = await db.prepare("SELECT id FROM surveys WHERE parent_id = ? AND status = 'draft'").bind(id).first();
      if (existing) return json({ id: existing.id, existing: true });
      const nid = randomHex(5);
      await db.prepare(`INSERT INTO surveys (id, owner_id, status, title, description, topic, visibility, anonymous, purpose, decision,
                          questions, search_text, root_id, parent_id, created, updated)
                        VALUES (?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .bind(nid, user.id, s.title, s.description, s.topic, s.visibility, s.anonymous ? 1 : 0, s.purpose, s.decision,
          JSON.stringify(s.questions), s.search_text, s.root_id, id, now(), now()).run();
      return json({ id: nid, existing: false });
    }

    if (method === "POST" && action === "delete") {
      assertManage(user, s);
      await db.batch([
        ...["responses", "analyses", "reports", "analysis_runs"].map(t => db.prepare(`DELETE FROM ${t} WHERE survey_id = ?`).bind(id)),
        db.prepare("UPDATE surveys SET successor_id = NULL WHERE successor_id = ?").bind(id),
        db.prepare("UPDATE surveys SET parent_id = NULL WHERE parent_id = ?").bind(id),
        db.prepare("DELETE FROM surveys WHERE id = ?").bind(id),
      ]);
      return json({ ok: true });
    }

    if (method === "GET" && action === "results") {
      assertManage(user, s);
      const all = await getResponses(db, id);
      const fq = url.searchParams.get("fq"), fv = url.searchParams.get("fv");
      const filtered = filterResponses(all, s.questions, fq, fv);
      const stats = computeStats(s.questions, filtered).map(st => (st.texts ? { ...st, texts: st.texts.slice(-200).reverse() } : st));
      const dur = await db.prepare("SELECT AVG(duration) AS avg FROM responses WHERE survey_id = ? AND duration IS NOT NULL").bind(id).first();
      return json({ total: all.length, n: filtered.length, filter: fq && fv ? { qid: fq, value: fv } : null,
        avg_duration: dur?.avg ? Math.round(dur.avg) : null, stats });
    }

    // Tung cau tra loi (moi nhat truoc). Khao sat an danh: khong co ten/email.
    if (method === "GET" && action === "responses") {
      assertManage(user, s);
      const page = Math.max(0, parseInt(url.searchParams.get("page"), 10) || 0), size = 50;
      const total = await countResponses(db, id);
      const { results } = await db.prepare(
        `SELECT r.answers, r.created, r.duration, u.name, u.email FROM responses r JOIN users u ON u.id = r.user_id
         WHERE r.survey_id = ? ORDER BY r.id DESC LIMIT ? OFFSET ?`).bind(id, size, page * size).all();
      return json({ total, page, more: (page + 1) * size < total, anonymous: s.anonymous,
        items: results.map((r, i) => ({ no: total - page * size - i, created: r.created, duration: r.duration,
          answers: JSON.parse(r.answers), ...(s.anonymous ? {} : { name: r.name, email: r.email }) })) });
    }

    if (method === "GET" && action === "respondents") {
      assertManage(user, s);
      if (s.anonymous) throw new HttpError(403, "Khảo sát ẩn danh: không hiển thị danh tính người trả lời.");
      const { results } = await db.prepare(
        "SELECT u.name, u.email, r.created FROM responses r JOIN users u ON u.id = r.user_id WHERE r.survey_id = ? ORDER BY r.created DESC")
        .bind(id).all();
      return json(results);
    }

    if (method === "GET" && action === "export") {
      assertManage(user, s);
      const { results } = await db.prepare(
        "SELECT r.answers, r.created, u.name, u.email FROM responses r JOIN users u ON u.id = r.user_id WHERE r.survey_id = ? ORDER BY r.id")
        .bind(id).all();
      const head = ["Thời gian", ...(s.anonymous ? [] : ["Họ tên", "Email"]), ...s.questions.map((q, i) => `${i + 1}. ${q.question}`)];
      const rows = results.map(r => {
        const a = JSON.parse(r.answers);
        return [fmtTime(r.created), ...(s.anonymous ? [] : [r.name, r.email]), ...s.questions.map(q => a[q.id] ?? "")];
      });
      const csv = "﻿" + [head, ...rows].map(row => row.map(csvCell).join(",")).join("\r\n");
      return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Cache-Control": "no-store",
        "Content-Disposition": `attachment; filename="khaosat-${id}.csv"` } });
    }

    if (method === "POST" && action.startsWith("analyze/")) {
      assertManage(user, s);
      if (s.status === "draft") throw new HttpError(400, "Khảo sát chưa được đăng.");
      const b = await readJson(request);

      if (action === "analyze/start") {
        if (!await countResponses(db, id)) throw new HttpError(400, "Chưa có câu trả lời nào để phân tích.");
        await assertQuota(db, env, user, "ana");
        const run = randomHex(8);
        await db.batch([
          db.prepare("INSERT INTO analysis_runs (id, survey_id, user_id, created) VALUES (?, ?, ?, ?)").bind(run, id, user.id, now()),
          db.prepare("DELETE FROM analysis_runs WHERE created < ?").bind(now() - 86400),
        ]);
        await addUsage(db, user.id, "ana", 1, 0);
        return json({ run, open_questions: s.questions.filter(q => q.type === "open_text").map(q => q.id), quota: await quotaInfo(db, env, user) });
      }

      const run = await checkRun(db, b.run, s, user);
      const responses = await getResponses(db, id);
      const purpose = s.purpose || `${s.title}. ${s.description}`.trim();

      if (action === "analyze/themes") {
        const q = s.questions.find(q => q.id === b.qid && q.type === "open_text");
        if (!q) throw new HttpError(400, "Câu hỏi mở không hợp lệ.");
        const texts = computeStats([q], responses)[0].texts;
        if (!texts.length) return json({ themes: [], no_content: 0, usage: { tokens: 0, calls: 0 } });
        const { result, usage } = await runStep(db, run, user, (usage) => analyzeOpenText({ db, cfg, usage }, llm, purpose, q.question, texts));
        return json({ ...result, usage });
      }

      if (action === "analyze/summary") {
        const seg = b.segment || null;
        if (seg && !s.questions.some(q => q.id === seg && (q.type === "single_choice" || q.type === "dropdown"))) {
          throw new HttpError(400, "Câu hỏi dùng để so sánh nhóm không hợp lệ.");
        }
        const decision = String(b.decision ?? s.decision ?? "").trim().slice(0, 500);
        const { result: analysis, usage } = await runStep(db, run, user,
          (usage) => summarize({ db, cfg, usage }, llm, s, responses, b.themes || {}, decision, seg));
        const prev = b.usage || {};
        analysis.usage = {
          tokens: usage.tokens + (parseInt(prev.tokens, 10) || 0), calls: usage.calls + (parseInt(prev.calls, 10) || 0),
          waited: Math.max(0, parseFloat(prev.waited) || 0), seconds: Math.max(0, parseFloat(prev.seconds) || 0),
        };
        await db.prepare(`INSERT INTO analyses (survey_id, data, created) VALUES (?, ?, ?)
                          ON CONFLICT (survey_id) DO UPDATE SET data = excluded.data, created = excluded.created`)
          .bind(id, JSON.stringify(analysis), now()).run();
        return json(analysis);
      }
    }
    throw new HttpError(404, "Không tìm thấy.");
  }

  // ======================= Admin =======================
  if (path.startsWith("/api/admin/")) {
    const admin = await requireAdmin(request, env);

    if (path === "/api/admin/stats" && method === "GET") {
      const one = async (sql, ...p) => (await db.prepare(sql).bind(...p).first())?.n || 0;
      const { results: ai } = await db.prepare("SELECT kind, SUM(count) AS count, SUM(tokens) AS tokens FROM ai_usage WHERE day = ? GROUP BY kind")
        .bind(vnDay()).all();
      return json({
        users: await one("SELECT COUNT(*) AS n FROM users"),
        locked_users: await one("SELECT COUNT(*) AS n FROM users WHERE locked = 1"),
        surveys: { draft: await one("SELECT COUNT(*) AS n FROM surveys WHERE status = 'draft'"),
          published: await one("SELECT COUNT(*) AS n FROM surveys WHERE status = 'published'"),
          closed: await one("SELECT COUNT(*) AS n FROM surveys WHERE status = 'closed'") },
        responses: await one("SELECT COUNT(*) AS n FROM responses"),
        fb_boxes: await one("SELECT COUNT(*) AS n FROM fb_boxes"),
        fb_letters: await one("SELECT COUNT(*) AS n FROM fb_letters"),
        open_reports: await one("SELECT COUNT(*) AS n FROM reports WHERE resolved = 0"),
        ai_today: Object.fromEntries(ai.map(r => [r.kind, { count: r.count, tokens: r.tokens }])),
        day: vnDay(),
      });
    }

    if (path === "/api/admin/ai" && method === "GET") {
      const groq = await listModels(cfg, "groq");
      return json({ provider: llm.provider, model: llm.model, ok: groq.ok, error: groq.error, models: groq.models,
        defaults: { gen: parseInt(env.QUOTA_GEN, 10) || DEFAULT_QUOTA.gen, ana: parseInt(env.QUOTA_ANA, 10) || DEFAULT_QUOTA.ana } });
    }

    if (path === "/api/admin/users" && method === "GET") {
      const terms = likeTerms(url.searchParams.get("q") || "");
      const where = terms.map(() => "(LOWER(u.email) LIKE ? ESCAPE '\\' OR LOWER(u.name) LIKE ? ESCAPE '\\')");
      const { results } = await db.prepare(
        `SELECT u.id, u.email, u.name, u.username, u.role, u.locked, u.quota_gen, u.quota_ana, u.created, u.pass_hash != '' AS has_password,
                (SELECT COUNT(*) FROM surveys s WHERE s.owner_id = u.id) AS surveys,
                (SELECT COUNT(*) FROM responses r WHERE r.user_id = u.id) AS answered,
                (SELECT COUNT(*) FROM fb_boxes f WHERE f.owner_id = u.id) AS boxes,
                (SELECT COALESCE(SUM(count), 0) FROM ai_usage a WHERE a.user_id = u.id AND a.day = ? AND a.kind = 'gen') AS gen_today,
                (SELECT COALESCE(SUM(count), 0) FROM ai_usage a WHERE a.user_id = u.id AND a.day = ? AND a.kind = 'ana') AS ana_today
         FROM users u ${where.length ? "WHERE " + where.join(" AND ") : ""}
         ORDER BY u.created DESC LIMIT 300`)
        .bind(vnDay(), vnDay(), ...terms.flatMap(t => [t, t])).all();
      return json(results.map(r => ({ ...r, locked: !!r.locked, has_password: !!r.has_password,
        is_admin: r.role === "admin", is_hr: r.role === "admin" || r.role === "hr" })));
    }

    // Admin tao tai khoan HR (dang nhap bang ten dang nhap, khong can email)
    if (path === "/api/admin/users" && method === "POST") {
      const b = await readJson(request);
      const username = String(b.username ?? "").trim();
      const name = String(b.name || "").replace(/\s+/g, " ").trim().slice(0, 80);
      const password = String(b.password || "");
      if (!USERNAME_RE.test(username)) throw new HttpError(400, "Tên đăng nhập gồm 3–32 ký tự: chữ không dấu, số, dấu chấm, gạch dưới, gạch ngang.");
      if (name.length < 2) throw new HttpError(400, "Tên hiển thị cần ít nhất 2 ký tự.");
      if (password.length < 8 || password.length > 200) throw new HttpError(400, "Mật khẩu cần từ 8 đến 200 ký tự.");
      // Khong cho 2 ten chi khac nhau o hoa/thuong (de tranh nham lan), du dang nhap phan biet hoa thuong
      if (await db.prepare("SELECT 1 FROM users WHERE LOWER(username) = LOWER(?)").bind(username).first()) {
        throw new HttpError(409, "Tên đăng nhập này đã có người dùng.");
      }
      const r = await db.prepare("INSERT INTO users (email, name, pass_hash, username, role, created) VALUES (?, ?, ?, ?, 'hr', ?)")
        .bind(usernameEmail(username), name, await hashPassword(password), username, now()).run();
      return json({ id: r.meta.last_row_id });
    }

    m = /^\/api\/admin\/users\/(\d+)$/.exec(path);
    if (m && method === "POST") {
      const target = await db.prepare("SELECT id, email, role, username FROM users WHERE id = ?").bind(+m[1]).first();
      if (!target) throw new HttpError(404, "Không tìm thấy người dùng.");
      const b = await readJson(request);
      const stmts = [];
      if ("locked" in b) {
        if (b.locked && (target.id === admin.id || target.role === "admin")) throw new HttpError(400, "Không thể khóa tài khoản quản trị viên.");
        stmts.push(db.prepare("UPDATE users SET locked = ? WHERE id = ?").bind(b.locked ? 1 : 0, target.id));
        if (b.locked) stmts.push(db.prepare("DELETE FROM sessions WHERE user_id = ?").bind(target.id)); // dang xuat ngay
      }
      if ("hr" in b) {
        if (target.role === "admin") throw new HttpError(400, "Quản trị viên luôn có quyền HR.");
        stmts.push(db.prepare("UPDATE users SET role = ? WHERE id = ?").bind(b.hr ? "hr" : null, target.id));
      }
      if ("password" in b) {
        // Chi dat lai mat khau cho tai khoan dang nhap bang ten (do admin tao); khong dong vao tai khoan email/Google cua nguoi khac
        if (!target.username || target.role === "admin") throw new HttpError(400, "Chỉ đặt lại được mật khẩu cho tài khoản đăng nhập bằng tên đăng nhập (do quản trị viên tạo).");
        const pw = String(b.password || "");
        if (pw.length < 8 || pw.length > 200) throw new HttpError(400, "Mật khẩu cần từ 8 đến 200 ký tự.");
        stmts.push(db.prepare("UPDATE users SET pass_hash = ? WHERE id = ?").bind(await hashPassword(pw), target.id));
        stmts.push(db.prepare("DELETE FROM sessions WHERE user_id = ?").bind(target.id)); // dang xuat moi phien cu
      }
      for (const k of ["quota_gen", "quota_ana"]) {
        if (k in b) {
          const v = b[k] === null || b[k] === "" ? null : Math.max(0, Math.min(1000, parseInt(b[k], 10) || 0));
          stmts.push(db.prepare(`UPDATE users SET ${k} = ? WHERE id = ?`).bind(v, target.id));
        }
      }
      if (stmts.length) await db.batch(stmts);
      return json({ ok: true });
    }

    if (path === "/api/admin/surveys" && method === "GET") {
      const terms = likeTerms(url.searchParams.get("q") || "");
      const status = ["draft", "published", "closed"].includes(url.searchParams.get("status")) ? url.searchParams.get("status") : "";
      const where = [...terms.map(() => "s.search_text LIKE ? ESCAPE '\\'"), ...(status ? ["s.status = ?"] : [])];
      const { results } = await db.prepare(
        `SELECT s.id, s.title, s.status, s.visibility, s.hidden, s.created, s.published_at, u.name AS owner_name, u.email AS owner_email,
                (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id) AS n,
                (SELECT COUNT(*) FROM reports p WHERE p.survey_id = s.id AND p.resolved = 0) AS reports
         FROM surveys s JOIN users u ON u.id = s.owner_id ${where.length ? "WHERE " + where.join(" AND ") : ""}
         ORDER BY s.updated DESC LIMIT 300`).bind(...terms, ...(status ? [status] : [])).all();
      return json(results.map(r => ({ ...r, hidden: !!r.hidden })));
    }

    m = /^\/api\/admin\/surveys\/([a-f0-9]{10})$/.exec(path);
    if (m && method === "POST") {
      const s = await mustLoad(db, m[1]);
      const b = await readJson(request);
      if ("hidden" in b) await db.prepare("UPDATE surveys SET hidden = ? WHERE id = ?").bind(b.hidden ? 1 : 0, s.id).run();
      return json({ ok: true });
    }

    if (path === "/api/admin/reports" && method === "GET") {
      const resolved = url.searchParams.get("resolved") === "1" ? 1 : 0;
      const { results } = await db.prepare(
        `SELECT p.id, p.reason, p.created, p.resolved, s.id AS survey_id, s.title, s.hidden, u.name AS reporter_name, u.email AS reporter_email
         FROM reports p JOIN surveys s ON s.id = p.survey_id JOIN users u ON u.id = p.user_id
         WHERE p.resolved = ? ORDER BY p.created DESC LIMIT 300`).bind(resolved).all();
      return json(results.map(r => ({ ...r, hidden: !!r.hidden, resolved: !!r.resolved })));
    }

    m = /^\/api\/admin\/reports\/(\d+)$/.exec(path);
    if (m && method === "POST") {
      const b = await readJson(request);
      await db.prepare("UPDATE reports SET resolved = ? WHERE id = ?").bind(b.resolved ? 1 : 0, +m[1]).run();
      return json({ ok: true });
    }
  }
  throw new HttpError(404, "Không tìm thấy.");
}

export async function handle(request, env) {
  try {
    return await route(request, env);
  } catch (e) {
    if (e instanceof WaitSignal) return json({ wait: Math.ceil(e.wait), label: e.label });
    if (e instanceof HttpError) return json({ error: e.message }, e.status);
    if (e instanceof LLMError) return json({ error: e.message }, 502);
    if (e?.status) return json({ error: e.message }, e.status);
    console.error(e);
    return json({ error: `Lỗi server: ${e?.message || e}` }, 500);
  }
}
