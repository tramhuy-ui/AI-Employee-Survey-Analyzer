// Kiem thu tren may, khong can Cloudflare: gia lap D1 bang node:sqlite va goi thang router.
//   node test/local.mjs          -> Groq gia lap: phan quyen, vong doi khao sat, tra loi, AI, admin
//   node test/local.mjs --real   -> Groq that (doc GROQ_API_KEY tu ../.env): 10 cau x 30 nguoi
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";
import { handle } from "../src/app.js";
import { hashPassword } from "../src/auth.js";

const REAL = process.argv.includes("--real");
const ADMIN_EMAIL = "admin@test.vn"; // email cu cua admin: nay chi la nguoi dung thuong
const ADMIN_USER = "Admin_account", ADMIN_PASS = "Mat-khau-admin-1";

// ------------------------------------------------------------- D1 gia lap ----
class Stmt {
  constructor(db, sql, params = []) { this.db = db; this.sql = sql; this.params = params; }
  bind(...p) { return new Stmt(this.db, this.sql, p.map(v => (v === undefined ? null : v))); }
  async first(col) { const r = this.db.prepare(this.sql).get(...this.params); return r ? (col ? r[col] : { ...r }) : null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.params).map(r => ({ ...r })) }; }
  async run() { const i = this.db.prepare(this.sql).run(...this.params); return { meta: { changes: i.changes, last_row_id: Number(i.lastInsertRowid) } }; }
}
class D1 {
  constructor() { this.db = new DatabaseSync(":memory:"); }
  prepare(sql) { return new Stmt(this.db, sql); }
  async batch(stmts) {
    this.db.exec("BEGIN");
    try { const out = []; for (const s of stmts) out.push(await s.run()); this.db.exec("COMMIT"); return out; }
    catch (e) { this.db.exec("ROLLBACK"); throw e; }
  }
}

// ------------------------------------------------------------ Groq gia lap ----
const MOCK_URL = "https://mock.groq.test/openai/v1";
const mock = { suggestCalls: 0, prompts: [], google: {} };
const GOOGLE_CID = "cid-test.apps.googleusercontent.com";
const fakeJwt = (payload) => ["e30", Buffer.from(JSON.stringify(payload)).toString("base64url"), "sig"].join(".");
const realFetch = globalThis.fetch;

function fakeResult(props, prompt = "") {
  if (props.items) { // hop thu gop y: cham muc hai long tung thu
    const items = [];
    for (const m of prompt.matchAll(/^\[(\d+)\] \(nhân viên chọn chủ đề: [^)]*\) (.*)$/gm)) {
      const [, id, text] = m;
      if (text.includes("BỎ QUA")) continue; // AI "quen" mot thu
      items.push({ id: +id, sat: /tệ|bức xúc/.test(text) ? 1 : /cảm ơn/i.test(text) ? 5 : /SAI ĐIỂM/.test(text) ? 9 : 3, topic: /lương/.test(text) ? "luong_thuong" : "khac" });
    }
    return { items };
  }
  if (props.overview) {
    const codes = [...prompt.matchAll(/\[(T\d+)\]/g)].map(m => m[1]);
    const box = /^- (Phòng [^:]+): \d+ thư/m.exec(prompt)?.[1] || "";
    return { overview: "Tình hình chung.", limitations: "Ít thư.",
      issues: [{ text: "Lương thấp", severity: "thap", evidence: [codes[0], "T999999"] }, { text: "Không bằng chứng", severity: "cao", evidence: ["x"] },
        { text: "Quản lý la mắng", severity: "cao", evidence: [codes[1] || codes[0]] }],
      positives: [], quick_actions: [{ text: "Gặp riêng phòng", evidence: [] }],
      retention_risk: { level: "cao", reason: "Nhiều thư bức xúc", evidence: [codes[0]] },
      departments: [{ name: box, main_issue: "Lương" }, { name: "Phòng Ma", main_issue: "x" }],
      focus: { name: box, reason: "Tiêu cực nhất" } };
  }
  if (props.questions) {
    return { title: "Khảo sát căng tin", description: "Giúp cải thiện căng tin.", topic: "gan_ket", questions: [
      { question: "Bạn là sinh viên năm mấy?", type: "single_choice", options: ["Năm 1", "Năm 2", "Năm 1"], scale_min_label: "", scale_max_label: "" },
      { question: "Mức hài lòng chung?", type: "scale", options: ["x"], scale_min_label: "Rất không hài lòng", scale_max_label: "Rất hài lòng" },
      { question: "Chọn món", type: "dropdown", options: ["Cơm"], scale_min_label: "", scale_max_label: "" },
      { question: "Bạn muốn cải thiện gì?", type: "open_text", options: [], scale_min_label: "", scale_max_label: "" }] };
  }
  if (props.themes) {
    return { themes: [{ name: "Giá cả", description: "Giá cao", sentiment: "tieu_cuc", ids: [0, 99] },
      { name: "Vệ sinh", description: "Bàn bẩn", sentiment: "tieu_cuc", ids: [1] }] };
  }
  const hr = props.retention_risk ? { retention_risk: { level: "cao", reason: "eNPS âm", evidence: ["q6", "zzz"] },
    quick_actions: [{ text: "Gặp riêng nhóm năm 2", evidence: ["q1"] }, { text: "", evidence: [] }] } : {};
  return { ...hr, summary: "Tóm tắt.", limitations: "Mẫu nhỏ",
    highlights: [{ text: "Giá là vấn đề", evidence: ["C1", "[q2]", "C99"] }, { text: "Không bằng chứng", evidence: ["zzz"] }],
    issues: [{ text: "thấp", severity: "thap", evidence: ["C2"] }, { text: "cao", severity: "cao", evidence: ["c1"] }],
    positives: [], notable: [], recommendations: [{ text: "Giảm giá", evidence: [] }] };
}

function mockFetch(url, init = {}) {
  url = String(url);
  if (url === "https://oauth2.googleapis.com/token") {
    const f = new URLSearchParams(init.body);
    const prof = mock.google[f.get("code")];
    const ok = prof && f.get("client_secret") === "secret-test" && f.get("code_verifier")?.length > 20 && f.get("redirect_uri") === "https://khaosat.test/api/auth/google/callback";
    if (!ok) return Promise.resolve(new Response(JSON.stringify({ error: "invalid_grant" }), { status: 400 }));
    return Promise.resolve(new Response(JSON.stringify({ id_token: fakeJwt({ iss: "https://accounts.google.com", aud: GOOGLE_CID,
      exp: Math.floor(Date.now() / 1000) + 3600, email_verified: true, ...prof }) })));
  }
  if (!url.startsWith(MOCK_URL)) return realFetch(url, init);
  const reply = (obj, status = 200, headers = {}) => Promise.resolve(new Response(JSON.stringify(obj), { status, headers }));
  if (url.endsWith("/models")) return reply({ data: [{ id: "openai/gpt-oss-120b" }] });
  const body = JSON.parse(init.body);
  const schema = body.response_format.json_schema.schema;
  mock.prompts.push(body.messages.map(m => m.content).join("\n"));
  if (schema.properties.questions && ++mock.suggestCalls === 1) {
    return reply({ error: { message: "Rate limit reached (TPM). Please try again in 1.1s." } }, 429);
  }
  return reply({ choices: [{ message: { content: JSON.stringify(fakeResult(schema.properties, body.messages[1].content)) } }], usage: { total_tokens: 1000 } }, 200,
    { "x-ratelimit-remaining-tokens": "7000", "x-ratelimit-reset-tokens": "7.5s", "x-ratelimit-limit-tokens": "8000" });
}

// ------------------------------------------------------------- tro giup ----
const env = { DB: new D1(), APP_SECRET: "test-secret", GOOGLE_CLIENT_ID: GOOGLE_CID, GOOGLE_CLIENT_SECRET: "secret-test" };
if (REAL) {
  env.GROQ_API_KEY = /^GROQ_API_KEY=(.+)$/m.exec(readFileSync(new URL("../../.env", import.meta.url), "utf8"))?.[1]?.trim();
  if (!env.GROQ_API_KEY) throw new Error("Không thấy GROQ_API_KEY trong ../.env");
} else {
  env.GROQ_API_KEY = "gsk_test";
  env.GROQ_URL = MOCK_URL;
  globalThis.fetch = mockFetch;
}

class Client {
  constructor(ip) { this.ip = ip; this.jar = {}; }
  async call(method, path, body, { contentType = "application/json", raw = false } = {}) {
    const headers = { "cf-connecting-ip": this.ip };
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join("; ");
    if (cookie) headers.cookie = cookie;
    if (body !== undefined) headers["content-type"] = contentType;
    const res = await handle(new Request("https://khaosat.test" + path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env);
    for (const c of res.headers.getSetCookie()) {
      const [kv] = c.split(";"); const i = kv.indexOf("=");
      if (/Max-Age=0/.test(c)) delete this.jar[kv.slice(0, i)]; else this.jar[kv.slice(0, i)] = kv.slice(i + 1);
    }
    if (res.status === 302) return { status: 302, location: res.headers.get("location"), headers: res.headers };
    // raw: doc byte, giu ky tu BOM o dau (res.text() tu bo BOM)
    const data = raw ? new TextDecoder("utf-8", { ignoreBOM: true }).decode(await res.arrayBuffer()) : await res.json();
    return { status: res.status, data, headers: res.headers };
  }
  get(p, o) { return this.call("GET", p, undefined, o); }
  post(p, b = {}) { return this.call("POST", p, b); }
  put(p, b) { return this.call("PUT", p, b); }
  // Giong trinh duyet: server bao "wait" thi cho roi goi lai
  async ai(path, body, log) {
    for (let waited = 0; ;) {
      const r = await this.post(path, body);
      if (!r.data.wait) return r;
      log?.(`   … chờ giới hạn ${r.data.label} ${r.data.wait} giây`);
      waited += r.data.wait;
      assert.ok(waited < 300, "chờ quá lâu");
      await new Promise(ok => setTimeout(ok, r.data.wait * 1000));
    }
  }
}

// Dang nhap Google qua server that, Google gia lap. Tra ve dia chi server chuyen huong toi sau cung.
let codeNo = 0;
async function googleLogin(c, profile, { next = "/dashboard", state } = {}) {
  const start = await c.get(`/api/auth/google/start?next=${encodeURIComponent(next)}`);
  assert.equal(start.status, 302);
  const u = new URL(start.location);
  assert.equal(u.origin + u.pathname, "https://accounts.google.com/o/oauth2/v2/auth");
  assert.equal(u.searchParams.get("scope"), "openid email profile"); assert.equal(u.searchParams.get("code_challenge_method"), "S256");
  const code = `code${++codeNo}`;
  if (profile) mock.google[code] = profile;
  const cb = await c.get(`/api/auth/google/callback?code=${code}&state=${state ?? u.searchParams.get("state")}`);
  assert.equal(cb.status, 302);
  return cb.location;
}

async function register(name, email, ip, password = "matkhau123") {
  const c = new Client(ip);
  const r = await c.post("/api/register", { name, email, password, accept_terms: true });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return c;
}

// Tai khoan admin duoc tao thang trong CSDL (giong cach tao tren web that), dang nhap bang ten dang nhap
async function seedAccount(username, name, password, role) {
  await env.DB.prepare("INSERT INTO users (email, name, pass_hash, username, role, terms_at, created) VALUES (?, ?, ?, ?, ?, ?, ?)")
    .bind("@" + username, name, await hashPassword(password), username, role, 1, 1).run();
}
async function loginAs(ident, password, ip) {
  const c = new Client(ip);
  const r = await c.post("/api/login", { email: ident, password });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return c;
}

const ok = (msg) => console.log("  ✓", msg);
const expect = async (p, status, msg) => { const r = await p; assert.equal(r.status, status, `${msg}: ${JSON.stringify(r.data)}`); return r; };

const QUESTIONS = [
  { id: "q1", question: "Bạn là sinh viên năm mấy?", type: "single_choice", options: ["Năm 1", "Năm 2"], required: true },
  { id: "q2", question: "Mức hài lòng chung?", type: "scale", scale: ["Rất tệ", "Rất tốt"], required: true },
  { id: "q3", question: "Bạn hay ăn món gì?", type: "multiple_choice", options: ["Cơm", "Phở", "Bánh mì"] },
  { id: "q4", question: "Khu vực", type: "dropdown", options: ["A", "B", "C"] },
  { id: "q5", question: "Chấm sao chất lượng", type: "rating" },
  { id: "q6", question: "Bạn có giới thiệu căng tin cho bạn bè?", type: "nps" },
  { id: "q7", question: "Bạn muốn cải thiện gì?", type: "open_text" },
];

// ------------------------------------------------------------- kiem thu ----
async function mainTests() {
  console.log("== Kiểm thử với Groq giả lập");
  const anon = new Client("10.0.0.9");

  // ---------- Tai khoan ----------
  const alice = await register("Alice Nguyễn", "Alice@Test.vn", "10.0.0.1");
  const bob = await register("Bob Trần", "bob@test.vn", "10.0.0.2");
  const carol = await register("Carol Lê", "carol@test.vn", "10.0.0.3");
  await anon.get("/api/me"); // tao bang
  await seedAccount(ADMIN_USER, "Quản trị viên", ADMIN_PASS, "admin");
  await expect(new Client("10.0.0.4").post("/api/login", { email: "admin_account", password: ADMIN_PASS }), 401, "tên đăng nhập phân biệt hoa thường");
  await expect(new Client("10.0.0.4").post("/api/login", { email: "@admin_account", password: ADMIN_PASS }), 401, "không lách bằng email @...");
  await expect(new Client("10.0.0.4").post("/api/login", { email: ADMIN_USER, password: ADMIN_PASS.toUpperCase() }), 401, "mật khẩu phân biệt hoa thường");
  const admin = await loginAs(ADMIN_USER, ADMIN_PASS, "10.0.0.4");
  const oldAdmin = await register("Email admin cũ", ADMIN_EMAIL, "10.0.0.11");
  assert.equal(await googleLogin(oldAdmin, { sub: "g-old", email: ADMIN_EMAIL, name: "X" }), "/dashboard");
  assert.equal((await oldAdmin.get("/api/me")).data.user.is_admin, false, "email admin cũ + Google: không còn quyền admin");
  await expect(oldAdmin.get("/api/admin/stats"), 403, "email admin cũ");
  await expect(new Client("10.0.0.5").post("/api/register", { name: "Dan", email: "dan@test.vn", password: "matkhau123" }), 400, "phải đồng ý điều khoản");
  await expect(new Client("10.0.0.5").post("/api/register", { name: "X", email: "alice@test.vn", password: "matkhau123" }), 400, "tên quá ngắn");
  await expect(new Client("10.0.0.5").post("/api/register", { name: "Alice 2", email: "ALICE@test.vn", password: "matkhau123", accept_terms: true }), 409, "email trùng");
  await expect(new Client("10.0.0.5").post("/api/register", { name: "Dan", email: "khong-phai-email", password: "matkhau123" }), 400, "email sai");
  await expect(new Client("10.0.0.5").post("/api/register", { name: "Dan", email: "dan@test.vn", password: "ngan" }), 400, "mật khẩu ngắn");
  const pw = env.DB.db.prepare("SELECT pass_hash FROM users WHERE email = 'bob@test.vn'").get().pass_hash;
  assert.match(pw, /^pbkdf2\$10000\$/); assert.ok(!pw.includes("matkhau123"));
  ok("đăng ký: kiểm tra dữ liệu, email trùng (không phân biệt hoa thường), mật khẩu được băm PBKDF2");

  assert.equal((await alice.get("/api/me")).data.user.is_admin, false);
  assert.equal((await admin.get("/api/me")).data.user.is_admin, true);
  assert.equal((await anon.get("/api/me")).data.user, null);
  const login = await expect(new Client("10.0.0.6").post("/api/login", { email: "bob@test.vn", password: "matkhau123" }), 200, "đăng nhập");
  assert.match(login.headers.get("set-cookie"), /HttpOnly; SameSite=Lax.*Secure/);
  const brute = new Client("10.0.0.7");
  for (let i = 0; i < 10; i++) await expect(brute.post("/api/login", { email: "bob@test.vn", password: "sai" + i }), 401, "sai mật khẩu");
  await expect(brute.post("/api/login", { email: "bob@test.vn", password: "matkhau123" }), 429, "khóa sau 10 lần sai");
  await expect(alice.post("/api/login", { email: "x@test.vn", password: "a" }), 401, "email không tồn tại");
  const am = (await admin.get("/api/me")).data.user;
  assert.equal(am.username, ADMIN_USER); assert.equal(am.is_hr, true); assert.equal(am.role, "admin");
  ok("đăng nhập: cookie HttpOnly/Lax/Secure, khóa 15 phút sau 10 lần sai; admin = tài khoản Admin_account (tên đăng nhập phân biệt hoa thường)");

  // ---------- Dang nhap Google ----------
  assert.equal((await anon.get("/api/me")).data.google, true);
  const gina = new Client("10.0.1.1");
  assert.equal(await googleLogin(gina, { sub: "g-gina", email: "Gina@Gmail.com", name: "Gina Phạm", picture: "https://lh3.googleusercontent.com/a/x" },
    { next: "/s/abc" }), `/welcome?next=${encodeURIComponent("/s/abc")}`, "tài khoản mới → màn hình đồng ý điều khoản");
  let me = (await gina.get("/api/me")).data.user;
  assert.equal(me.email, "gina@gmail.com"); assert.equal(me.needs_terms, true); assert.equal(me.via, "google");
  assert.equal(me.avatar, "https://lh3.googleusercontent.com/a/x");
  assert.ok(!gina.jar.ks_oauth, "xóa cookie tạm");
  await expect(gina.post("/api/me/terms", { accept: false }), 400, "phải bấm đồng ý");
  await gina.post("/api/me/terms", { accept: true });
  assert.equal((await gina.get("/api/me")).data.user.needs_terms, false);
  const gpw = await expect(new Client("10.0.1.2").post("/api/login", { email: "gina@gmail.com", password: "matkhau123" }), 401, "tài khoản Google không có mật khẩu");
  assert.match(gpw.data.error, /Google/);
  assert.equal(await googleLogin(new Client("10.0.1.3"), { sub: "g-gina", email: "gina@gmail.com", name: "Gina" }), "/dashboard", "lần sau vào thẳng");
  const bobId = env.DB.db.prepare("SELECT id FROM users WHERE email = 'bob@test.vn'").get().id;
  const bobG = new Client("10.0.1.4");
  assert.equal(await googleLogin(bobG, { sub: "g-bob", email: "bob@test.vn", name: "Bob Google" }), "/dashboard", "gộp vào tài khoản cũ (đã đồng ý khi đăng ký)");
  me = (await bobG.get("/api/me")).data.user;
  assert.equal(me.id, bobId); assert.equal(me.name, "Bob Trần", "giữ tên cũ");
  env.DB.db.exec("DELETE FROM hits"); // gia lap 15 phut da qua (email Bob bi khoa do kiem thu do mat khau o tren)
  await expect(new Client("10.0.1.5").post("/api/login", { email: "bob@test.vn", password: "matkhau123" }), 200, "vẫn đăng nhập bằng mật khẩu được");
  assert.equal(env.DB.db.prepare("SELECT COUNT(*) AS n FROM users").get().n, 6, "không tạo tài khoản trùng");
  assert.equal(await googleLogin(new Client("10.0.1.6"), { sub: "g-khac", email: "bob@test.vn", name: "X" }), "/login?error=linked");
  assert.equal(await googleLogin(new Client("10.0.1.7"), { sub: "g-x", email: "x@gmail.com" }, { state: "sai" }), "/login?error=state", "chống CSRF bằng state");
  assert.equal(await googleLogin(new Client("10.0.1.8"), { sub: "g-y", email: "y@gmail.com", email_verified: false }), "/login?error=unverified");
  assert.equal(await googleLogin(new Client("10.0.1.9"), { sub: "g-z", email: "z@gmail.com", aud: "khac" }), "/login?error=token", "id_token cho app khác");
  assert.equal(await googleLogin(new Client("10.0.1.10"), null), "/login?error=token", "Google từ chối mã");
  const cancel = new Client("10.0.1.11"); await cancel.get("/api/auth/google/start");
  assert.equal((await cancel.get("/api/auth/google/callback?error=access_denied")).location, "/login?error=cancelled");
  assert.equal(await googleLogin(new Client("10.0.1.12"), { sub: "g-gina", email: "gina@gmail.com" }, { next: "//evil.com" }), "/dashboard", "chặn chuyển hướng ra ngoài");
  ok("Google: tạo tài khoản + đồng ý điều khoản, ảnh đại diện, gộp tài khoản cũ cùng email, PKCE/state, kiểm tra id_token, chặn chuyển hướng ngoài");

  await expect(anon.get("/api/my/surveys"), 401, "khách không có trang của tôi");
  await expect(alice.call("POST", "/api/surveys", {}, { contentType: "text/plain" }), 415, "chặn request không phải JSON (CSRF)");

  // ---------- Ban nhap & phan quyen ----------
  const { data: { id: sid } } = await expect(alice.post("/api/surveys", { title: "Khảo sát Căng tin" }), 200, "tạo nháp");
  await expect(alice.put(`/api/surveys/${sid}`, { title: "Khảo sát Căng tin trường", description: "Ý kiến về đồ ăn",
    topic: "gan_ket", visibility: "public", questions: QUESTIONS, decision: "Có thêm quầy không" }), 200, "sửa nháp");
  const draft = (await alice.get(`/api/surveys/${sid}`)).data;
  assert.equal(draft.status, "draft"); assert.equal(draft.questions.length, 7); assert.equal(draft.version, 1);
  for (const [m, p, b] of [["GET", ""], ["PUT", "", { title: "hack" }], ["POST", "/publish"], ["POST", "/delete"], ["POST", "/revise"],
    ["GET", "/results"], ["GET", "/respondents"], ["GET", "/export"]]) {
    await expect(bob.call(m, `/api/surveys/${sid}${p}`, m === "GET" ? undefined : (b || {})), 403, `Bob ${m} ${p} khảo sát của Alice`);
    await expect(anon.call(m, `/api/surveys/${sid}${p}`, m === "GET" ? undefined : (b || {})), 401, `khách ${m} ${p}`);
  }
  await expect(bob.get(`/api/public/surveys/${sid}`), 404, "người khác không thấy bản nháp");
  assert.equal((await alice.get(`/api/public/surveys/${sid}`)).data.preview, true);
  assert.equal((await anon.get("/api/search?q=cang tin")).data.items.length, 0);
  ok("bản nháp: chỉ người tạo xem/sửa; người khác 403, khách 401; người tạo xem trước được");

  const { data: { id: bad } } = await alice.post("/api/surveys", {});
  await expect(alice.post(`/api/surveys/${bad}/publish`), 400, "không có tiêu đề");
  await alice.put(`/api/surveys/${bad}`, { title: "Lỗi", questions: [{ question: "Chọn", type: "single_choice", options: ["Một"] }] });
  await expect(alice.post(`/api/surveys/${bad}/publish`), 400, "câu chọn cần ≥2 đáp án");
  await alice.post(`/api/surveys/${bad}/delete`);
  ok("không cho đăng khảo sát thiếu tiêu đề / câu chọn thiếu đáp án");

  await expect(alice.post(`/api/surveys/${sid}/publish`), 200, "đăng");
  await expect(alice.put(`/api/surveys/${sid}`, { title: "Sửa sau khi đăng" }), 409, "không sửa khi đã đăng");
  const found = (await anon.get("/api/search?q=cang tin&topic=gan_ket")).data.items;
  assert.equal(found.length, 1); assert.equal(found[0].owner_name, "Alice Nguyễn");
  assert.equal((await anon.get("/api/search?q=cang&topic=suc_khoe")).data.items.length, 0);
  const { data: { id: linkOnly } } = await bob.post("/api/surveys", { title: "Khảo sát riêng của lớp" });
  await bob.put(`/api/surveys/${linkOnly}`, { visibility: "link", anonymous: true, topic: "khac",
    questions: [{ question: "Góp ý cho lớp", type: "open_text", required: true }] });
  await bob.post(`/api/surveys/${linkOnly}/publish`);
  assert.equal((await anon.get("/api/search?q=khao sat")).data.items.length, 1, "khảo sát 'chỉ ai có link' không hiện khi tìm");
  assert.equal((await anon.get(`/api/public/surveys/${linkOnly}`)).status, 200);
  ok("đăng: khóa nội dung; tìm kiếm không dấu + lọc chủ đề; 'chỉ ai có link' không hiện khi tìm nhưng mở bằng link được");

  // ---------- Tra loi ----------
  await expect(anon.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 1", q2: 4 } }), 401, "khách phải đăng nhập");
  await expect(alice.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 1", q2: 4 } }), 403, "không tự trả lời");
  await expect(bob.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 1" } }), 400, "thiếu câu bắt buộc");
  await expect(bob.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 1", q2: 4, q3: ["Cơm", "Hack"], q4: "B",
    q5: 5, q6: 10, q7: "Giá đắt quá" }, duration: 95 }), 200, "Bob trả lời");
  await expect(bob.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 2", q2: 1 } }), 409, "trả lời lần 2");
  await expect(carol.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 2", q2: 2, q5: 9, q6: 3, q7: "Bàn ghế bẩn" }, duration: "abc" }), 200, "Carol");
  await expect(admin.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 1", q2: 5, q6: 8, q7: "Không có ý kiến" }, duration: 999999 }), 200, "admin");
  const pub = (await bob.get(`/api/public/surveys/${sid}`)).data;
  assert.equal(pub.viewer.answered, true);
  assert.equal((await bob.get("/api/search?q=cang")).data.items[0].answered, true);
  assert.deepEqual((await bob.get("/api/my/answered")).data.map(r => r.id), [sid]);
  ok("trả lời: bắt buộc đăng nhập, người tạo không tự trả lời, kiểm tra câu bắt buộc, mỗi người 1 lần, trang 'đã trả lời'");

  const res = (await alice.get(`/api/surveys/${sid}/results`)).data;
  const st = Object.fromEntries(res.stats.map(s => [s.id, s]));
  assert.equal(res.total, 3);
  assert.deepEqual(st.q3.counts, { "Cơm": 1, "Phở": 0, "Bánh mì": 0 }, "đáp án lạ bị bỏ");
  assert.equal(st.q5.answered, 1, "sao ngoài 1-5 bị bỏ"); assert.equal(st.q6.nps, 0, "NPS = (1 ủng hộ - 1 phản đối)/3");
  assert.deepEqual(st.q6.groups, { promoters: 1, passives: 1, detractors: 1 });
  const filt = (await alice.get(`/api/surveys/${sid}/results?fq=q1&fv=${encodeURIComponent("Năm 1")}`)).data;
  assert.equal(filt.n, 2); assert.equal(filt.total, 3);
  const resp = (await alice.get(`/api/surveys/${sid}/respondents`)).data;
  assert.deepEqual(resp.map(r => r.name).sort(), ["Bob Trần", "Carol Lê", "Quản trị viên"]);
  const csv = (await alice.get(`/api/surveys/${sid}/export`, { raw: true })).data;
  assert.ok(csv.startsWith("﻿") && csv.includes("Bob Trần") && csv.includes("bob@test.vn") && csv.includes("1. Bạn là sinh viên năm mấy?"));
  assert.equal(res.avg_duration, Math.round((95 + 86400) / 2), "thời gian TB: bỏ giá trị lỗi, chặn trên 1 ngày");
  const ind = (await alice.get(`/api/surveys/${sid}/responses`)).data;
  assert.equal(ind.total, 3); assert.deepEqual(ind.items.map(r => r.no), [3, 2, 1], "mới nhất trước");
  assert.equal(ind.items[2].name, "Bob Trần"); assert.equal(ind.items[2].duration, 95); assert.equal(ind.items[2].answers.q7, "Giá đắt quá");
  await expect(bob.get(`/api/surveys/${sid}/responses`), 403, "người khác không xem phản hồi cá nhân");
  ok("kết quả: thống kê 7 loại câu, NPS, lọc, thời gian làm bài, phản hồi cá nhân, danh sách người trả lời, xuất CSV (UTF-8 cho Excel)");

  await expect(carol.post(`/api/public/surveys/${linkOnly}/responses`, { answers: { q1: "Lớp nên học thêm" } }), 200, "trả lời ẩn danh");
  await expect(bob.get(`/api/surveys/${linkOnly}/respondents`), 403, "khảo sát ẩn danh không lộ danh tính");
  const indAnon = (await bob.get(`/api/surveys/${linkOnly}/responses`)).data;
  assert.equal(indAnon.items.length, 1); assert.ok(!("name" in indAnon.items[0]) && !("email" in indAnon.items[0]), "phản hồi cá nhân ẩn danh không có tên/email");
  const csvAnon = (await bob.get(`/api/surveys/${linkOnly}/export`, { raw: true })).data;
  assert.ok(!csvAnon.includes("Carol") && !csvAnon.includes("carol@test.vn") && csvAnon.includes("Lớp nên học thêm"));
  ok("khảo sát ẩn danh: không có danh sách người trả lời, CSV không có tên/email");

  // ---------- AI goi y + han muc ----------
  await expect(admin.post("/api/admin/users/2", { quota_gen: 1 }), 200, "admin đặt hạn mức cho Bob");
  const waits = [];
  const sug = await bob.ai("/api/ai/suggest", { purpose: "Đánh giá căng tin", count: 5 }, m => waits.push(m));
  assert.equal(sug.status, 200, JSON.stringify(sug.data));
  assert.ok(waits.length >= 1, "429 từ Groq → trình duyệt được báo chờ");
  assert.deepEqual(sug.data.questions[0].options, ["Năm 1", "Năm 2"]);
  assert.equal(sug.data.questions[2].type, "open_text", "dropdown chỉ 1 đáp án → đổi thành câu mở");
  assert.deepEqual(sug.data.quota.gen, { used: 1, limit: 1 });
  assert.equal(sug.data.topic, "gan_ket", "AI chọn chủ đề nhân sự");
  assert.ok(mock.prompts.at(-1).includes("phòng ban, thâm niên, cấp bậc"), "prompt gợi ý theo ngữ cảnh nhân sự");
  await expect(bob.post("/api/ai/suggest", { purpose: "Đánh giá căng tin", count: 5 }), 429, "hết lượt gợi ý");
  ok("AI gợi ý: chỉ trả câu hỏi mẫu (không tự lưu), tự chờ khi Groq 429, hạn mức theo người do admin chỉnh");

  // ---------- Phan tich ----------
  await expect(bob.post(`/api/surveys/${sid}/analyze/start`), 403, "Bob không phân tích khảo sát của Alice");
  await expect(alice.post(`/api/surveys/${sid}/analyze/themes`, { run: "sai", qid: "q7" }), 400, "run sai");
  const start = (await alice.post(`/api/surveys/${sid}/analyze/start`)).data;
  assert.deepEqual(start.open_questions, ["q7"]);
  const th = (await alice.ai(`/api/surveys/${sid}/analyze/themes`, { run: start.run, qid: "q7" })).data;
  assert.deepEqual(th.themes.map(t => [t.name, t.count]), [["Giá cả", 1], ["Vệ sinh", 1]]);
  assert.equal(th.no_content, 1);
  const a = (await alice.ai(`/api/surveys/${sid}/analyze/summary`, { run: start.run, segment: "q1", themes: { q7: th } })).data;
  assert.deepEqual(a.summary.highlights, [{ text: "Giá là vấn đề", evidence: ["C1", "q2"] }]);
  assert.equal(a.hr, true, "chủ đề nhân sự → phân tích nhân sự");
  assert.deepEqual(a.summary.retention_risk, { level: "cao", reason: "eNPS âm", evidence: ["q6"] });
  assert.deepEqual(a.summary.quick_actions, [{ text: "Gặp riêng nhóm năm 2", evidence: ["q1"] }]);
  assert.equal(a.summary.issues[0].severity, "cao");
  assert.ok(!mock.prompts.some(p => /Bob|Carol|bob@test|carol@test/.test(p)), "không gửi tên/email lên AI");
  assert.equal((await alice.get(`/api/surveys/${sid}`)).data.analysis.summary.summary, "Tóm tắt.");
  assert.equal((await alice.get("/api/my/quota")).data.ana.used, 1);
  ok("phân tích: theo phiên (run), bỏ mã bằng chứng sai, xếp mức nghiêm trọng, nguy cơ nghỉ việc + việc nên làm ngay, KHÔNG gửi tên/email lên AI");

  // ---------- Mau nhan su ----------
  const tpls = (await anon.get("/api/templates")).data;
  assert.equal(tpls.length, 20, "20 mẫu nhân sự");
  for (const t of tpls) {
    assert.ok(t.count >= 6 && t.count <= 10 && t.questions.length === t.count, `${t.key}: 6-10 câu`);
    assert.ok(t.topic !== "khac" && t.topic_label, `${t.key}: chủ đề nhân sự`);
    assert.ok(t.questions.some(q => q.type === "open_text"), `${t.key}: có câu mở`);
    assert.ok(t.questions.some(q => /phòng ban|bộ phận/.test(q.question)), `${t.key}: có câu phân nhóm`);
  }
  assert.equal(new Set(Object.keys((await anon.get("/api/topics")).data)).size, 7);
  await expect(carol.post("/api/surveys", { template: "khong_co" }), 400, "mẫu không tồn tại");
  for (let i = 0; i < 3; i++) await carol.post("/api/surveys", { template: "stay" });
  const { data: { id: fromTpl } } = await expect(carol.post("/api/surveys", { template: "exit" }), 200, "tạo từ mẫu");
  const ft = (await carol.get(`/api/surveys/${fromTpl}`)).data;
  assert.equal(ft.status, "draft"); assert.equal(ft.anonymous, true, "mẫu mặc định ẩn danh"); assert.equal(ft.topic, "nghi_viec");
  assert.equal(ft.questions.length, tpls.find(t => t.key === "exit").count);
  await expect(carol.post(`/api/surveys/${fromTpl}/publish`), 200, "đăng ngay bản tạo từ mẫu");
  const tp2 = (await anon.get("/api/templates")).data;
  assert.equal(tp2.find(t => t.key === "stay").used, 3); assert.equal(tp2.find(t => t.key === "stay").popular, true, "dùng ≥3 lần → phổ biến");
  assert.equal(tp2.find(t => t.key === "exit").popular, false);
  const { data: { id: fromAi } } = await carol.post("/api/surveys", { title: "Từ AI", topic: "gan_ket", purpose: "Hiểu nhân viên", anonymous: true,
    questions: sug.data.questions });
  const fa = (await carol.get(`/api/surveys/${fromAi}`)).data;
  assert.equal(fa.title, "Từ AI"); assert.equal(fa.purpose, "Hiểu nhân viên"); assert.equal(fa.questions.length, sug.data.questions.length);
  ok("mẫu nhân sự: 20 mẫu đủ điều kiện, tạo nháp ẩn danh từ mẫu, đếm lượt dùng → 'Phổ biến'; tạo bản nháp từ kết quả AI");

  // ---------- Phien ban ----------
  const rv = (await alice.post(`/api/surveys/${sid}/revise`)).data;
  assert.equal(rv.existing, false);
  assert.equal((await alice.post(`/api/surveys/${sid}/revise`)).data.id, rv.id, "chỉ 1 bản nháp mới cho mỗi khảo sát");
  assert.equal((await alice.get(`/api/surveys/${sid}`)).data.status, "published", "bản cũ vẫn nhận trả lời khi bản mới còn là nháp");
  await alice.put(`/api/surveys/${rv.id}`, { title: "Khảo sát Căng tin trường (v2)" });
  await alice.post(`/api/surveys/${rv.id}/publish`);
  const old = (await anon.get(`/api/public/surveys/${sid}`)).data;
  assert.equal(old.status, "closed"); assert.equal(old.successor, rv.id);
  await expect(new Client("10.5.0.1").post(`/api/public/surveys/${sid}/responses`, {}), 401, "");
  await expect(carol.post(`/api/public/surveys/${sid}/responses`, { answers: { q1: "Năm 1", q2: 3 } }), 403, "bản cũ đã đóng");
  const v2 = (await alice.get(`/api/surveys/${rv.id}`)).data;
  assert.equal(v2.version, 2); assert.equal(v2.responses, 0); assert.deepEqual(v2.versions.map(v => v.version), [1, 2]);
  ok("sửa nội dung: tạo bản mới (v2, 0 câu trả lời); bản cũ tự đóng khi bản mới được đăng và trỏ sang bản mới");

  // ---------- Bao cao & admin ----------
  await expect(bob.post(`/api/public/surveys/${rv.id}/report`, { reason: "Nội dung không phù hợp" }), 200, "báo cáo");
  await expect(bob.post(`/api/public/surveys/${rv.id}/report`, { reason: "Lần nữa nè" }), 409, "báo cáo trùng");
  for (const p of ["/api/admin/stats", "/api/admin/users", "/api/admin/surveys", "/api/admin/reports"]) {
    await expect(alice.get(p), 403, `người thường vào ${p}`);
  }
  const stats = (await admin.get("/api/admin/stats")).data;
  assert.equal(stats.users, 6); assert.equal(stats.open_reports, 1); assert.equal(stats.surveys.closed, 1);
  const reports = (await admin.get("/api/admin/reports")).data;
  assert.equal(reports[0].reporter_name, "Bob Trần");
  await admin.post(`/api/admin/surveys/${rv.id}`, { hidden: true });
  assert.equal((await anon.get("/api/search?q=cang")).data.items.length, 0, "bị ẩn khỏi tìm kiếm");
  assert.equal((await anon.get(`/api/public/surveys/${rv.id}`)).status, 200, "vẫn mở bằng link");
  await admin.post(`/api/admin/reports/${reports[0].id}`, { resolved: true });
  assert.equal((await admin.get("/api/admin/reports")).data.length, 0);
  assert.equal((await admin.get(`/api/surveys/${sid}/results`)).data.total, 3, "admin xem kết quả mọi khảo sát");
  ok("admin: chặn người thường, thống kê, báo cáo vi phạm, ẩn khỏi tìm kiếm, xem mọi khảo sát");

  await expect(admin.post("/api/admin/users/4", { locked: true }), 400, "không khóa admin");
  await admin.post("/api/admin/users/2", { locked: true });
  await expect(bob.get("/api/my/surveys"), 401, "Bob bị đăng xuất ngay");
  env.DB.db.exec("DELETE FROM hits"); // gia lap 15 phut da qua (email Bob bi khoa do kiem thu do mat khau o tren)
  await expect(new Client("10.0.0.8").post("/api/login", { email: "bob@test.vn", password: "matkhau123" }), 403, "Bob không đăng nhập được");
  await expect(anon.get(`/api/public/surveys/${linkOnly}`), 404, "khảo sát của người bị khóa bị ẩn");
  assert.equal(await googleLogin(new Client("10.0.0.10"), { sub: "g-bob", email: "bob@test.vn" }), "/login?error=locked", "bị khóa: Google cũng không vào được");
  await admin.post("/api/admin/users/2", { locked: false });
  ok("khóa tài khoản: đăng xuất ngay, không đăng nhập được, khảo sát bị ẩn; mở khóa lại được");

  await expect(admin.post(`/api/surveys/${linkOnly}/delete`), 200, "admin xóa khảo sát");
  await expect(anon.get(`/api/public/surveys/${linkOnly}`), 404, "đã xóa");
  await alice.post("/api/logout");
  await expect(alice.get("/api/my/surveys"), 401, "đăng xuất");
  ok("admin xóa khảo sát; đăng xuất xóa phiên trên server");
}

// ------------------------------------------------------- hop thu gop y ----
async function feedbackTests() {
  console.log("== Hộp thư góp ý");
  const anon = new Client("10.0.3.9");
  const hr = await register("Hà HR", "hr@test.vn", "10.0.3.1");
  const nv1 = await register("Nhân viên Một", "nv1@test.vn", "10.0.3.2");
  const nv2 = await register("Nhân viên Hai", "nv2@test.vn", "10.0.3.3");
  const other = await register("HR Khác", "hr2@test.vn", "10.0.3.4");
  const admin = await loginAs(ADMIN_USER, ADMIN_PASS, "10.0.3.8");
  const hrId = env.DB.db.prepare("SELECT id FROM users WHERE email = 'hr@test.vn'").get().id;

  // ---- Chi tai khoan HR moi tao hop thu ----
  let r = await expect(hr.get("/api/fb/boxes"), 403, "chưa có quyền HR");
  assert.match(r.data.error, /Chỉ tài khoản HR/);
  await expect(hr.post("/api/fb/boxes", { name: "Phòng A" }), 403, "chưa có quyền HR: không tạo được");
  assert.equal((await hr.get("/api/me")).data.user.can_feedback, false);
  await expect(hr.post(`/api/admin/users/${hrId}`, { hr: true }), 403, "người thường không tự cấp quyền");
  await expect(admin.post(`/api/admin/users/${hrId}`, { hr: true }), 200, "admin cấp quyền HR");
  assert.equal((await hr.get("/api/me")).data.user.can_feedback, true);
  ok("chỉ tài khoản HR (do admin cấp quyền) mới tạo được hộp thư");

  // ---- HR tao hop thu ----
  r = await expect(hr.get("/api/fb/boxes"), 200, "danh sách hộp thư");
  const hub = r.data.hub;
  assert.match(hub, /^[a-f0-9]{10}$/); assert.equal(r.data.boxes.length, 0);
  assert.equal((await hr.get("/api/fb/boxes")).data.hub, hub, "link chung cố định");
  await expect(hr.post("/api/fb/boxes", { name: "A" }), 400, "tên quá ngắn");
  const kt = (await expect(hr.post("/api/fb/boxes", { name: "Phòng Kỹ thuật", description: "Góp ý cho phòng KT" }), 200, "tạo hộp")).data.id;
  const kd = (await expect(hr.post("/api/fb/boxes", { name: "Phòng Kinh doanh" }), 200, "tạo hộp 2")).data.id;
  await expect(hr.post("/api/fb/boxes", { name: "Phòng Kỹ thuật" }), 409, "trùng tên");
  await expect(hr.post("/api/fb/hub", { title: "  Công ty   ABC " }), 200, "đặt tên");
  await expect(anon.post("/api/fb/boxes", { name: "X y" }), 401, "khách không tạo được");
  await expect(other.post(`/api/fb/boxes/${kt}`, { status: "closed" }), 403, "người khác không sửa được");
  await admin.post(`/api/admin/users/${env.DB.db.prepare("SELECT id FROM users WHERE email = 'hr2@test.vn'").get().id}`, { hr: true });
  await expect(other.post(`/api/fb/boxes/${kt}`, { status: "closed" }), 404, "HR khác không sửa được");
  await expect(other.get(`/api/fb/letters?box=${kt}`), 404, "HR khác không đọc được");
  ok("HR tạo hộp thư theo phòng ban, link chung cố định, đặt tên công ty; người khác không đụng được");

  // ---- Nhan vien vao link chung, gui thu ----
  r = await expect(anon.get(`/api/fb/hub/${hub}`), 200, "link chung (công khai)");
  assert.equal(r.data.title, "Công ty ABC");
  assert.deepEqual(r.data.boxes.map(b => b.name).sort(), ["Phòng Kinh doanh", "Phòng Kỹ thuật"]);
  r = await expect(anon.get(`/api/fb/box/${kt}`), 200, "trang hộp thư");
  assert.equal(r.data.viewer.logged_in, false); assert.equal(r.data.title, "Công ty ABC");
  await expect(anon.post(`/api/fb/box/${kt}/letters`, { content: "Nội dung góp ý đủ dài" }), 401, "phải đăng nhập");
  await expect(hr.post(`/api/fb/box/${kt}/letters`, { content: "Tự gửi cho mình xem sao" }), 403, "HR không tự gửi");
  await expect(nv1.post(`/api/fb/box/${kt}/letters`, { content: "ngắn" }), 400, "quá ngắn");
  await expect(nv1.post(`/api/fb/box/${kt}/letters`, { content: "x".repeat(2001) }), 400, "quá dài");
  const send = (c, box, content, topic = "khac") => expect(c.post(`/api/fb/box/${box}/letters`, { content, topic }), 200, "gửi thư");
  await send(nv1, kt, "Lương thấp quá, không đủ sống", "luong_thuong");
  await send(nv1, kt, "Sếp la mắng trước mặt mọi người, rất bức xúc", "quan_ly");
  await send(nv1, kt, "Máy lạnh hỏng hai tuần rồi, làm việc rất tệ", "moi_truong");
  await send(nv1, kd, "Cảm ơn công ty đã tổ chức du lịch", "khac");
  await send(nv1, kd, "Đề xuất mua thêm bàn ghế phòng họp", "moi_truong");
  await expect(nv1.post(`/api/fb/box/${kd}/letters`, { content: "Thư thứ sáu trong ngày" }), 429, "tối đa 5 thư/ngày");
  await send(nv2, kd, "Mong được tăng lương theo năng lực");      // chu de "Khac" -> AI gan "Luong thuong"
  await send(nv2, kd, "Thư này AI sẽ BỎ QUA khi chấm");
  await send(nv2, kd, "Thư này AI trả SAI ĐIỂM ngoài thang");
  r = await expect(nv1.get(`/api/fb/box/${kt}`), 200, "đếm thư hôm nay");
  assert.equal(r.data.viewer.sent_today, 5);
  ok("nhân viên vào link chung, chọn đúng hộp thư; phải đăng nhập, giới hạn 5 thư/ngày, HR không tự gửi");

  // ---- HR doc thu: KHONG co thong tin nguoi gui ----
  r = await expect(hr.get("/api/fb/letters"), 200, "HR đọc thư");
  assert.equal(r.data.total, 8);
  const raw = JSON.stringify(r.data);
  for (const leak of ["nv1@test.vn", "nv2@test.vn", "Nhân viên Một", "user_id", "created"]) assert.ok(!raw.includes(leak), `lộ thông tin: ${leak}`);
  assert.match(r.data.items[0].day, /^\d{4}-\d{2}-\d{2}$/);
  r = await expect(hr.get(`/api/fb/letters?box=${kt}&topic=quan_ly`), 200, "lọc");
  assert.equal(r.data.total, 1); assert.equal(r.data.items[0].box_name, "Phòng Kỹ thuật");
  const boxes = (await hr.get("/api/fb/boxes")).data.boxes;
  assert.deepEqual(boxes.map(b => [b.n, b.n_new]), [[3, 3], [5, 5]]);
  ok("HR đọc thư, lọc theo hộp/chủ đề: không có tên, email, mã người gửi hay giờ gửi");

  // ---- Trang thai, tra loi, an ----
  const letter = (await hr.get(`/api/fb/letters?box=${kt}&topic=luong_thuong`)).data.items[0];
  r = await expect(hr.post(`/api/fb/letters/${letter.id}`, { status: "done", reply: "Công ty sẽ xem xét lại lương vào tháng 1." }), 200, "trả lời");
  assert.equal(r.data.status, "done"); assert.equal(r.data.reply, "Công ty sẽ xem xét lại lương vào tháng 1.");
  await expect(other.post(`/api/fb/letters/${letter.id}`, { status: "doing" }), 404, "HR khác không sửa được thư");
  await expect(nv1.post(`/api/fb/letters/${letter.id}`, { status: "doing" }), 403, "người gửi không đổi trạng thái");
  r = await expect(nv1.get("/api/fb/mine"), 200, "thư tôi đã gửi");
  assert.equal(r.data.length, 5);
  const mineL = r.data.find(x => x.content.startsWith("Lương thấp"));
  assert.equal(mineL.status, "done"); assert.equal(mineL.reply, "Công ty sẽ xem xét lại lương vào tháng 1."); assert.equal(mineL.title, "Công ty ABC");
  assert.equal((await nv2.get("/api/fb/mine")).data.length, 3, "chỉ thấy thư của mình");
  ok("HR đổi trạng thái và trả lời; người gửi thấy câu trả lời ở \"Thư tôi đã gửi\" (vẫn ẩn danh với HR)");

  // ---- AI cham diem + tong ket ----
  await expect(hr.post("/api/fb/analyze/start", { scope: "zzz", period: "30" }), 400, "phạm vi sai");
  await expect(hr.post("/api/fb/analyze/start", { scope: "all", period: "7" }), 400, "khoảng thời gian sai");
  await expect(hr.post("/api/fb/analyze/score", { run: "x", scope: "all", period: "30" }), 400, "phiên sai");
  const st = (await expect(hr.post("/api/fb/analyze/start", { scope: "all", period: "30" }), 200, "bắt đầu")).data;
  assert.equal(st.total, 8); assert.equal(st.unscored, 8);
  let sc = (await hr.ai("/api/fb/analyze/score", { run: st.run, scope: "all", period: "30" })).data;
  assert.equal(sc.scored, 6, JSON.stringify(sc)); assert.equal(sc.remaining, 2, "2 thư AI chấm hỏng → còn lại");
  await expect(other.post("/api/fb/analyze/score", { run: st.run, scope: "all", period: "30" }), 400, "người khác không dùng được phiên");
  const a = (await hr.ai("/api/fb/analyze/summary", { run: st.run, scope: "all", period: "30", usage: sc.usage })).data;
  assert.equal(a.scope_name, "Tất cả phòng ban"); assert.equal(a.n, 8); assert.equal(a.scored, 6);
  assert.deepEqual(a.summary.issues.map(i => i.text), ["Quản lý la mắng", "Lương thấp"], "bỏ mục không có bằng chứng, xếp theo mức nghiêm trọng");
  assert.ok(a.summary.issues[1].evidence.every(c => a.quotes[c]), "mỗi bằng chứng đều có trích dẫn thư");
  assert.equal(a.summary.retention_risk.level, "cao");
  assert.deepEqual(a.summary.departments.map(d => d.name).filter(n => n === "Phòng Ma"), [], "bỏ phòng ban AI bịa");
  assert.ok(["Phòng Kỹ thuật", "Phòng Kinh doanh"].includes(a.summary.focus?.name));
  assert.equal(a.usage.calls, 2);
  const prompt = mock.prompts.at(-1);
  for (const leak of ["nv1@test.vn", "Nhân viên Một", "Hà HR"]) assert.ok(!prompt.includes(leak), `gửi thông tin định danh cho AI: ${leak}`);
  assert.equal((await hr.get("/api/fb/analysis?scope=all&period=30")).data.analysis.n, 8, "lưu lại kết quả");
  ok("AI chấm từng thư (lưu lại, bỏ điểm sai), tổng kết có bằng chứng; bỏ phòng ban bịa; không gửi danh tính cho AI");

  // ---- Bieu do: tinh bang code tu diem tung thu ----
  let s = (await expect(hr.get("/api/fb/stats?scope=all&period=30"), 200, "thống kê")).data;
  assert.equal(s.n, 8); assert.equal(s.scored, 6);
  assert.deepEqual(s.dist, { 1: 2, 2: 0, 3: 3, 4: 0, 5: 1 });
  assert.equal(s.mean, 2.67); assert.equal(s.neg_pct, 33);
  assert.equal(s.by_topic.find(t => t.key === "luong_thuong").n, 2, "thư chủ đề Khác được AI gán sang Lương thưởng");
  const bkt = s.by_box.find(b => b.name === "Phòng Kỹ thuật");
  assert.deepEqual([bkt.n, bkt.mean, bkt.neg_pct], [3, 1.67, 67]);
  assert.equal(s.trend.length, 1); assert.equal(s.unit, "week");
  r = await expect(hr.get(`/api/fb/letters?sat=1`), 200, "bấm cột biểu đồ → danh sách thư");
  assert.equal(r.data.total, 2);
  // HR sua diem -> bieu do cap nhat
  const neutral = (await hr.get(`/api/fb/letters?box=${kd}&sat=3`)).data.items[0];
  await expect(hr.post(`/api/fb/letters/${neutral.id}`, { sat: 7 }), 400, "điểm ngoài thang");
  r = await expect(hr.post(`/api/fb/letters/${neutral.id}`, { sat: 2 }), 200, "HR sửa điểm");
  assert.equal(r.data.sat_by, "hr");
  s = (await hr.get("/api/fb/stats?scope=all&period=30")).data;
  assert.deepEqual(s.dist, { 1: 2, 2: 1, 3: 2, 4: 0, 5: 1 });
  // An thu -> khong tinh
  await expect(hr.post(`/api/fb/letters/${neutral.id}`, { hidden: true }), 200, "ẩn thư");
  assert.equal((await hr.get("/api/fb/stats?scope=all&period=30")).data.n, 7);
  assert.equal((await hr.get("/api/fb/letters?hidden=1")).data.total, 1);
  // Phan tich rieng mot phong ban
  const st2 = (await hr.post("/api/fb/analyze/start", { scope: kt, period: "all" })).data;
  assert.equal(st2.unscored, 0, "thư đã chấm không chấm lại (tiết kiệm token)");
  const a2 = (await hr.ai("/api/fb/analyze/summary", { run: st2.run, scope: kt, period: "all" })).data;
  assert.equal(a2.scope_name, "Phòng Kỹ thuật"); assert.deepEqual(a2.summary.departments, []); assert.equal(a2.summary.focus, null);
  ok("biểu đồ tính bằng code: phân bố, chỉ số, theo chủ đề/phòng ban/thời gian; HR sửa điểm, ẩn thư → cập nhật; phân tích từng phòng");

  // ---- Dong hop, admin, xoa ----
  await expect(hr.post(`/api/fb/boxes/${kd}`, { status: "closed" }), 200, "đóng hộp");
  await expect(nv2.post(`/api/fb/box/${kd}/letters`, { content: "Gửi vào hộp đã đóng" }), 403, "hộp đóng");
  r = await expect(admin.get(`/api/fb/boxes?owner=${hrId}`), 200, "admin xem hộp thư của HR");
  assert.equal(r.data.boxes.length, 2); assert.equal(r.data.is_own, false);
  await expect(nv1.get(`/api/fb/boxes?owner=${hrId}`), 403, "người thường không dùng được ?owner=");
  assert.equal((await admin.get("/api/admin/users?q=hr@test.vn")).data[0].boxes, 2);
  await expect(hr.post(`/api/fb/boxes/${kd}/delete`), 200, "xóa hộp");
  assert.equal((await hr.get("/api/fb/letters?hidden=1")).data.total, 0, "xóa hộp xóa luôn thư");
  assert.equal((await nv2.get("/api/fb/mine")).data.length, 0);
  await expect(anon.get(`/api/fb/box/${kd}`), 404, "hộp đã xóa");
  ok("đóng hộp không nhận thư; admin xem được qua ?owner=; xóa hộp xóa luôn thư");

  // ---- Go quyen HR: van quan ly hop cu, khong tao hop moi ----
  await admin.post(`/api/admin/users/${hrId}`, { hr: false });
  r = await expect(hr.get("/api/fb/boxes"), 200, "vẫn quản lý hộp cũ");
  assert.equal(r.data.can_create, false); assert.equal((await hr.get("/api/me")).data.user.can_feedback, true);
  await expect(hr.post("/api/fb/boxes", { name: "Phòng Mới" }), 403, "không tạo hộp mới");
  await expect(hr.get("/api/fb/letters"), 200, "vẫn đọc thư");
  ok("gỡ quyền HR: không tạo hộp mới nhưng vẫn quản lý hộp thư đã tạo");
}

// ------------------------------------------------- tai khoan HR do admin tao ----
async function accountTests() {
  console.log("== Tài khoản HR do admin tạo, đổi mật khẩu");
  const admin = await loginAs(ADMIN_USER, ADMIN_PASS, "10.0.4.1");
  const user = await register("Người thường", "thuong@test.vn", "10.0.4.2");
  await expect(user.post("/api/admin/users", { username: "Hr_x", name: "HR X", password: "matkhau123" }), 403, "người thường không tạo tài khoản");
  await expect(admin.post("/api/admin/users", { username: "a b", name: "HR", password: "matkhau123" }), 400, "tên đăng nhập sai");
  await expect(admin.post("/api/admin/users", { username: "Hr_account", name: "H", password: "matkhau123" }), 400, "tên hiển thị ngắn");
  await expect(admin.post("/api/admin/users", { username: "Hr_account", name: "Phòng Nhân sự", password: "ngan" }), 400, "mật khẩu ngắn");
  const { data: { id } } = await expect(admin.post("/api/admin/users", { username: "Hr_account", name: "Phòng Nhân sự", password: "Hr-mat-khau-1" }), 200, "tạo HR");
  await expect(admin.post("/api/admin/users", { username: "hr_ACCOUNT", name: "Trùng", password: "matkhau123" }), 409, "trùng tên (khác hoa thường)");
  await expect(new Client("10.0.4.3").post("/api/login", { email: "hr_account", password: "Hr-mat-khau-1" }), 401, "phân biệt hoa thường");
  const hr = await loginAs("Hr_account", "Hr-mat-khau-1", "10.0.4.3");
  let me = (await hr.get("/api/me")).data.user;
  assert.deepEqual([me.username, me.role, me.is_hr, me.is_admin, me.email, me.needs_terms], ["Hr_account", "hr", true, false, "@Hr_account", true]);
  await expect(hr.get("/api/admin/stats"), 403, "HR không phải admin");
  await expect(hr.post("/api/fb/boxes", { name: "Phòng Kế toán" }), 200, "HR tạo hộp thư");
  const list = (await admin.get("/api/admin/users?q=hr_account")).data;
  assert.equal(list[0].username, "Hr_account"); assert.equal(list[0].is_hr, true);
  // Doi mat khau
  await expect(hr.post("/api/me/password", { current: "sai-mat-khau", password: "Moi-mat-khau-2" }), 400, "sai mật khẩu hiện tại");
  await expect(hr.post("/api/me/password", { current: "Hr-mat-khau-1", password: "ngan" }), 400, "mật khẩu mới ngắn");
  const hr2 = await loginAs("Hr_account", "Hr-mat-khau-1", "10.0.4.4"); // phien thu 2
  await expect(hr.post("/api/me/password", { current: "Hr-mat-khau-1", password: "Moi-mat-khau-2" }), 200, "đổi mật khẩu");
  await expect(hr.get("/api/me/../my/quota"), 200, "phiên hiện tại vẫn giữ");
  await expect(hr2.get("/api/my/quota"), 401, "phiên khác bị đăng xuất");
  await expect(new Client("10.0.4.5").post("/api/login", { email: "Hr_account", password: "Hr-mat-khau-1" }), 401, "mật khẩu cũ hết hiệu lực");
  await loginAs("Hr_account", "Moi-mat-khau-2", "10.0.4.5");
  // Admin dat lai mat khau
  const uid = env.DB.db.prepare("SELECT id FROM users WHERE email = 'thuong@test.vn'").get().id;
  await expect(admin.post(`/api/admin/users/${uid}`, { password: "matkhau999" }), 400, "không đặt lại mật khẩu tài khoản email");
  await expect(admin.post(`/api/admin/users/${id}`, { password: "Dat-lai-3" }), 200, "đặt lại mật khẩu HR");
  await expect(hr.get("/api/my/quota"), 401, "đặt lại → đăng xuất mọi phiên");
  await loginAs("Hr_account", "Dat-lai-3", "10.0.4.6");
  const adminId = env.DB.db.prepare("SELECT id FROM users WHERE username = ?").get(ADMIN_USER).id;
  await expect(admin.post(`/api/admin/users/${adminId}`, { hr: false }), 400, "admin luôn có quyền HR");
  await expect(admin.post(`/api/admin/users/${adminId}`, { password: "x12345678" }), 400, "không đặt lại mật khẩu admin ở đây");
  await expect(admin.post(`/api/admin/users/${adminId}`, { locked: true }), 400, "không khóa admin");
  await expect(admin.post("/api/me/password", { current: ADMIN_PASS, password: "Admin-moi-9" }), 200, "admin tự đổi mật khẩu");
  ok("admin tạo tài khoản HR (tên đăng nhập phân biệt hoa thường, chống trùng), đổi mật khẩu (đăng xuất phiên khác), admin đặt lại mật khẩu HR");
}

// ------------------------------------------------------------- han chot ----
async function deadlineTests() {
  console.log("== Hạn chót tự đóng, mở lại");
  const own = await register("Chủ KS", "chu@test.vn", "10.0.5.1"), resp = await register("Người TL", "tl@test.vn", "10.0.5.2");
  const { data: { id } } = await own.post("/api/surveys", { template: "pulse" });
  await expect(own.post(`/api/surveys/${id}/deadline`, { closes_at: null }), 409, "nháp: chưa đặt hạn chót");
  await expect(own.post(`/api/surveys/${id}/publish`), 200, "đăng");
  const now = Math.floor(Date.now() / 1000);
  await expect(own.post(`/api/surveys/${id}/deadline`, { closes_at: now - 10 }), 400, "hạn chót trong quá khứ");
  await expect(own.post(`/api/surveys/${id}/deadline`, { closes_at: now + 400 * 86400 }), 400, "quá 1 năm");
  await expect(resp.post(`/api/surveys/${id}/deadline`, { closes_at: now + 86400 }), 403, "người khác không đặt");
  await expect(own.post(`/api/surveys/${id}/deadline`, { closes_at: now + 3 * 86400 }), 200, "đặt hạn chót");
  let pub = (await resp.get(`/api/public/surveys/${id}`)).data;
  assert.equal(pub.closes_at, now + 3 * 86400); assert.equal(pub.status, "published");
  assert.equal((await own.get("/api/my/surveys")).data.find(x => x.id === id).closes_at, now + 3 * 86400);
  // Gia lap: da qua han chot
  env.DB.db.prepare("UPDATE surveys SET closes_at = ? WHERE id = ?").run(now - 5, id);
  pub = (await resp.get(`/api/public/surveys/${id}`)).data;
  assert.equal(pub.status, "closed", "quá hạn → tự đóng");
  const q = (await own.get(`/api/surveys/${id}`)).data;
  assert.equal(q.closed_at, now - 5, "giờ đóng = hạn chót");
  const answers = Object.fromEntries(q.questions.filter(x => x.required).map(x => [x.id, x.options?.[0] ?? 3]));
  await expect(resp.post(`/api/public/surveys/${id}/responses`, { answers }), 403, "đã đóng: không nhận trả lời");
  await expect(own.post(`/api/surveys/${id}/reopen`, { closes_at: now - 1 }), 400, "mở lại với hạn chót quá khứ");
  await expect(own.post(`/api/surveys/${id}/reopen`, { closes_at: now + 7 * 86400 }), 200, "mở lại + gia hạn");
  pub = (await resp.get(`/api/public/surveys/${id}`)).data;
  assert.equal(pub.status, "published"); assert.equal(pub.closes_at, now + 7 * 86400);
  await expect(resp.post(`/api/public/surveys/${id}/responses`, { answers }), 200, "mở lại: nhận trả lời");
  await expect(own.post(`/api/surveys/${id}/deadline`, { closes_at: null }), 200, "bỏ hạn chót");
  assert.equal((await own.get(`/api/surveys/${id}`)).data.closes_at, null);
  await expect(own.post(`/api/surveys/${id}/reopen`, {}), 409, "đang mở thì không mở lại");
  // Co phien ban moi da dang -> khong mo lai ban cu
  const v2 = (await own.post(`/api/surveys/${id}/revise`)).data.id;
  await expect(own.post(`/api/surveys/${v2}/publish`), 200, "đăng v2");
  await expect(own.post(`/api/surveys/${id}/reopen`, {}), 409, "đã có phiên bản mới");
  ok("hạn chót: kiểm tra thời điểm, tự đóng khi quá hạn (không cần tác vụ định kỳ), mở lại + gia hạn, bỏ hạn chót; bản cũ có bản mới thì không mở lại");
}

async function realRun() {
  console.log("== Groq THẬT: AI gợi ý 10 câu → đăng → 30 người trả lời → phân tích");
  const alice = await register("Alice", "alice@test.vn", "10.0.0.1");
  let t = Date.now();
  const sug = (await alice.ai("/api/ai/suggest", { purpose: "Tìm hiểu vì sao nhân viên muốn nghỉ việc và điều gì giữ chân họ",
    audience: "nhân viên văn phòng", decision: "Có nên điều chỉnh lương thưởng năm sau không", count: 10 }, console.log)).data;
  assert.ok(sug.questions, JSON.stringify(sug));
  console.log(`Gợi ý (${((Date.now() - t) / 1000).toFixed(1)}s): ${sug.title} · chủ đề ${sug.topic}`);
  for (const q of sug.questions) console.log(`  ${q.id} [${q.type}] ${q.question} ${q.options.length ? JSON.stringify(q.options) : ""}`);
  const { data: { id } } = await alice.post("/api/surveys", {});
  await expect(alice.put(`/api/surveys/${id}`, { title: sug.title, description: sug.description, questions: sug.questions, topic: sug.topic }), 200, "lưu");
  await expect(alice.post(`/api/surveys/${id}/publish`), 200, "đăng");
  const pool = ["Lương thấp hơn thị trường", "Không thấy lộ trình thăng tiến", "Quản lý ít phản hồi", "Đồng nghiệp rất thân thiện",
    "Làm thêm giờ quá nhiều", "Muốn được làm từ xa 1-2 ngày/tuần", "Cần đào tạo kỹ năng mới", "Không có ý kiến", "Áp lực doanh số cao"];
  let seed = 7;
  const pick = (arr) => arr[Math.floor(((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648) * arr.length)];
  for (let i = 0; i < 30; i++) {
    const c = await register(`Người ${i}`, `u${i}@test.vn`, `10.9.${i}.1`);
    const answers = {};
    for (const q of sug.questions) {
      if (["single_choice", "dropdown"].includes(q.type)) answers[q.id] = pick(q.options);
      else if (q.type === "multiple_choice") answers[q.id] = [pick(q.options), pick(q.options)];
      else if (["scale", "rating"].includes(q.type)) answers[q.id] = pick([1, 2, 3, 3, 4, 4, 4, 5]);
      else if (q.type === "nps") answers[q.id] = pick([2, 5, 7, 8, 9, 10]);
      else answers[q.id] = pick(pool);
    }
    await expect(c.post(`/api/public/surveys/${id}/responses`, { answers }), 200, "trả lời");
  }
  t = Date.now();
  const start = (await alice.post(`/api/surveys/${id}/analyze/start`)).data;
  const themes = {}, usage = { tokens: 0, calls: 0 };
  for (const qid of start.open_questions) {
    const r = (await alice.ai(`/api/surveys/${id}/analyze/themes`, { run: start.run, qid }, console.log)).data;
    assert.ok(r.themes, JSON.stringify(r));
    themes[qid] = r; usage.tokens += r.usage.tokens; usage.calls += r.usage.calls;
  }
  const seg = sug.questions[0].type === "single_choice" ? sug.questions[0].id : "";
  const a = (await alice.ai(`/api/surveys/${id}/analyze/summary`, { run: start.run, themes, segment: seg, usage }, console.log)).data;
  assert.ok(a.summary, JSON.stringify(a));
  console.log(`\nPhân tích xong sau ${((Date.now() - t) / 1000).toFixed(1)}s · ${a.usage.tokens} token · ${a.usage.calls} lần gọi`);
  for (const st of a.stats.filter(st => st.themes)) console.log(`[${st.id}] ` + st.themes.map(t => `${t.code} ${t.name} (${t.count})`).join(" | "));
  console.log("TÓM TẮT:", a.summary.summary);
  console.log("NGUY CƠ NGHỈ VIỆC:", JSON.stringify(a.summary.retention_risk));
  console.log("VIỆC NÊN LÀM NGAY:", (a.summary.quick_actions || []).map(x => x.text + " " + JSON.stringify(x.evidence)).join(" | "));
  assert.equal(a.hr, sug.topic !== "khac");
}

if (REAL) await realRun(); else { await mainTests(); await feedbackTests(); await accountTests(); await deadlineTests(); }
console.log("\nTất cả kiểm thử đều đạt.");
