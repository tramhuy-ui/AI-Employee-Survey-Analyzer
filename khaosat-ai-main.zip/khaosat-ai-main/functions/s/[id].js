// Link tra loi cong khai /s/<id> -> trang answer.html (trang tu doc id tu duong dan)
export const onRequest = ({ request, env }) => env.ASSETS.fetch(new URL("/answer", request.url));
