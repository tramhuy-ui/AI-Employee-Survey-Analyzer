// Thu vien mau khao sat nhan su (giu chan nhan vien). Mau viet san trong code, khong ton luot AI.
// Moi mau: mac dinh an danh + co cau phan nhom (phong ban, tham nien, cap bac) de so sanh theo nhom.

const DEPT = ["Kinh doanh / Bán hàng", "Marketing", "Kỹ thuật / Công nghệ", "Sản xuất / Vận hành", "Hành chính / Nhân sự / Kế toán", "Khác"];
const seg = {
  dept: { question: "Bạn thuộc phòng ban / bộ phận nào?", type: "single_choice", options: DEPT, required: true },
  tenure: { question: "Bạn đã làm việc ở công ty được bao lâu?", type: "single_choice",
    options: ["Dưới 6 tháng", "6 tháng – 1 năm", "1 – 3 năm", "3 – 5 năm", "Trên 5 năm"], required: true },
  level: { question: "Cấp bậc hiện tại của bạn?", type: "single_choice",
    options: ["Nhân viên", "Trưởng nhóm / Giám sát", "Quản lý cấp trung trở lên"], required: true },
};
const SEG3 = [seg.dept, seg.tenure, seg.level];

const agree = (question) => ({ question, type: "scale", scale: ["Rất không đồng ý", "Rất đồng ý"] });
const scale = (question, lo, hi) => ({ question, type: "scale", scale: [lo, hi] });
const single = (question, options) => ({ question, type: "single_choice", options });
const multi = (question, options) => ({ question, type: "multiple_choice", options });
const rating = (question) => ({ question, type: "rating" });
const nps = (question) => ({ question, type: "nps" });
const open = (question) => ({ question, type: "open_text" });

const ENPS = "Bạn có sẵn lòng giới thiệu công ty là nơi đáng làm việc cho bạn bè, người thân không?";

const LIST = [
  // ------------------------------------------------ Tuyen dung & hoi nhap ----
  { key: "ung_vien", topic: "tuyen_dung", title: "Trải nghiệm ứng viên sau phỏng vấn",
    description: "Tìm hiểu ứng viên cảm nhận thế nào về quy trình tuyển dụng để cải thiện hình ảnh nhà tuyển dụng.",
    questions: [
      { ...single("Vị trí bạn ứng tuyển thuộc bộ phận nào?", DEPT), required: true },
      single("Bạn biết đến vị trí này qua kênh nào?", ["Website tuyển dụng của công ty", "Trang việc làm (TopCV, VietnamWorks…)",
        "Mạng xã hội (Facebook, LinkedIn…)", "Người quen giới thiệu", "Khác"]),
      agree("Thông tin về vị trí và quy trình tuyển dụng được truyền đạt rõ ràng."),
      agree("Thời gian chờ phản hồi sau mỗi vòng là hợp lý."),
      rating("Bạn đánh giá thế nào về sự chuyên nghiệp của người phỏng vấn?"),
      nps("Bạn có sẵn lòng giới thiệu bạn bè ứng tuyển vào công ty không?"),
      open("Chúng tôi có thể cải thiện điều gì trong quy trình tuyển dụng?"),
    ] },
  { key: "hoi_nhap_30", topic: "tuyen_dung", title: "Hội nhập sau 30 ngày",
    description: "Dành cho nhân viên mới sau tháng đầu tiên: đã được hướng dẫn đủ chưa, công việc có đúng như mong đợi không.",
    questions: [
      seg.dept, seg.level,
      agree("Tôi được hướng dẫn đầy đủ về công việc trong những ngày đầu."),
      agree("Công việc thực tế đúng với mô tả khi tuyển dụng."),
      agree("Tôi cảm thấy được đồng nghiệp chào đón."),
      multi("Bạn còn thiếu điều gì để làm tốt công việc? (có thể chọn nhiều)", ["Tài liệu hướng dẫn", "Công cụ / thiết bị",
        "Sự hỗ trợ từ quản lý", "Đào tạo kỹ năng", "Hiểu rõ mục tiêu công việc", "Không thiếu gì"]),
      open("Điều gì khiến bạn bất ngờ (tích cực hoặc tiêu cực) trong tháng đầu tiên?"),
      open("Công ty nên cải thiện gì trong quá trình đón nhân viên mới?"),
    ] },
  { key: "hoi_nhap_90", topic: "tuyen_dung", title: "Hội nhập sau 90 ngày",
    description: "Sau 3 tháng: nhân viên mới đã quen việc chưa, quan hệ với quản lý ra sao và có dự định ở lại không.",
    questions: [
      seg.dept, seg.level,
      agree("Tôi đã nắm vững công việc của mình."),
      agree("Quản lý trực tiếp thường xuyên trao đổi và phản hồi cho tôi."),
      agree("Tôi hiểu công việc của mình đóng góp gì cho mục tiêu chung."),
      rating("Bạn đánh giá trải nghiệm 3 tháng đầu ở công ty thế nào?"),
      single("Bạn dự định gắn bó với công ty trong bao lâu?", ["Dưới 6 tháng nữa", "6 – 12 tháng", "1 – 2 năm", "Trên 2 năm", "Chưa chắc chắn"]),
      open("Điều gì sẽ giúp bạn gắn bó lâu dài hơn với công ty?"),
    ] },

  // ------------------------------------------------------------- Gan ket ----
  { key: "enps", topic: "gan_ket", title: "Gắn kết nhân viên định kỳ (eNPS)",
    description: "Đo mức độ gắn kết bằng chỉ số eNPS và tìm lý do đằng sau điểm số. Nên làm 6 tháng một lần.",
    questions: [
      ...SEG3,
      nps(ENPS),
      agree("Tôi tự hào khi nói mình làm việc ở công ty."),
      agree("Tôi có động lực để nỗ lực hơn mức được yêu cầu."),
      agree("Tôi thấy mình vẫn sẽ làm việc ở đây sau 1 năm nữa."),
      open("Lý do chính cho điểm số bạn chọn ở câu giới thiệu công ty là gì?"),
      open("Một điều công ty nên thay đổi ngay để bạn gắn bó hơn?"),
    ] },
  { key: "pulse", topic: "gan_ket", title: "Khảo sát nhanh hàng tháng (pulse)",
    description: "Vài câu hỏi nhanh mỗi tháng về tinh thần, khối lượng việc và sự hỗ trợ, để phát hiện vấn đề sớm.",
    questions: [
      seg.dept, seg.tenure,
      rating("Tinh thần làm việc của bạn trong tháng này thế nào?"),
      scale("Khối lượng công việc tháng này của bạn?", "Rất nhẹ", "Quá tải"),
      agree("Tôi nhận được đủ sự hỗ trợ để hoàn thành công việc."),
      agree("Tôi được ghi nhận khi làm tốt."),
      open("Có điều gì đang cản trở bạn trong công việc tháng này?"),
    ] },
  { key: "hai_long", topic: "gan_ket", title: "Mức hài lòng với công việc",
    description: "Đánh giá mức hài lòng về tính chất công việc, sự ghi nhận, quyền tự chủ và các yếu tố chưa hài lòng.",
    questions: [
      ...SEG3,
      scale("Nhìn chung, bạn hài lòng với công việc hiện tại ở mức nào?", "Rất không hài lòng", "Rất hài lòng"),
      agree("Công việc của tôi thú vị và có ý nghĩa."),
      agree("Tôi được tự chủ trong cách làm việc của mình."),
      agree("Đóng góp của tôi được ghi nhận xứng đáng."),
      multi("Những yếu tố nào khiến bạn CHƯA hài lòng? (có thể chọn nhiều)", ["Thu nhập", "Khối lượng công việc", "Cơ hội phát triển",
        "Quản lý trực tiếp", "Đồng nghiệp", "Môi trường làm việc", "Không có"]),
      open("Điều gì sẽ khiến công việc của bạn tốt hơn?"),
    ] },
  { key: "thuoc_ve", topic: "gan_ket", title: "Cảm giác thuộc về & hòa nhập",
    description: "Nhân viên có cảm thấy được tôn trọng, được lắng nghe và đối xử công bằng không.",
    questions: [
      ...SEG3,
      agree("Tôi cảm thấy mình là một phần của tập thể."),
      agree("Ý kiến của tôi được lắng nghe và tôn trọng."),
      agree("Mọi người được đối xử công bằng, bất kể giới tính, tuổi tác hay xuất thân."),
      agree("Tôi có thể là chính mình khi làm việc."),
      single("Trong 6 tháng qua, bạn có từng cảm thấy bị đối xử không công bằng ở công ty không?",
        ["Chưa từng", "Một vài lần", "Nhiều lần", "Không muốn trả lời"]),
      open("Công ty có thể làm gì để mọi người cảm thấy được hòa nhập hơn?"),
    ] },

  // ----------------------------------------------- Dai ngo & phat trien ----
  { key: "luong_thuong", topic: "dai_ngo", title: "Lương thưởng & phúc lợi",
    description: "Mức lương có tương xứng và cạnh tranh không, cách tính có minh bạch không, phúc lợi nào quan trọng nhất.",
    questions: [
      ...SEG3,
      agree("Mức lương của tôi tương xứng với công sức và trách nhiệm."),
      agree("Mức lương của tôi cạnh tranh so với thị trường."),
      agree("Cách tính lương thưởng minh bạch, dễ hiểu."),
      multi("Những phúc lợi nào quan trọng nhất với bạn? (có thể chọn nhiều)", ["Bảo hiểm sức khỏe", "Thưởng theo hiệu quả",
        "Làm việc linh hoạt / từ xa", "Ngày nghỉ phép", "Hỗ trợ đào tạo", "Du lịch / team building", "Hỗ trợ ăn trưa, đi lại"]),
      open("Bạn muốn công ty bổ sung hoặc điều chỉnh chế độ nào?"),
    ] },
  { key: "phat_trien", topic: "dai_ngo", title: "Cơ hội phát triển & thăng tiến",
    description: "Nhân viên có thấy rõ lộ trình nghề nghiệp, được đào tạo và giao việc thử thách không.",
    questions: [
      ...SEG3,
      agree("Tôi thấy rõ lộ trình phát triển nghề nghiệp của mình ở công ty."),
      agree("Tôi được giao những việc giúp mình học hỏi và phát triển."),
      agree("Quản lý quan tâm đến sự phát triển của tôi."),
      single("Trong 12 tháng qua, bạn đã được tham gia khóa đào tạo nào chưa?", ["Chưa", "1 khóa", "2 – 3 khóa", "Trên 3 khóa"]),
      multi("Bạn muốn được phát triển thêm ở mảng nào? (có thể chọn nhiều)", ["Chuyên môn nghiệp vụ", "Kỹ năng quản lý, lãnh đạo",
        "Kỹ năng mềm (giao tiếp, thuyết trình…)", "Ngoại ngữ", "Công nghệ, công cụ số"]),
      open("Điều gì sẽ giúp bạn phát triển nhanh hơn ở công ty?"),
    ] },
  { key: "dao_tao", topic: "dai_ngo", title: "Đánh giá sau khóa đào tạo nội bộ",
    description: "Thu phản hồi ngay sau khóa học: nội dung, giảng viên, khả năng áp dụng và chủ đề muốn học tiếp.",
    questions: [
      seg.dept, seg.level,
      rating("Bạn đánh giá chung về khóa đào tạo thế nào?"),
      agree("Nội dung khóa học phù hợp với công việc của tôi."),
      agree("Giảng viên truyền đạt dễ hiểu."),
      single("Bạn có thể áp dụng kiến thức vào công việc ở mức nào?", ["Áp dụng được ngay", "Áp dụng được một phần", "Khó áp dụng", "Không áp dụng được"]),
      single("Thời lượng khóa học?", ["Quá ngắn", "Vừa đủ", "Quá dài"]),
      open("Bạn muốn học chủ đề gì tiếp theo?"),
    ] },

  // ------------------------------------------------- Quan ly & doi nhom ----
  { key: "quan_ly", topic: "quan_ly", title: "Đánh giá quản lý trực tiếp",
    description: "Nhân viên đánh giá quản lý trực tiếp về giao việc, phản hồi, ghi nhận và sự cởi mở.",
    questions: [
      ...SEG3,
      agree("Quản lý của tôi giao việc rõ ràng, có mục tiêu cụ thể."),
      agree("Quản lý thường xuyên phản hồi để tôi làm tốt hơn."),
      agree("Quản lý ghi nhận khi tôi làm tốt."),
      agree("Tôi có thể chia sẻ khó khăn với quản lý mà không ngại."),
      rating("Bạn đánh giá chung về quản lý trực tiếp của mình thế nào?"),
      open("Quản lý của bạn nên làm điều gì nhiều hơn hoặc ít đi?"),
    ] },
  { key: "lam_viec_nhom", topic: "quan_ly", title: "Làm việc nhóm & giao tiếp nội bộ",
    description: "Đánh giá sự phối hợp trong nhóm, giữa các phòng ban và hiệu quả của các kênh thông tin nội bộ.",
    questions: [
      ...SEG3,
      agree("Các thành viên trong nhóm hỗ trợ nhau tốt."),
      agree("Thông tin quan trọng được chia sẻ kịp thời giữa các phòng ban."),
      agree("Mâu thuẫn trong nhóm được giải quyết thẳng thắn, xây dựng."),
      multi("Kênh nào bạn thấy hiệu quả nhất để nhận thông tin nội bộ? (có thể chọn nhiều)", ["Họp trực tiếp", "Email",
        "Nhóm chat (Zalo, Teams, Slack…)", "Bảng tin / intranet", "Trao đổi riêng với quản lý"]),
      open("Điều gì đang cản trở việc phối hợp giữa các nhóm / phòng ban?"),
    ] },
  { key: "lanh_dao", topic: "quan_ly", title: "Niềm tin vào lãnh đạo & giá trị công ty",
    description: "Nhân viên có hiểu tầm nhìn, tin vào ban lãnh đạo và thấy lời nói đi đôi với việc làm không.",
    questions: [
      ...SEG3,
      agree("Tôi hiểu rõ tầm nhìn và mục tiêu của công ty."),
      agree("Ban lãnh đạo truyền đạt thông tin minh bạch."),
      agree("Lời nói và hành động của ban lãnh đạo nhất quán."),
      agree("Tôi tin công ty đang đi đúng hướng."),
      open("Bạn muốn ban lãnh đạo chia sẻ hoặc thay đổi điều gì?"),
    ] },

  // ---------------------------------------------- Suc khoe & can bang ----
  { key: "kiet_suc", topic: "suc_khoe", title: "Khối lượng công việc & nguy cơ kiệt sức",
    description: "Phát hiện sớm tình trạng quá tải: giờ làm thêm, mức căng thẳng, dấu hiệu kiệt sức và nguyên nhân.",
    questions: [
      ...SEG3,
      scale("Khối lượng công việc hiện tại của bạn?", "Rất nhẹ", "Quá tải"),
      single("Trung bình mỗi tuần bạn làm thêm ngoài giờ bao nhiêu?", ["Không làm thêm", "Dưới 3 giờ", "3 – 8 giờ", "Trên 8 giờ"]),
      scale("Mức căng thẳng trong công việc của bạn gần đây?", "Rất thấp", "Rất cao"),
      multi("Dấu hiệu nào bạn đang gặp phải? (có thể chọn nhiều)", ["Mệt mỏi kéo dài", "Khó tập trung", "Mất hứng thú với công việc",
        "Khó ngủ", "Dễ cáu gắt", "Không có dấu hiệu nào"]),
      multi("Nguyên nhân chính gây căng thẳng? (có thể chọn nhiều)", ["Khối lượng việc quá nhiều", "Thời hạn gấp", "Mục tiêu không rõ ràng",
        "Thiếu nhân sự", "Áp lực từ quản lý", "Mâu thuẫn với đồng nghiệp"]),
      open("Công ty có thể làm gì để giảm áp lực cho bạn?"),
    ] },
  { key: "can_bang", topic: "suc_khoe", title: "Cân bằng công việc – cuộc sống",
    description: "Nhân viên có đủ thời gian cho bản thân, gia đình và mong muốn hình thức làm việc nào.",
    questions: [
      ...SEG3,
      agree("Tôi có đủ thời gian cho gia đình và cuộc sống cá nhân."),
      agree("Tôi có thể nghỉ phép khi cần mà không lo ngại."),
      agree("Giờ giấc làm việc đủ linh hoạt với tôi."),
      single("Hình thức làm việc bạn mong muốn nhất?", ["Toàn thời gian tại văn phòng", "Kết hợp văn phòng và từ xa", "Làm từ xa hoàn toàn", "Không quan trọng"]),
      open("Chính sách nào sẽ giúp bạn cân bằng tốt hơn?"),
    ] },
  { key: "moi_truong", topic: "suc_khoe", title: "Môi trường & điều kiện làm việc",
    description: "Đánh giá không gian, công cụ, thiết bị và sự an toàn nơi làm việc.",
    questions: [
      ...SEG3,
      rating("Bạn đánh giá thế nào về không gian làm việc?"),
      agree("Tôi có đủ công cụ, thiết bị để làm việc hiệu quả."),
      agree("Nơi làm việc an toàn và sạch sẽ."),
      multi("Bạn muốn cải thiện điều gì ở nơi làm việc? (có thể chọn nhiều)", ["Chỗ ngồi", "Máy tính, thiết bị", "Phần mềm, công cụ",
        "Phòng họp", "Khu vực nghỉ ngơi, ăn uống", "Nhiệt độ, ánh sáng, tiếng ồn"]),
      open("Góp ý khác của bạn về môi trường làm việc?"),
    ] },

  // ----------------------------------------------------- Nguy co nghi viec ----
  { key: "stay", topic: "nghi_viec", title: "Ý định gắn bó (stay survey)",
    description: "Hỏi nhân viên hiện tại điều gì giữ họ ở lại và điều gì có thể khiến họ ra đi, trước khi họ nghỉ việc.",
    questions: [
      ...SEG3,
      single("Bạn có dự định tiếp tục làm việc ở công ty trong 12 tháng tới không?", ["Chắc chắn có", "Có thể có", "Chưa chắc chắn",
        "Có thể không", "Chắc chắn không"]),
      multi("Điều gì giữ bạn ở lại công ty? (có thể chọn nhiều)", ["Thu nhập, phúc lợi", "Đồng nghiệp", "Quản lý trực tiếp",
        "Cơ hội học hỏi, phát triển", "Công việc ổn định", "Thời gian linh hoạt", "Văn hóa công ty"]),
      multi("Điều gì có thể khiến bạn cân nhắc rời đi? (có thể chọn nhiều)", ["Thu nhập thấp hơn thị trường", "Không có cơ hội thăng tiến",
        "Áp lực, quá tải", "Quan hệ với quản lý", "Có lời mời tốt hơn", "Lý do cá nhân, gia đình"]),
      single("Trong 3 tháng qua, bạn có từng tìm hiểu cơ hội việc làm ở nơi khác không?", ["Chưa", "Có tìm hiểu nhưng chưa ứng tuyển",
        "Đã ứng tuyển / phỏng vấn", "Không muốn trả lời"]),
      open("Nếu được thay đổi một điều để bạn gắn bó lâu hơn, đó là gì?"),
    ] },
  { key: "exit", topic: "nghi_viec", title: "Khảo sát nghỉ việc (exit survey)",
    description: "Dành cho nhân viên sắp nghỉ: lý do thật sự rời đi, có quay lại không và góp ý để công ty tốt hơn.",
    questions: [
      ...SEG3,
      multi("Lý do chính khiến bạn nghỉ việc? (có thể chọn nhiều)", ["Thu nhập, phúc lợi", "Cơ hội phát triển", "Quản lý trực tiếp",
        "Khối lượng công việc, áp lực", "Môi trường, văn hóa", "Lý do cá nhân, gia đình", "Có cơ hội tốt hơn"]),
      scale("Nhìn chung, bạn hài lòng thế nào về thời gian làm việc tại công ty?", "Rất không hài lòng", "Rất hài lòng"),
      single("Bạn có cân nhắc quay lại làm việc với công ty trong tương lai không?", ["Có", "Có thể", "Không"]),
      nps(ENPS),
      open("Công ty có thể làm gì để bạn đã không rời đi?"),
      open("Góp ý của bạn để công ty tốt hơn?"),
    ] },
  { key: "thay_doi", topic: "nghi_viec", title: "Khảo sát sau thay đổi tổ chức",
    description: "Sau tái cấu trúc, đổi quản lý hay sáp nhập: nhân viên có hiểu lý do, lo lắng điều gì và cần hỗ trợ gì.",
    questions: [
      ...SEG3,
      agree("Tôi hiểu lý do của sự thay đổi."),
      agree("Tôi được thông tin đầy đủ về việc thay đổi ảnh hưởng đến mình."),
      scale("Mức lo lắng của bạn về thay đổi này?", "Hoàn toàn không lo", "Rất lo lắng"),
      multi("Bạn cần hỗ trợ gì trong giai đoạn này? (có thể chọn nhiều)", ["Thông tin rõ ràng hơn", "Đào tạo kỹ năng mới",
        "Trao đổi riêng với quản lý", "Thời gian thích nghi", "Không cần hỗ trợ thêm"]),
      open("Bạn có băn khoăn hay đề xuất gì về sự thay đổi này?"),
    ] },
  { key: "van_hoa", topic: "nghi_viec", title: "Văn hóa công ty",
    description: "Nhân viên mô tả văn hóa hiện tại, điều muốn giữ và điều muốn thay đổi. Văn hóa không phù hợp là lý do nghỉ việc phổ biến.",
    questions: [
      ...SEG3,
      agree("Giá trị cốt lõi của công ty được thể hiện trong công việc hằng ngày."),
      multi("Những từ nào mô tả đúng văn hóa công ty hiện nay? (có thể chọn nhiều)", ["Thân thiện", "Chuyên nghiệp", "Đổi mới", "Áp lực",
        "Cứng nhắc", "Cởi mở", "Cạnh tranh", "Gắn kết"]),
      agree("Tôi cảm thấy phù hợp với văn hóa công ty."),
      open("Điều bạn muốn GIỮ trong văn hóa công ty là gì?"),
      open("Điều bạn muốn THAY ĐỔI trong văn hóa công ty là gì?"),
    ] },
];

// Thoi gian lam bai uoc tinh (giay moi cau theo loai)
const SECONDS = { single_choice: 8, dropdown: 8, multiple_choice: 12, scale: 6, rating: 6, nps: 6, open_text: 40 };
const minutesOf = (qs) => Math.max(1, Math.ceil(qs.reduce((s, q) => s + SECONDS[q.type], 0) / 60));

// Cau hoi day du (id q1.., required, options, scale) - dung chung khi xem truoc va khi tao ban nhap
function build(t) {
  return t.questions.map((q, i) => {
    const item = { id: `q${i + 1}`, question: q.question, type: q.type, required: !!q.required, options: q.options ? [...q.options] : [] };
    if (q.scale) item.scale = [...q.scale];
    return item;
  });
}

export const TEMPLATES = Object.fromEntries(LIST.map(t => [t.key, {
  key: t.key, topic: t.topic, title: t.title, description: t.description,
  questions: build(t), count: t.questions.length, minutes: minutesOf(t.questions),
}]));
