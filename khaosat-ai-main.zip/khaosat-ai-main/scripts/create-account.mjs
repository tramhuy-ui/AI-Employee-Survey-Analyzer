// In ra cau lenh SQL tao tai khoan dang nhap bang TEN DANG NHAP (vd. admin dau tien). Mat khau duoc bam PBKDF2,
// doc tu bien moi truong PASSWORD (khong ghi vao file, khong hien tren man hinh).
//   PASSWORD='...' node scripts/create-account.mjs <ten_dang_nhap> "<Ten hien thi>" <admin|hr>
//   -> chay cau lenh in ra:  npx wrangler d1 execute khaosat-db --remote --command "<SQL>"
// Neu ten dang nhap da ton tai: cap nhat mat khau + vai tro (dung de dat lai mat khau admin).
import { hashPassword, USERNAME_RE, usernameEmail, ROLES } from "../src/auth.js";

const [username, name, role] = process.argv.slice(2);
const password = process.env.PASSWORD || "";
if (!USERNAME_RE.test(username || "") || !name || !ROLES.includes(role)) {
  console.error('Cách dùng: PASSWORD=\'...\' node scripts/create-account.mjs <ten_dang_nhap> "<Tên hiển thị>" <admin|hr>');
  process.exit(1);
}
if (password.length < 8) { console.error("PASSWORD cần ít nhất 8 ký tự."); process.exit(1); }
const q = (v) => `'${String(v).replace(/'/g, "''")}'`;
const now = Math.floor(Date.now() / 1000);
const hash = await hashPassword(password);
console.log(`INSERT INTO users (email, name, pass_hash, username, role, terms_at, created) VALUES (${q(usernameEmail(username))}, ${q(name)}, ${q(hash)}, ${q(username)}, ${q(role)}, ${now}, ${now}) ` +
  `ON CONFLICT (email) DO UPDATE SET pass_hash = excluded.pass_hash, role = excluded.role, name = excluded.name, locked = 0;`);
