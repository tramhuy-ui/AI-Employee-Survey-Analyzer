# KhảoSát AI

Nền tảng tạo khảo sát trực tuyến có trợ lý AI, tập trung vào **khảo sát nhân sự và giữ chân nhân viên**. Đây là dự án học tập (bài tập cuối kỳ).

🔗 Bản chạy thật: **https://khaosat-ai-490.pages.dev**

## Tính năng

- **3 cách tạo khảo sát**
  - Từ ý tưởng: mô tả mục đích, AI gợi ý bộ câu hỏi (kèm câu hỏi phân nhóm phòng ban / thâm niên / cấp bậc).
  - Từ mẫu có sẵn: 20 mẫu nhân sự (eNPS, onboarding 30/90 ngày, stay interview, exit survey, kiệt sức, lương thưởng…).
  - Từ đầu: tự soạn câu hỏi.
- **Nhiều loại câu hỏi**: một lựa chọn, nhiều lựa chọn, thang đo đồng ý, đánh giá sao, NPS, câu hỏi mở.
- **Ẩn danh**: khảo sát nhân sự mặc định ẩn danh; người trả lời luôn được báo trước.
- **Chia sẻ**: link + mã QR, đóng/mở khảo sát, quản lý phiên bản.
- **Kết quả**: biểu đồ từng câu, xem từng câu trả lời, xuất CSV, thời gian làm bài trung bình.
- **Phân tích bằng AI**: tóm tắt, chủ đề nổi bật, **mức nguy cơ nghỉ việc** (có dẫn chứng) và **việc nên làm ngay**.
- **Hộp thư góp ý ẩn danh**: HR tạo mỗi phòng ban một hộp thư và gửi một link chung (kèm mã QR); nhân viên đăng nhập để gửi nhưng HR **không thấy** người gửi. HR đổi trạng thái, trả lời (nhân viên xem ở "Thư tôi đã gửi").
  - AI chấm **mức hài lòng 1–5 từng thư** (lưu lại, không chấm lại), web tự vẽ biểu đồ: phân bố, so sánh phòng ban, theo chủ đề, xu hướng theo tuần/tháng.
  - AI viết đánh giá tình hình cho tất cả phòng ban hoặc từng phòng: nguy cơ nghỉ việc, phòng cần chú ý, việc nên làm ngay (có trích dẫn thư làm bằng chứng).
- **Tài khoản**: đăng ký bằng email/mật khẩu hoặc **đăng nhập bằng Google** (OAuth 2.0 + PKCE).
- **Phân quyền**: Người dùng (tạo khảo sát, gửi góp ý) · **HR** (tạo hộp thư góp ý) · **Admin**. Admin tạo tài khoản HR (đăng nhập bằng tên đăng nhập, phân biệt hoa thường) hoặc bật quyền HR cho người dùng đã đăng ký. Mọi tài khoản có mật khẩu đều đổi được mật khẩu.
- **Quản trị**: xử lý báo cáo vi phạm, ẩn/xóa khảo sát, khóa tài khoản, chỉnh hạn mức AI, cấp quyền HR, đặt lại mật khẩu tài khoản HR.

## Công nghệ

| Phần | Công nghệ |
|---|---|
| Giao diện | HTML, CSS, JavaScript thuần (không framework) |
| Máy chủ | Cloudflare Pages Functions |
| Cơ sở dữ liệu | Cloudflare D1 (SQLite) |
| AI | Groq API (`openai/gpt-oss-120b`, đầu ra JSON có schema) |
| Đăng nhập | Mật khẩu băm PBKDF2, Google OAuth 2.0 |

## Cấu trúc thư mục

```
public/          Giao diện (các trang .html, assets/app.css, assets/app.js)
functions/       Điểm vào Cloudflare Pages Functions (chuyển tiếp sang src/)
src/
  app.js         Định tuyến API
  auth.js        Đăng ký, đăng nhập, phiên
  google.js      Đăng nhập Google
  db.js          Tạo/cập nhật bảng D1
  survey.js      Gợi ý câu hỏi và phân tích bằng AI
  feedback.js    Hộp thư góp ý: API, AI chấm mức hài lòng, thống kê
  llm.js         Gọi Groq / Gemini
  templates.js   20 mẫu khảo sát nhân sự
  questions.js   Kiểm tra dữ liệu câu hỏi, chủ đề
test/            Kiểm thử API (local.mjs) và giao diện (ui.mjs)
scripts/         create-account.mjs: tạo tài khoản admin/HR · seed-demo.mjs: nạp / xóa dữ liệu demo
schema.sql       Cấu trúc cơ sở dữ liệu
wrangler.toml    Cấu hình Cloudflare
```

## Chạy trên máy

Yêu cầu: Node.js 20+.

```bash
npm install
cp .dev.vars.example .dev.vars   # điền GROQ_API_KEY, APP_SECRET
npm run dev                      # mở http://localhost:8788
```

Chạy kiểm thử:

```bash
npm test
```

## Triển khai lên Cloudflare

```bash
npx wrangler login
npx wrangler d1 create khaosat-db          # rồi cập nhật database_id trong wrangler.toml
npx wrangler pages secret put GROQ_API_KEY --project-name khaosat-ai
npx wrangler pages secret put APP_SECRET   --project-name khaosat-ai
# Tùy chọn, để bật đăng nhập Google:
npx wrangler pages secret put GOOGLE_CLIENT_ID     --project-name khaosat-ai
npx wrangler pages secret put GOOGLE_CLIENT_SECRET --project-name khaosat-ai
npm run deploy
```

Các bảng trong D1 được tạo tự động ở lần gọi API đầu tiên. Sau đó tạo tài khoản admin (mật khẩu đọc từ biến môi trường, không ghi vào file):

```bash
SQL=$(PASSWORD='mat-khau-manh' node scripts/create-account.mjs Admin_account "Quản trị viên" admin)
npx wrangler d1 execute khaosat-db --remote --command "$SQL"
```

Với đăng nhập Google, tạo OAuth client loại *Web application* trên Google Cloud và thêm Authorized redirect URI:
`https://<ten-mien-cua-ban>/api/auth/google/callback`


## Lưu ý

- Kết quả do AI gợi ý và phân tích chỉ mang tính tham khảo.
- Không có khóa bí mật nào trong mã nguồn; tất cả được lưu dưới dạng secret của Cloudflare.
