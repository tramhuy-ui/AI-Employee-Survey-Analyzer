// Kiem thu giao dien bang jsdom: mo tung trang, bam nut / dien form nhu nguoi dung that.
// API duoc noi thang vao router (src/app.js) voi D1 gia lap va Groq gia lap. Chay: node test/ui.mjs
import jsdom from "jsdom";
const { JSDOM, VirtualConsole, requestInterceptor } = jsdom;
import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";
import { handle } from "../src/app.js";
import { hashPassword } from "../src/auth.js";

const BASE = "https://khaosat.test";
const PUBLIC = new URL("../public/", import.meta.url);

// ---------------------------------------------------------- D1 + Groq gia lap ----
class Stmt {
  constructor(db, sql, params = []) { this.db = db; this.sql = sql; this.params = params; }
  bind(...p) { return new Stmt(this.db, this.sql, p.map(v => (v === undefined ? null : v))); }
  async first(col) { const r = this.db.prepare(this.sql).get(...this.params); return r ? (col ? r[col] : { ...r }) : null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.params).map(r => ({ ...r })) }; }
  async run() { const i = this.db.prepare(this.sql).run(...this.params); return { meta: { changes: i.changes, last_row_id: Number(i.lastInsertRowid) } }; }
}
class D1 {
  constructor() { this.db = new DatabaseSync(":memory:"); }
  prepare(sql) { return new Stmt(this.db, sql); }
  async batch(stmts) { this.db.exec("BEGIN"); try { for (const s of stmts) await s.run(); this.db.exec("COMMIT"); } catch (e) { this.db.exec("ROLLBACK"); throw e; } }
}
const MOCK = "https://mock.groq.test/openai/v1";
const env = { DB: new D1(), APP_SECRET: "x", GROQ_API_KEY: "gsk_test", GROQ_URL: MOCK,
  GOOGLE_CLIENT_ID: "cid", GOOGLE_CLIENT_SECRET: "sec" };
const googleProfiles = {};
const nodeFetch = globalThis.fetch;
globalThis.fetch = async (url, init = {}) => {
  if (String(url) === "https://oauth2.googleapis.com/token") {
    const p = googleProfiles[new URLSearchParams(init.body).get("code")];
    const jwt = ["e30", Buffer.from(JSON.stringify({ iss: "accounts.google.com", aud: "cid", exp: Date.now() / 1000 + 600, email_verified: true, ...p })).toString("base64url"), "s"].join(".");
    return Response.json({ id_token: jwt });
  }
  if (!String(url).startsWith(MOCK)) return nodeFetch(url, init);
  if (String(url).endsWith("/models")) return Response.json({ data: [{ id: "openai/gpt-oss-120b" }] });
  const body = JSON.parse(init.body), p = body.response_format.json_schema.schema.properties, prompt = body.messages[1].content;
  const codes = [...prompt.matchAll(/\[(T\d+)\]/g)].map(m => m[1]);
  const out = p.items ? { items: [...prompt.matchAll(/^\[(\d+)\] \([^)]*\) (.*)$/gm)].map(([, id, t]) => ({ id: +id, sat: /tệ/.test(t) ? 1 : 4, topic: "quan_ly" })) }
    : p.overview ? { overview: "Tình hình góp ý kiểm thử.", issues: [{ text: "Quản lý chưa lắng nghe", severity: "cao", evidence: [codes[0]] }], positives: [],
        retention_risk: { level: "trung_binh", reason: "Có thư bức xúc", evidence: [codes[0]] }, quick_actions: [{ text: "Họp với trưởng phòng", evidence: [] }],
        departments: [{ name: "Phòng Kỹ thuật", main_issue: "Quản lý" }], focus: { name: "Phòng Kỹ thuật", reason: "Chỉ số thấp nhất" }, limitations: "Ít thư." }
    : p.questions ? { title: "Khảo sát căng tin (AI)", description: "Mô tả do AI viết", topic: "gan_ket", questions: [
      { question: "Bạn học năm mấy?", type: "single_choice", options: ["Năm 1", "Năm 2"], scale_min_label: "", scale_max_label: "" },
      { question: "Chấm điểm chất lượng", type: "rating", options: [], scale_min_label: "", scale_max_label: "" }] }
    : p.themes ? { themes: [{ name: "Giá cả", description: "Giá cao", sentiment: "tieu_cuc", ids: [0] }] }
    : { retention_risk: { level: "trung_binh", reason: "Một số người chưa chắc gắn bó", evidence: ["q1"] }, quick_actions: [],
        summary: "Tóm tắt kiểm thử.", limitations: "", highlights: [{ text: "Giá cao", evidence: ["C1"] }], issues: [], positives: [], notable: [], recommendations: [] };
  return Response.json({ choices: [{ message: { content: JSON.stringify(out) } }], usage: { total_tokens: 500 } });
};

// --------------------------------------------------------------- trinh duyet ----
// Script/CSS cua trang doc tu thu muc public; thu vien QR (cdnjs) thay bang ban gia
const resources = { interceptors: [requestInterceptor((request) => {
  const js = { headers: { "Content-Type": "application/javascript" } };
  if (request.url.startsWith(BASE)) {
    const path = new URL(request.url).pathname;
    return new Response(readFileSync(new URL("." + path, PUBLIC)), path.endsWith(".css") ? { headers: { "Content-Type": "text/css" } } : js);
  }
  if (request.url.includes("qrcode")) return new Response("window.qrcode=()=>({addData(){},make(){},getModuleCount:()=>21,isDark:()=>false});", js);
  return new Response("", { status: 404 });
})] };

class Browser {
  constructor(ip) { this.ip = ip; this.jar = {}; this.errors = []; }
  async request(url, init = {}) {
    const headers = new Headers(init.headers || {});
    headers.set("cf-connecting-ip", this.ip);
    const cookie = Object.entries(this.jar).map(([k, v]) => `${k}=${v}`).join("; ");
    if (cookie) headers.set("cookie", cookie);
    const res = await handle(new Request(new URL(url, BASE), { ...init, headers }), env);
    for (const c of res.headers.getSetCookie()) {
      const [kv] = c.split(";"); const i = kv.indexOf("=");
      if (/Max-Age=0/.test(c)) delete this.jar[kv.slice(0, i)]; else this.jar[kv.slice(0, i)] = kv.slice(i + 1);
    }
    return res;
  }
  // Mo mot trang (file .html tuong ung voi duong dan, giong Cloudflare Pages)
  async open(path) {
    const u = new URL(path, BASE);
    let file = u.pathname === "/" ? "index" : u.pathname.slice(1);
    if (file.startsWith("s/")) file = "answer";
    const html = readFileSync(new URL(`${file}.html`, PUBLIC), "utf8");
    const vc = new VirtualConsole();
    vc.on("jsdomError", (e) => { if (!/navigation|showModal|getContext|Could not load link/i.test(e.message)) this.errors.push(`${path}: ${e.message}`); });
    vc.on("error", (e) => this.errors.push(`${path}: ${e}`));
    this.navigatedTo = null;
    const dom = new JSDOM(html, { url: u.href, runScripts: "dangerously", resources, virtualConsole: vc, pretendToBeVisual: true,
      beforeParse: (w) => {
        w.fetch = (url, init) => this.request(url, init);
        w.confirm = () => true; w.alert = (m) => { this.lastAlert = m; };
        w.HTMLDialogElement.prototype.showModal = function () { this.open = true; };
        w.HTMLDialogElement.prototype.close = function () { this.open = false; };
        w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
        w.HTMLCanvasElement.prototype.getContext = () => ({ fillRect() {} });
        w.HTMLCanvasElement.prototype.toDataURL = () => "data:image/png;base64,";
        w.HTMLElement.prototype.animate = () => {};
      } });
    this.dom = dom; this.w = dom.window; this.d = dom.window.document;
    await new Promise(r => dom.window.addEventListener("load", r));
    await this.waitFor(() => this.d.documentElement.dataset.ready, `khởi tạo trang ${path}`);
    await new Promise(r => setTimeout(r, 20)); // cho script cua trang gan xong cac xu ly su kien
    return this;
  }
  $(sel) { return this.d.querySelector(sel); }
  text(sel) { return this.$(sel)?.textContent.replace(/\s+/g, " ").trim() || ""; }
  type(sel, value) { const el = this.$(sel); assert.ok(el, `không thấy ${sel}`); el.value = value; el.dispatchEvent(new this.w.Event("input", { bubbles: true })); el.dispatchEvent(new this.w.Event("change", { bubbles: true })); }
  click(sel) { const el = typeof sel === "string" ? this.$(sel) : sel; assert.ok(el, `không thấy ${sel}`); el.click(); }
  submit(sel) { this.$(sel).dispatchEvent(new this.w.Event("submit", { bubbles: true, cancelable: true })); }
  async waitFor(fn, msg, ms = 5000) {
    const t = Date.now();
    for (;;) { try { const v = fn(); if (v) return v; } catch { /* thu lai */ } if (Date.now() - t > ms) throw new Error(`Hết thời gian chờ: ${msg}` + (this.errors.length ? `\nLỗi trên trang: ${this.errors.join(" | ")}` : "")); await new Promise(r => setTimeout(r, 30)); }
  }
}

const ok = (m) => console.log("  ✓", m);
// Dang nhap Google: trinh duyet bam nut -> Google (gia lap) -> callback cua server
let gcode = 0;
async function googleLogin(b, profile, next = "/dashboard") {
  const start = await b.request(`/api/auth/google/start?next=${encodeURIComponent(next)}`);
  const state = new URL(start.headers.get("location")).searchParams.get("state");
  const code = `c${++gcode}`; googleProfiles[code] = profile;
  return (await b.request(`/api/auth/google/callback?code=${code}&state=${state}`)).headers.get("location");
}
const db = (sql, ...p) => env.DB.db.prepare(sql).get(...p);

// ----------------------------------------------------------------- kich ban ----
console.log("== Kiểm thử giao diện (jsdom)");
const alice = new Browser("10.0.0.1"), bob = new Browser("10.0.0.2"), admin = new Browser("10.0.0.3"), guest = new Browser("10.0.0.4");

// Dang ky qua giao dien
await alice.open("/register?next=/dashboard");
alice.type("#name", "Alice Nguyễn"); alice.type("#email", "alice@test.vn"); alice.type("#password", "matkhau123"); alice.type("#password2", "matkhau123");
assert.ok(alice.$("#btnGoogle")?.href.includes("/api/auth/google/start?next=%2Fdashboard"), "nút Đăng ký bằng Google");
alice.submit("#form");
await alice.waitFor(() => alice.text("#err").includes("Điều khoản"), "phải đồng ý điều khoản");
alice.$("#terms").checked = true;
alice.submit("#form");
await alice.waitFor(() => db("SELECT 1 FROM users WHERE email = 'alice@test.vn'") && alice.jar.ks_sess, "đăng ký Alice");
await bob.request("/api/register", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: "Bob Trần", email: "bob@test.vn", password: "matkhau123", accept_terms: true }) });
// Tai khoan admin tao thang trong CSDL; dang nhap qua form bang ten dang nhap (phan biet hoa thuong)
env.DB.db.prepare("INSERT INTO users (email, name, pass_hash, username, role, terms_at, created) VALUES (?, ?, ?, ?, 'admin', 1, 1)")
  .run("@Admin_account", "Quản trị viên", await hashPassword("Mat-khau-admin-1"), "Admin_account");
await admin.open("/login?next=/admin");
admin.type("#email", "admin_account"); admin.type("#password", "Mat-khau-admin-1"); admin.submit("#form");
await admin.waitFor(() => admin.text("#err").includes("không đúng"), "sai hoa thường → báo lỗi");
admin.type("#email", "Admin_account"); admin.submit("#form");
await admin.waitFor(() => admin.jar.ks_sess, "admin đăng nhập bằng tên đăng nhập");
await guest.open("/register");
guest.type("#name", "Khách"); guest.type("#email", "guest@test.vn"); guest.type("#password", "matkhau123"); guest.type("#password2", "khac123456");
guest.submit("#form");
await guest.waitFor(() => guest.text("#err").includes("không khớp"), "báo mật khẩu không khớp");
guest.jar = {};
ok("đăng ký qua form (bắt buộc đồng ý điều khoản, báo lỗi khi 2 mật khẩu không khớp); admin đăng nhập bằng tên đăng nhập (phân biệt hoa thường)");

// Dang nhap Google lan dau -> man hinh dong y dieu khoan
const dung = new Browser("10.0.0.5");
await dung.open("/login?next=/create&error=cancelled");
assert.match(dung.text("#err"), /hủy đăng nhập/); assert.ok(dung.$("#btnGoogle").href.includes("next=%2Fcreate"));
assert.equal(await googleLogin(dung, { sub: "g-dung", email: "dung@gmail.com", name: "Dũng Võ", picture: "https://lh3.googleusercontent.com/a/d" }, "/create"),
  `/welcome?next=${encodeURIComponent("/create")}`);
await dung.open("/welcome?next=/create");
await dung.waitFor(() => dung.text("#hello").includes("Dũng Võ"), "màn hình chào mừng");
assert.ok(dung.$("#avt img")?.src.includes("googleusercontent"), "ảnh đại diện Google"); assert.equal(dung.$("#btn").disabled, true);
dung.click("#c1"); assert.equal(dung.$("#btn").disabled, false);
dung.click("#btn");
await dung.waitFor(() => db("SELECT terms_at FROM users WHERE email = 'dung@gmail.com'").terms_at, "lưu đồng ý điều khoản");
await dung.open("/terms"); assert.match(dung.text("h1"), /Điều khoản/);
await dung.open("/privacy"); assert.match(dung.text("main"), /openid, email, profile/);
ok("Google: nút đăng nhập, báo lỗi, tài khoản mới → đồng ý điều khoản (ảnh đại diện Google); trang Điều khoản, Quyền riêng tư");

// Dashboard trong -> trang tao khao sat (3 cach)
await alice.open("/dashboard");
await alice.waitFor(() => !alice.$("#empty").classList.contains("hidden"), "dashboard trống");
assert.match(alice.text(".ab"), /Alice Nguyễn/);
assert.ok(!alice.text(".ab").includes("Quản trị"), "người thường không thấy menu Quản trị");
assert.ok(alice.$(".sd .si2.on")?.textContent.includes("Khảo sát của tôi"), "thanh bên");
await alice.open("/create?mode=tpl");
await alice.waitFor(() => alice.d.querySelectorAll("#tplList .mcard").length === 20, "20 mẫu nhân sự");
alice.type("#tq", "exit survey");
await alice.waitFor(() => alice.d.querySelectorAll("#tplList .mcard").length === 1, "tìm mẫu không dấu");
alice.click('#tplList [data-a="preview"]');
assert.equal(alice.$("#tplDialog").open, true); assert.ok(alice.d.querySelectorAll("#dQuestions .pvq").length >= 6, "xem trước câu hỏi");
alice.click("#dUse");
await alice.waitFor(() => db("SELECT COUNT(*) AS n FROM surveys").n === 1, "tạo từ mẫu");
let row = db("SELECT * FROM surveys");
assert.equal(row.title, "Khảo sát nghỉ việc (exit survey)"); assert.equal(row.anonymous, 1); assert.equal(row.topic, "nghi_viec");
await alice.open("/create");
alice.type("#idea", "Vì sao nhân viên mới hay nghỉ");
alice.click("#btnIdea");
await alice.waitFor(() => db("SELECT COUNT(*) AS n FROM surveys").n === 2, "tạo bằng AI");
row = db("SELECT * FROM surveys ORDER BY created DESC, rowid DESC");
assert.equal(row.title, "Khảo sát căng tin (AI)"); assert.equal(JSON.parse(row.questions).length, 2); assert.equal(row.purpose, "Vì sao nhân viên mới hay nghỉ");
await alice.open("/create");
alice.click("#mScratch");
await alice.waitFor(() => db("SELECT COUNT(*) AS n FROM surveys").n === 3, "tạo từ đầu");
const sid = db("SELECT id FROM surveys WHERE questions = '[]'").id;
ok("tạo khảo sát: thư viện 20 mẫu (tìm, xem trước, dùng mẫu), từ ý tưởng bằng AI, từ đầu; thanh bên");

// Trinh soan: AI goi y + sua cau hoi + tu dong luu + dang
await alice.open(`/edit?id=${sid}`);
await alice.waitFor(() => alice.$("#topic option"), "trình soạn tải xong");
assert.equal(alice.text(".st4 .on"), "1. Thiết kế"); assert.ok(alice.$(".st4 span"), "chưa đăng: bước Kết quả bị khóa");
alice.type("#purpose", "Đánh giá căng tin trường");
alice.click("#btnSuggest");
await alice.waitFor(() => !alice.$("#sugBox").classList.contains("hidden"), "hiện gợi ý AI");
assert.equal(alice.d.querySelectorAll("#sugList .sug-item").length, 2);
alice.click("#sugAppend");
await alice.waitFor(() => alice.d.querySelectorAll(".qedit").length === 2, "thêm 2 câu gợi ý");
assert.equal(alice.$("#title").value, "Khảo sát căng tin (AI)", "điền sẵn tiêu đề gợi ý khi đang trống");
alice.$("#newType").value = "open_text"; alice.click("#btnAdd");
alice.type('.qedit[data-i="2"] textarea[data-f="question"]', "Bạn muốn cải thiện gì?");
alice.click('.qedit[data-i="0"] [data-a="opt-add"]');
alice.type('.qedit[data-i="0"] [data-opt="2"]', "Năm 3");
const req = alice.$('.qedit[data-i="0"] [data-f="required"]'); req.checked = true; req.dispatchEvent(new alice.w.Event("change", { bubbles: true }));
alice.click('.qedit[data-i="2"] [data-a="up"]');
alice.type("#visibility", "public");
alice.type("#topic", "gan_ket");
await alice.waitFor(() => alice.text("#saveState").startsWith("Đã lưu lúc"), "tự động lưu", 6000);
assert.equal(alice.text(".sbt b"), "Khảo sát căng tin (AI)", "thanh khảo sát cập nhật tiêu đề");
let saved = JSON.parse(db("SELECT questions FROM surveys WHERE id = ?", sid).questions);
assert.deepEqual(saved.map(q => q.type), ["single_choice", "open_text", "rating"], "đổi thứ tự câu hỏi");
assert.deepEqual(saved[0].options, ["Năm 1", "Năm 2", "Năm 3"]); assert.equal(saved[0].required, true);
alice.click("#btnPublish");
await alice.waitFor(() => db("SELECT status FROM surveys WHERE id = ?", sid).status === "published", "đăng khảo sát");
ok("trình soạn: thanh bước, AI gợi ý → chọn câu → thêm/sửa đáp án, bắt buộc, đổi thứ tự → tự lưu → đăng");

// Chia se
await alice.open(`/share?id=${sid}&published=1`);
await alice.waitFor(() => !alice.$("#liveBox").classList.contains("hidden"), "trang chia sẻ");
assert.ok(alice.$("#link").value.endsWith(`/s/${sid}`)); assert.equal(alice.text(".st4 .on"), "2. Chia sẻ");
assert.ok(!alice.$("#pubNote").classList.contains("hidden")); assert.ok(alice.$("#qrDownload").href.startsWith("data:image/png"), "mã QR");
alice.$("#dlInput").value = alice.w.eval("toLocalInput(Date.now() / 1000 + 3 * 86400 + 120)");
alice.click("#btnDl");
await alice.waitFor(() => db("SELECT closes_at FROM surveys WHERE id = ?", sid).closes_at > Date.now() / 1000 + 2 * 86400, "đặt hạn chót");
await alice.waitFor(() => alice.text("#dlState").includes("còn 3 ngày"), "hiện thời gian còn lại");
ok("chia sẻ: link, mã QR tải về được, thông báo vừa đăng, đặt hạn chót tự đóng");

// Tim kiem cong khai
await guest.open("/");
await guest.waitFor(() => guest.d.querySelectorAll(".scard").length === 1, "thấy khảo sát trên trang chủ");
guest.type("#q", "cang tin"); guest.submit("#searchForm");
await guest.waitFor(() => guest.d.querySelectorAll(".scard").length === 1 && guest.text(".scard h4").includes("căng tin"), "tìm không dấu");
guest.click('.chip[data-t="suc_khoe"]');
await guest.waitFor(() => !guest.$("#empty").classList.contains("hidden"), "lọc chủ đề khác → rỗng");
guest.click('.chip[data-t="gan_ket"]');
await guest.waitFor(() => guest.d.querySelectorAll(".scard").length === 1, "lọc đúng chủ đề nhân sự");
ok("trang chủ: hiện khảo sát công khai, tìm không dấu, lọc chủ đề nhân sự");

// Khach mo link -> phai dang nhap
await guest.open(`/s/${sid}`);
await guest.waitFor(() => !guest.$("#message").classList.contains("hidden"), "thông báo cần đăng nhập");
assert.match(guest.text("#msgText"), /cần đăng nhập/);
assert.ok(guest.$("#msgActions a").href.includes(`/login?next=${encodeURIComponent(`/s/${sid}`)}`));
ok("khách mở link: yêu cầu đăng nhập, quay lại đúng khảo sát sau khi đăng nhập");

// Bob tra loi
await bob.open(`/s/${sid}`);
await bob.waitFor(() => !bob.$("#surveyView").classList.contains("hidden"), "hiện bảng câu hỏi");
assert.match(bob.text("#privacy"), /sẽ thấy họ tên và email/);
assert.match(bob.text("#deadline"), /Hạn chót.*còn 3 ngày/, "người trả lời thấy hạn chót");
bob.click("#btnSubmit");
await bob.waitFor(() => bob.text("#err").includes("bắt buộc"), "báo thiếu câu bắt buộc");
bob.click('#questions .q:first-child input[value="Năm 2"]');
bob.type('textarea[name]', "Giá đắt quá");
bob.click(bob.d.querySelector('.stars label[title="4 sao"]'));
bob.click("#btnSubmit");
await bob.waitFor(() => bob.text("#msgTitle") === "Cảm ơn bạn!", "gửi thành công");
const ansRow = db("SELECT answers, duration FROM responses");
const ans = JSON.parse(ansRow.answers);
assert.equal(ans[saved[0].id], "Năm 2"); assert.equal(Object.values(ans).includes(4), true, "chấm 4 sao");
assert.ok(ansRow.duration === null || ansRow.duration >= 0, "ghi thời gian làm bài");
await bob.open(`/s/${sid}`);
await bob.waitFor(() => bob.text("#msgTitle").includes("đã trả lời"), "mở lại → đã trả lời");
await bob.open("/answered");
await bob.waitFor(() => bob.d.querySelectorAll("#list tr").length === 1, "trang đã trả lời");
ok("trả lời: thông báo quyền riêng tư, báo câu bắt buộc, chọn sao, gửi; mở lại thấy 'đã trả lời'");

// Nguoi tao mo link cua minh
await alice.open(`/s/${sid}`);
await alice.waitFor(() => alice.text("#previewNote").includes("người tạo"), "người tạo không tự trả lời");
ok("người tạo mở link: chỉ xem giao diện, không có nút gửi");

// Ket qua + phan tich AI
await alice.open(`/results?id=${sid}`);
await alice.waitFor(() => alice.text("#kpis").includes("1"), "KPI tổng câu trả lời");
assert.equal(alice.text(".st4 .on"), "3. Kết quả");
assert.ok(alice.d.querySelectorAll("#stats .qc .hr").length > 0, "biểu đồ thanh ngang");
const ct = alice.$("#stats select[data-ct]"); ct.value = "v"; ct.dispatchEvent(new alice.w.Event("change", { bubbles: true }));
await alice.waitFor(() => alice.$("#stats .vch"), "đổi sang cột dọc");
alice.click('.stab button[data-tab="ind"]');
await alice.waitFor(() => alice.text("#indTable").includes("Bob Trần"), "bảng phản hồi cá nhân");
alice.click("#indTable tr[data-i]");
assert.ok(!alice.$("#drawer").classList.contains("hidden") && alice.text("#drawer").includes("Giá đắt quá"), "ngăn kéo câu trả lời đầy đủ");
alice.click('#drawer [data-a="close"]');
alice.click('#view button[data-v="one"]');
assert.ok(!alice.$("#indOne").classList.contains("hidden") && alice.text("#indOne").includes("1 / 1"), "xem từng người");
alice.click('.stab button[data-tab="sum"]');
alice.$("#fq").value = saved[0].id; alice.$("#fq").dispatchEvent(new alice.w.Event("change"));
await alice.waitFor(() => alice.$("#fv option"), "chọn giá trị lọc");
alice.$("#fv").value = "Năm 1"; alice.$("#fv").dispatchEvent(new alice.w.Event("change"));
await alice.waitFor(() => alice.text("#stats").includes("Không có câu trả lời nào khớp"), "lọc Năm 1 → 0");
alice.click('.stab button[data-tab="ai"]');
assert.match(alice.text("#hrNote"), /nguy cơ nghỉ việc/);
alice.click("#btnAnalyze");
await alice.waitFor(() => alice.text("#report").includes("Tóm tắt kiểm thử."), "báo cáo AI");
assert.ok(alice.$('#report a[data-ev="C1"]'), "mã bằng chứng C1");
assert.ok(alice.$("#report .risk"), "khối nguy cơ nghỉ việc");
assert.ok(alice.$("#btnPdf").href.endsWith(`/report?id=${sid}`), "nút báo cáo PDF");
await alice.open(`/report?id=${sid}`);
await alice.waitFor(() => alice.text("#doc").includes("Tóm tắt kiểm thử."), "trang báo cáo in: có phân tích AI");
assert.match(alice.text("#doc"), /Kết quả từng câu hỏi/); assert.match(alice.text(".pmeta"), /Số câu trả lời\s*1/);
assert.ok(alice.$("#btnPrint"), "nút In / Lưu PDF");
ok("kết quả: KPI, đổi kiểu biểu đồ, phản hồi cá nhân (bảng, ngăn kéo, từng người), lọc, phân tích AI nhân sự; báo cáo PDF");

// Sua noi dung -> phien ban moi
await alice.open(`/share?id=${sid}`);
await alice.waitFor(() => !alice.$("#liveBox").classList.contains("hidden"), "trang chia sẻ");
alice.click("#btnRevise");
await alice.waitFor(() => db("SELECT COUNT(*) AS n FROM surveys WHERE parent_id = ?", sid).n === 1, "tạo phiên bản mới");
const v2 = db("SELECT id FROM surveys WHERE parent_id = ?", sid).id;
await alice.open(`/edit?id=${v2}`);
await alice.waitFor(() => !alice.$("#revNote").classList.contains("hidden"), "ghi chú phiên bản");
assert.match(alice.text("#revNote"), /phiên bản 2/);
alice.click("#btnPublish");
await alice.waitFor(() => db("SELECT status FROM surveys WHERE id = ?", sid).status === "closed", "bản cũ tự đóng");
await bob.open(`/s/${sid}`);
await bob.waitFor(() => bob.text("#msgText").includes("phiên bản mới"), "link cũ trỏ sang bản mới");
assert.ok(bob.$("#msgActions a").href.endsWith(`/s/${v2}`));
ok("sửa nội dung → bản nháp v2 → đăng → bản cũ đóng, link cũ trỏ sang bản mới");

// Danh sach khao sat cua toi
await alice.open("/dashboard");
await alice.waitFor(() => alice.d.querySelectorAll("#list .item").length === 4, "4 khảo sát");
alice.$("#fStatus").value = "draft"; alice.$("#fStatus").dispatchEvent(new alice.w.Event("change"));
assert.equal(alice.d.querySelectorAll("#list .item").length, 2, "lọc nháp");
alice.$("#fStatus").value = ""; alice.type("#fText", "nghi viec");
assert.equal(alice.d.querySelectorAll("#list .item").length, 1, "tìm không dấu");
ok("khảo sát của tôi: lọc theo trạng thái, tìm không dấu");

// Bao cao + admin
await bob.open(`/s/${v2}`);
await bob.waitFor(() => !bob.$("#surveyView").classList.contains("hidden"), "mở v2");
bob.click("#btnReport"); bob.type("#reason", "Nội dung thử nghiệm báo cáo"); bob.click("#btnSendReport");
await bob.waitFor(() => bob.$("#btnReport").disabled, "đã gửi báo cáo");
await alice.open("/admin");
await alice.waitFor(() => alice.text("main").includes("Chỉ quản trị viên"), "người thường bị chặn khỏi trang admin");
await admin.open("/admin");
await admin.waitFor(() => admin.text("#kpis").includes("Người dùng"), "admin tổng quan");
assert.match(admin.text(".ab"), /Quản trị/);
admin.click('.stab button[data-tab="reports"]');
await admin.waitFor(() => admin.text("#reports").includes("Nội dung thử nghiệm báo cáo"), "danh sách báo cáo");
admin.click('#reports [data-act="hide"]');
await admin.waitFor(() => db("SELECT hidden FROM surveys WHERE id = ?", v2).hidden === 1, "ẩn khảo sát");
admin.click('.stab button[data-tab="users"]');
await admin.waitFor(() => admin.text("#users").includes("bob@test.vn"), "danh sách người dùng");
const bobRow = [...admin.d.querySelectorAll("#users tr")].find(tr => tr.textContent.includes("bob@test.vn"));
bobRow.querySelector('[data-k="quota_gen"]').value = "3";
bobRow.querySelector('[data-k="quota_gen"]').dispatchEvent(new admin.w.Event("change", { bubbles: true }));
await admin.waitFor(() => db("SELECT quota_gen FROM users WHERE email = 'bob@test.vn'").quota_gen === 3, "đặt hạn mức");
bobRow.querySelector("[data-lock]").click();
await admin.waitFor(() => db("SELECT locked FROM users WHERE email = 'bob@test.vn'").locked === 1, "khóa Bob");
ok("báo cáo vi phạm → admin ẩn khảo sát, chỉnh hạn mức, khóa tài khoản; người thường không vào được trang admin");

// Chi HR moi tao hop thu: Alice chua co quyen -> admin cap quyen HR o trang Quan tri
await alice.open("/feedback");
await alice.waitFor(() => !alice.$("#notHr").classList.contains("hidden"), "chưa phải HR: thông báo");
assert.ok(!alice.text(".ab").includes("Hộp thư góp ý"), "không có tab Hộp thư góp ý");
await admin.open("/admin");
admin.click('.stab button[data-tab="users"]');
await admin.waitFor(() => admin.text("#users").includes("alice@test.vn"), "danh sách người dùng");
const aliceRow = [...admin.d.querySelectorAll("#users tr")].find(tr => tr.textContent.includes("alice@test.vn"));
aliceRow.querySelector("[data-hr]").checked = true;
aliceRow.querySelector("[data-hr]").dispatchEvent(new admin.w.Event("change", { bubbles: true }));
await admin.waitFor(() => db("SELECT role FROM users WHERE email = 'alice@test.vn'").role === "hr", "cấp quyền HR");
// Admin tao tai khoan HR moi; HR dang nhap, doi mat khau
admin.type("#hrUser", "Hr_account"); admin.type("#hrName", "Phòng Nhân sự"); admin.type("#hrPass", "Hr-mat-khau-1"); admin.submit("#newHr");
await admin.waitFor(() => !admin.$("#hrOk").classList.contains("hidden"), "tạo tài khoản HR");
await admin.waitFor(() => admin.text("#users").includes("@Hr_account"), "HR hiện trong danh sách");
const hrB = new Browser("10.0.0.7");
await hrB.open("/login?next=/feedback");
hrB.type("#email", "Hr_account"); hrB.type("#password", "Hr-mat-khau-1"); hrB.submit("#form");
await hrB.waitFor(() => hrB.jar.ks_sess, "HR đăng nhập");
await hrB.open("/welcome?next=/account"); // tai khoan moi: dong y dieu khoan truoc
await hrB.waitFor(() => hrB.text("#hello").includes("Phòng Nhân sự"), "chào mừng HR");
hrB.click("#c1"); hrB.click("#btn");
await hrB.waitFor(() => db("SELECT terms_at FROM users WHERE username = 'Hr_account'").terms_at, "HR đồng ý điều khoản");
await hrB.open("/account");
assert.match(hrB.text("#ident"), /Hr_account/); assert.match(hrB.text("#roleLine"), /HR/);
hrB.type("#current", "Hr-mat-khau-1"); hrB.type("#password", "Moi-mat-khau-2"); hrB.type("#password2", "Moi-mat-khau-2"); hrB.submit("#form");
await hrB.waitFor(() => !hrB.$("#done").classList.contains("hidden"), "đổi mật khẩu");
ok("phân quyền HR: người thường không thấy hộp thư; admin cấp quyền HR, tạo tài khoản HR; HR đăng nhập, đổi mật khẩu");

// Hop thu gop y: HR tao hop -> nhan vien gui an danh -> HR tra loi -> AI cham + bieu do
await alice.open("/feedback");
await alice.waitFor(() => alice.$("#hubLink").value.includes("/gopy?h="), "link chung");
assert.ok(alice.$(".sd .si2.on")?.textContent.includes("Hộp thư góp ý"), "thanh bên");
assert.ok(alice.$("#qrDownload").href.startsWith("data:image/png"), "mã QR");
assert.ok(!alice.$("#noBox").classList.contains("hidden"), "chưa có hộp thư");
for (const name of ["Phòng Kỹ thuật", "Phòng Kinh doanh"]) {
  alice.type("#nbName", name); alice.submit("#newBox");
  await alice.waitFor(() => alice.text("#boxList").includes(name), `tạo ${name}`);
}
alice.type("#hubTitle", "Công ty ABC"); alice.click("#btnTitle");
await alice.waitFor(() => db("SELECT fb_title FROM users WHERE email = 'alice@test.vn'").fb_title === "Công ty ABC", "lưu tên công ty");
const hubUrl = new URL(alice.$("#hubLink").value);
await guest.open(hubUrl.pathname + hubUrl.search);
await guest.waitFor(() => guest.d.querySelectorAll("#hubBoxes a").length === 2, "trang chọn hộp thư");
assert.equal(guest.text("#hubTitle"), "Công ty ABC");
const ktLink = [...guest.d.querySelectorAll("#hubBoxes a")].find(a => a.textContent.includes("Kỹ thuật")).getAttribute("href");
await guest.open(ktLink);
await guest.waitFor(() => !guest.$("#boxView").classList.contains("hidden"), "trang gửi góp ý");
assert.ok(!guest.$("#loginBox").classList.contains("hidden") && guest.$("#form").classList.contains("hidden"), "khách phải đăng nhập");
assert.ok(guest.$("#btnLogin").href.includes("next=%2Fgopy"), "đăng nhập xong quay lại hộp thư");
await dung.open(ktLink);
await dung.waitFor(() => !dung.$("#form").classList.contains("hidden"), "form góp ý");
assert.match(dung.text("#boxView .notice"), /không thấy/);
dung.click('#topics [data-topic="quan_ly"]');
dung.type("#content", "ngắn"); dung.submit("#form");
await dung.waitFor(() => dung.text("#err").includes("10 ký tự"), "báo nội dung quá ngắn");
dung.type("#content", "Trưởng phòng không lắng nghe ý kiến, làm việc rất tệ"); dung.submit("#form");
await dung.waitFor(() => dung.text("#msgTitle").includes("Đã gửi"), "gửi thành công");
await dung.open(ktLink.replace(/b=[a-f0-9]+/, "b=" + db("SELECT id FROM fb_boxes WHERE name = 'Phòng Kinh doanh'").id));
await dung.waitFor(() => !dung.$("#form").classList.contains("hidden"), "form hộp 2");
dung.type("#content", "Cảm ơn công ty, môi trường làm việc rất tốt"); dung.submit("#form");
await dung.waitFor(() => dung.text("#msgTitle").includes("Đã gửi"), "gửi thư 2");
assert.equal(db("SELECT topic FROM fb_letters WHERE content LIKE 'Trưởng phòng%'").topic, "quan_ly");
await alice.open(ktLink);
await alice.waitFor(() => !alice.$("#ownerNote").classList.contains("hidden"), "HR mở hộp của mình: chỉ xem");
assert.equal(alice.$("#btnSend").disabled, true);
ok("hộp thư: HR tạo hộp theo phòng ban + link chung/QR; nhân viên chọn hộp, chọn chủ đề, gửi (khách phải đăng nhập)");

await alice.open("/feedback#letters");
await alice.waitFor(() => alice.d.querySelectorAll("#letters .fbl").length === 2, "HR thấy 2 thư");
assert.ok(!alice.text("#letters").includes("Dũng") && !alice.text("#letters").includes("dung@gmail.com"), "HR không thấy người gửi");
assert.match(alice.text("#newCount"), /2 mới/);
const fbl = [...alice.d.querySelectorAll("#letters .fbl")].find(x => x.textContent.includes("Trưởng phòng"));
fbl.querySelector('[data-act="reply"]').click();
fbl.querySelector("textarea").value = "Cảm ơn bạn, mình sẽ trao đổi với trưởng phòng.";
fbl.querySelector("form").dispatchEvent(new alice.w.Event("submit", { bubbles: true, cancelable: true }));
await alice.waitFor(() => db("SELECT status FROM fb_letters WHERE content LIKE 'Trưởng phòng%'").status === "done", "trả lời → đã xử lý");
await alice.waitFor(() => alice.text("#letters").includes("Phản hồi của bạn"), "hiện phản hồi");
alice.$("#fBox").value = db("SELECT id FROM fb_boxes WHERE name = 'Phòng Kinh doanh'").id; alice.$("#fBox").dispatchEvent(new alice.w.Event("change"));
await alice.waitFor(() => alice.d.querySelectorAll("#letters .fbl").length === 1 && alice.text("#lCount").includes("khớp bộ lọc"), "lọc theo hộp thư");
await dung.open("/my-feedback");
await dung.waitFor(() => dung.d.querySelectorAll("#list .fbl").length === 2, "thư tôi đã gửi");
assert.match(dung.text("#list"), /Cảm ơn bạn, mình sẽ trao đổi/);
ok("HR đọc thư (không thấy người gửi), lọc, trả lời; nhân viên thấy phản hồi ở “Thư tôi đã gửi”");

await alice.open("/feedback#ana");
await alice.waitFor(() => alice.text("#charts").includes("Chưa có thư nào được chấm"), "chưa chấm");
alice.click("#btnAnalyze");
await alice.waitFor(() => alice.text("#report").includes("Tình hình góp ý kiểm thử."), "báo cáo AI hộp thư");
await alice.waitFor(() => alice.text("#charts").includes("So sánh giữa các phòng ban"), "biểu đồ so sánh phòng ban");
assert.deepEqual(db("SELECT GROUP_CONCAT(sat) AS s FROM (SELECT sat FROM fb_letters ORDER BY id)").s, "1,4");
assert.ok(alice.$("#charts .stk i[data-sat]"), "thanh xếp chồng 5 mức");
assert.ok(alice.$('#report a[data-ev^="T"]'), "mã thư trích dẫn");
assert.match(alice.text("#report"), /Phòng cần chú ý nhất: Phòng Kỹ thuật/);
assert.match(alice.text("#charts"), /Xu hướng/);
alice.click('#charts .hr.click[data-sat="1"]');
await alice.waitFor(() => !alice.$("#tab-letters").classList.contains("hidden") && alice.$("#fSat").value === "1"
  && alice.d.querySelectorAll("#letters .fbl").length === 1, "bấm cột biểu đồ → danh sách thư mức 1");
const satSel = alice.$('#letters select[data-act="sat"]'); satSel.value = "2"; satSel.dispatchEvent(new alice.w.Event("change", { bubbles: true }));
await alice.waitFor(() => db("SELECT sat_by FROM fb_letters WHERE content LIKE 'Trưởng phòng%'").sat_by === "hr", "HR sửa mức hài lòng");
await alice.open("/feedback-report?scope=all&period=30");
await alice.waitFor(() => alice.text("#doc").includes("Tình hình góp ý kiểm thử."), "báo cáo PDF hộp thư");
assert.match(alice.text("#doc"), /So sánh giữa các phòng ban/); assert.match(alice.text(".pmeta"), /Công ty ABC/);
ok("đánh giá tình hình: AI chấm từng thư → biểu đồ (phân bố, phòng ban, chủ đề, xu hướng) + báo cáo; bấm biểu đồ → thư; HR sửa điểm");

const aliceId = db("SELECT id FROM users WHERE email = 'alice@test.vn'").id;
await admin.open(`/feedback?owner=${aliceId}`);
await admin.waitFor(() => !admin.$("#adminNote").classList.contains("hidden") && admin.text("#boxList").includes("Phòng Kỹ thuật"), "admin xem hộp thư của Alice");
await admin.open("/admin");
await admin.waitFor(() => admin.text("#kpis").includes("Thư góp ý"), "thống kê thư góp ý");
ok("admin: xem hộp thư của người dùng, thống kê thư góp ý");

// Dang xuat
await alice.open("/dashboard");
await alice.waitFor(() => alice.$("#navLogout"), "nút đăng xuất");
alice.click("#navLogout");
await alice.waitFor(() => !alice.jar.ks_sess, "đăng xuất");
ok("đăng xuất");

const errs = [alice, bob, admin, guest, dung, hrB].flatMap(b => b.errors);
assert.deepEqual(errs, [], "không có lỗi JavaScript trên trang");
console.log("\nKhông có lỗi JavaScript nào trên các trang. Tất cả kiểm thử giao diện đều đạt.");
process.exit(0);
