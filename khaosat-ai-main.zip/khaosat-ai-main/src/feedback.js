// Hop thu gop y.
// - HR tao hop thu (moi phong ban mot hop) + mot link chung liet ke cac hop.
// - Nhan vien PHAI dang nhap de gui (chong spam, gioi han/ngay, xem lai thu cua minh) nhung HR KHONG BAO GIO biet nguoi gui.
// - AI cham muc hai long (1-5) TUNG THU, ket qua duoc luu lai; bieu do do code tu dem -> khop voi du lieu, kiem chung duoc.
// - AI viet danh gia tong quan cho "tat ca phong ban" hoac tung phong ban.
import { HttpError, json, readJson, now, randomHex, vnDay } from "./http.js";
import { currentUser, requireUser } from "./auth.js";
import { llmJson, WaitSignal } from "./llm.js";

export const FB_TOPICS = { quan_ly: "Quản lý", luong_thuong: "Lương thưởng", moi_truong: "Môi trường làm việc",
  dong_nghiep: "Đồng nghiệp", phat_trien: "Phát triển", khac: "Khác" };
export const SAT_LABELS = { 1: "Rất không hài lòng", 2: "Không hài lòng", 3: "Trung lập", 4: "Hài lòng", 5: "Rất hài lòng" };
const STATUSES = ["new", "doing", "done"];
const PERIODS = { 30: "30 ngày qua", 90: "90 ngày qua", all: "toàn bộ thời gian" };
const PERIOD_DAYS = { 30: 30, 90: 90, all: null };
const DAILY_LIMIT = 5;      // so thu moi nguoi duoc gui moi ngay
const MAX_BOXES = 50;
const MAX_CHARS = 2000;
const MAX_LETTERS = 200;    // so thu gan nhat dua vao moi lan phan tich
const SCORE_BATCH = 20;     // so thu moi lan goi AI cham diem
const SCORE_CHARS = 500;    // cat thu dai khi gui AI cham diem
const SAMPLE = 40;          // so thu trich dan gui AI o buoc tong ket
const SAMPLE_CHARS = 300;
const MAX_STEPS = Math.ceil(MAX_LETTERS / SCORE_BATCH) + 3;
const RISK_LEVELS = ["cao", "trung_binh", "thap", "khong_ro"];
const SEVERITY_ORDER = { cao: 0, trung_binh: 1, thap: 2 };

const mean = (v) => (v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 100) / 100 : null);
const topicOf = (l) => (l.topic === "khac" && l.ai_topic ? l.ai_topic : l.topic);
const TOPIC_SQL = "(CASE WHEN l.topic = 'khac' AND l.ai_topic IS NOT NULL THEN l.ai_topic ELSE l.topic END)";
const validBoxId = (id) => /^[a-f0-9]{10}$/.test(id || "");
const clean = (s, max) => String(s ?? "").replace(/\r\n/g, "\n").trim().slice(0, max);

// Thu gui cho HR: KHONG co user_id / ten / email / gio gui
const hrLetter = (l) => ({
  id: l.id, box_id: l.box_id, box_name: l.box_name, topic: topicOf(l), topic_label: FB_TOPICS[topicOf(l)] || FB_TOPICS.khac,
  topic_by_ai: l.topic === "khac" && !!l.ai_topic, content: l.content, day: l.day, status: l.status, reply: l.reply || "",
  hidden: !!l.hidden, sat: l.sat ?? null, sat_by: l.sat_by || null,
});

// ------------------------------------------------------------ thong ke ----
const SATS = [1, 2, 3, 4, 5];
function summarize(list) {
  const s = list.filter(l => SATS.includes(l.sat));
  const dist = Object.fromEntries(SATS.map(k => [k, 0]));
  for (const l of s) dist[l.sat] += 1;
  return { n: list.length, scored: s.length, dist, mean: mean(s.map(l => l.sat)),
    neg_pct: s.length ? Math.round(100 * s.filter(l => l.sat <= 2).length / s.length) : null };
}

function topTopic(list) {
  const neg = list.filter(l => l.sat && l.sat <= 2);
  const src = neg.length ? neg : list;
  const c = {};
  for (const l of src) c[topicOf(l)] = (c[topicOf(l)] || 0) + 1;
  const best = Object.entries(c).sort((a, b) => b[1] - a[1])[0];
  return best ? FB_TOPICS[best[0]] : null;
}

function bucket(day, unit) {
  if (unit === "month") return day.slice(0, 7);
  const d = new Date(day + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7)); // ve thu Hai dau tuan
  return d.toISOString().slice(0, 10);
}

// Tinh hoan toan bang code tu muc hai long da luu cua tung thu
export function fbStats(letters, boxes, period) {
  const unit = period === "all" ? "month" : "week";
  const by_topic = Object.entries(FB_TOPICS).map(([key, label]) => ({ key, label, ...summarize(letters.filter(l => topicOf(l) === key)) }))
    .filter(t => t.n);
  const by_box = boxes.map(b => {
    const list = letters.filter(l => l.box_id === b.id);
    return { id: b.id, name: b.name, ...summarize(list), top_topic: topTopic(list) };
  });
  const groups = new Map();
  for (const l of letters) {
    const k = bucket(l.day, unit);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(l);
  }
  const trend = [...groups.keys()].sort().slice(-12).map(k => ({ key: k, ...summarize(groups.get(k)) }));
  return { period, unit, ...summarize(letters), by_topic, by_box, trend };
}

// ------------------------------------------------------------ AI ----
const SCORE_SCHEMA = {
  type: "object",
  properties: { items: { type: "array", items: { type: "object",
    properties: { id: { type: "integer" }, sat: { type: "integer" }, topic: { type: "string", enum: Object.keys(FB_TOPICS) } },
    required: ["id", "sat", "topic"] } } },
  required: ["items"],
};

export async function scoreLetters(ctx, llm, letters) {
  const topics = Object.entries(FB_TOPICS).map(([k, v]) => `${k} (${v})`).join(", ");
  const system = "Bạn là chuyên viên nhân sự. Bạn đọc thư góp ý ẩn danh của nhân viên và chấm mức độ hài lòng THỂ HIỆN TRONG TỪNG THƯ. " +
    "Chỉ dựa vào nội dung thư, không suy diễn thêm.";
  const user = `Thang điểm "sat":
1 = Rất không hài lòng (bức xúc mạnh, bị đối xử tệ, muốn nghỉ việc, vấn đề nghiêm trọng)
2 = Không hài lòng (than phiền, chỉ ra vấn đề)
3 = Trung lập (đề xuất hoặc hỏi thông tin, không rõ thái độ)
4 = Hài lòng (nhìn chung tích cực, góp ý nhẹ)
5 = Rất hài lòng (khen ngợi, cảm ơn rõ ràng)
"topic": chủ đề chính dựa vào NỘI DUNG thư (không phụ thuộc chủ đề nhân viên đã chọn), một trong: ${topics}.
Chỉ chọn "khac" khi nội dung thật sự không thuộc chủ đề nào ở trên (vd. làm thêm giờ, phòng họp, thiết bị → moi_truong; OT không trả lương → luong_thuong).

Các thư (số trong ngoặc vuông là mã thư):
${letters.map(l => `[${l.id}] (nhân viên chọn chủ đề: ${FB_TOPICS[l.topic] || "Khác"}) ${l.content.slice(0, SCORE_CHARS).replace(/\s+/g, " ")}`).join("\n")}

Trả về đúng một mục cho MỖI thư, "id" là mã thư.`;
  const out = await llmJson(ctx, llm, system, user, SCORE_SCHEMA, { temperature: 0.1, effort: "low" });
  const valid = new Set(letters.map(l => l.id)), seen = new Set(), res = [];
  for (const it of out.items || []) {
    if (!valid.has(it.id) || seen.has(it.id)) continue;
    const sat = Math.round(Number(it.sat));
    if (!SATS.includes(sat)) continue;
    seen.add(it.id);
    res.push({ id: it.id, sat, topic: FB_TOPICS[it.topic] ? it.topic : "khac" });
  }
  return res;
}

const EVIDENCE = { type: "array", items: { type: "string" } };
const ITEM = { type: "object", properties: { text: { type: "string" }, evidence: EVIDENCE }, required: ["text", "evidence"] };
const SUMMARY_SCHEMA = {
  type: "object",
  properties: {
    overview: { type: "string" },
    issues: { type: "array", items: { type: "object",
      properties: { text: { type: "string" }, severity: { type: "string", enum: ["cao", "trung_binh", "thap"] }, evidence: EVIDENCE },
      required: ["text", "severity", "evidence"] } },
    positives: { type: "array", items: ITEM },
    retention_risk: { type: "object", properties: { level: { type: "string", enum: RISK_LEVELS }, reason: { type: "string" }, evidence: EVIDENCE },
      required: ["level", "reason", "evidence"] },
    quick_actions: { type: "array", items: ITEM },
    departments: { type: "array", items: { type: "object", properties: { name: { type: "string" }, main_issue: { type: "string" } },
      required: ["name", "main_issue"] } },
    focus: { type: "object", properties: { name: { type: "string" }, reason: { type: "string" } }, required: ["name", "reason"] },
    limitations: { type: "string" },
  },
  required: ["overview", "issues", "positives", "retention_risk", "quick_actions", "departments", "focus", "limitations"],
};

const pct = (k, s) => (s.scored ? Math.round(100 * s.dist[k] / s.scored) : 0);
function describe(stats, isAll, scopeName) {
  const line = (s) => `${s.n} thư, chỉ số hài lòng ${s.mean ?? "–"}/5, tiêu cực (mức 1-2) ${s.neg_pct ?? "–"}%`;
  const out = [`Phạm vi: ${scopeName}. Khoảng thời gian: ${PERIODS[stats.period]}.`,
    `Tổng: ${stats.n} thư (đã chấm mức hài lòng: ${stats.scored}). Chỉ số hài lòng trung bình: ${stats.mean ?? "–"}/5.`,
    `Phân bố: ` + SATS.map(k => `${SAT_LABELS[k]} ${stats.dist[k]} (${pct(k, stats)}%)`).join("; ") + ".",
    `\nTheo chủ đề:`, ...stats.by_topic.map(t => `- ${t.label}: ${line(t)}`)];
  if (isAll) out.push(`\nTheo phòng ban (mỗi hộp thư là một phòng ban):`,
    ...stats.by_box.map(b => `- ${b.name}: ${b.n ? line(b) + (b.top_topic ? `, chủ đề nổi bật: ${b.top_topic}` : "") : "chưa có thư"}`));
  if (stats.trend.length > 1) out.push(`\nXu hướng theo ${stats.unit === "month" ? "tháng" : "tuần (ngày đầu tuần)"}:`,
    stats.trend.map(t => `${t.key}: TB ${t.mean ?? "–"} (${t.n} thư)`).join("; "));
  return out.join("\n");
}

// Chon thu trich dan: uu tien thu tieu cuc, lan luot qua cac phong ban de khong bi lech ve mot phong
function pickSample(letters) {
  const byBox = new Map();
  for (const l of [...letters].sort((a, b) => (a.sat ?? 3) - (b.sat ?? 3) || b.id - a.id)) {
    if (!byBox.has(l.box_id)) byBox.set(l.box_id, []);
    byBox.get(l.box_id).push(l);
  }
  const queues = [...byBox.values()], out = [];
  while (out.length < SAMPLE && queues.some(q => q.length)) for (const q of queues) if (q.length && out.length < SAMPLE) out.push(q.shift());
  return out;
}

export async function summarizeFeedback(ctx, llm, { letters, stats, isAll, scopeName, boxNames }) {
  const sample = pickSample(letters);
  const system = "Bạn là chuyên gia nhân sự, phân tích thư góp ý ẩn danh của nhân viên để giúp công ty giữ chân nhân viên. " +
    "Chỉ dựa vào dữ liệu được cung cấp, không bịa thêm, không tự tính lại các con số đã cho. Viết tiếng Việt có dấu, súc tích. " +
    "Không cố đoán danh tính người viết thư.";
  const user = `SỐ LIỆU (đã tính chính xác từ mức hài lòng của từng thư):
${describe(stats, isAll, scopeName)}

THƯ TRÍCH DẪN (mã T + số; ưu tiên thư tiêu cực; tối đa ${SAMPLE} thư):
${sample.map(l => `[T${l.id}] (${l.box_name} · ${FB_TOPICS[topicOf(l)]} · mức ${l.sat ?? "?"}) ${l.content.slice(0, SAMPLE_CHARS).replace(/\s+/g, " ")}`).join("\n")}

Hãy viết:
- overview: 2-4 câu đánh giá tình hình tổng quan, có con số.
- issues: các vấn đề nổi bật, xếp theo mức nghiêm trọng. "severity" (cao/trung_binh/thap) dựa trên mức ảnh hưởng (sức khỏe, an toàn, bị đối xử bất công, ý định nghỉ việc), không chỉ dựa vào số thư.
- positives: các điểm tích cực (để trống nếu không có).
- retention_risk: mức nguy cơ nghỉ việc (cao/trung_binh/thap) dựa trên thư; "reason" 1-2 câu. Nếu không đủ dữ liệu thì level = "khong_ro".
- quick_actions: 2-4 việc cụ thể HR làm được ngay trong 30 ngày tới.
${isAll ? `- departments: với MỖI phòng ban có thư, một dòng "main_issue" nêu vấn đề chính (tối đa 15 từ). "name" phải đúng tên phòng ban ở trên.
- focus: phòng ban cần chú ý nhất ("name" đúng tên ở trên) và "reason" 1 câu kèm con số. Nếu không có phòng nào nổi bật thì name = "".`
    : `- departments: để trống []. focus: name = "", reason = "".`}
- limitations: 1-2 câu về hạn chế (vd. người viết thư góp ý thường là người có điều chưa vui, số thư ít...).
Mỗi mục trong issues/positives/quick_actions và retention_risk có "evidence": danh sách mã thư làm bằng chứng (vd. "T12"). Không có bằng chứng thì không viết mục đó (riêng quick_actions có thể để trống evidence).`;
  const out = await llmJson(ctx, llm, system, user, SUMMARY_SCHEMA, { temperature: 0.2 });

  const valid = new Map(sample.map(l => [`t${l.id}`, l]));
  const cited = new Map();
  const cleanEv = (list) => {
    const ev = [];
    for (const c of Array.isArray(list) ? list : []) {
      const l = valid.get(String(c).trim().replace(/^\[|\]$/g, "").toLowerCase());
      if (l && !ev.includes(`T${l.id}`)) { ev.push(`T${l.id}`); cited.set(l.id, l); }
    }
    return ev;
  };
  const items = (list, needEv) => (Array.isArray(list) ? list : []).map(it => ({ ...it, text: String(it?.text || "").trim(), evidence: cleanEv(it?.evidence) }))
    .filter(it => it.text && (!needEv || it.evidence.length));
  const s = {
    overview: String(out.overview || "").trim(),
    issues: items(out.issues, true).map(it => ({ ...it, severity: SEVERITY_ORDER[it.severity] !== undefined ? it.severity : "trung_binh" }))
      .sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]),
    positives: items(out.positives, true),
    quick_actions: items(out.quick_actions, false),
    limitations: String(out.limitations || "").trim(),
  };
  const r = out.retention_risk || {};
  const rEv = cleanEv(r.evidence);
  s.retention_risk = { level: rEv.length && RISK_LEVELS.includes(r.level) ? r.level : "khong_ro", reason: String(r.reason || "").trim(), evidence: rEv };
  const names = new Set(boxNames);
  s.departments = isAll ? (Array.isArray(out.departments) ? out.departments : [])
    .filter(d => names.has(String(d?.name || "").trim()) && String(d.main_issue || "").trim())
    .map(d => ({ name: d.name.trim(), main_issue: d.main_issue.trim() })) : [];
  s.focus = isAll && names.has(String(out.focus?.name || "").trim()) ? { name: out.focus.name.trim(), reason: String(out.focus.reason || "").trim() } : null;
  if (stats.scored < 5) s.note = `Chỉ có ${stats.scored} thư được chấm, kết quả chỉ mang tính tham khảo.`;
  const quotes = Object.fromEntries([...cited.values()].map(l => [`T${l.id}`,
    { text: l.content.slice(0, 600), box: l.box_name, topic: FB_TOPICS[topicOf(l)], sat: l.sat ?? null, day: l.day }]));
  return { summary: s, quotes };
}

// ------------------------------------------------------------ routes ----
async function ensureHub(db, ownerId) {
  let u = await db.prepare("SELECT id, fb_hub, fb_title FROM users WHERE id = ?").bind(ownerId).first();
  if (!u) throw new HttpError(404, "Không tìm thấy người dùng.");
  if (!u.fb_hub) {
    await db.prepare("UPDATE users SET fb_hub = ? WHERE id = ? AND fb_hub IS NULL").bind(randomHex(5), ownerId).run();
    u = await db.prepare("SELECT id, fb_hub, fb_title FROM users WHERE id = ?").bind(ownerId).first();
  }
  return u;
}

async function ownBox(db, user, id) {
  const b = validBoxId(id) ? await db.prepare("SELECT * FROM fb_boxes WHERE id = ?").bind(id).first() : null;
  if (!b || (b.owner_id !== user.id && !user.is_admin)) throw new HttpError(404, "Không tìm thấy hộp thư.");
  return b;
}

async function boxesOf(db, ownerId) {
  return (await db.prepare("SELECT id, name FROM fb_boxes WHERE owner_id = ? ORDER BY created").bind(ownerId).all()).results;
}

// Pham vi phan tich: "all" (moi hop thu cua HR) hoac id mot hop thu
async function resolveScope(db, ownerId, scope, period) {
  if (!(String(period) in PERIODS)) throw new HttpError(400, "Khoảng thời gian không hợp lệ.");
  const boxes = await boxesOf(db, ownerId);
  if (scope === "all") return { boxes, isAll: true, scopeName: "Tất cả phòng ban" };
  const b = boxes.find(x => x.id === scope);
  if (!b) throw new HttpError(400, "Hộp thư không hợp lệ.");
  return { boxes: [b], isAll: false, scopeName: b.name };
}

async function scopeLetters(db, ownerId, scope, period, limit) {
  const where = ["b.owner_id = ?", "l.hidden = 0"], params = [ownerId];
  if (scope !== "all") { where.push("l.box_id = ?"); params.push(scope); }
  if (PERIOD_DAYS[period]) { where.push("l.created >= ?"); params.push(now() - PERIOD_DAYS[period] * 86400); }
  return (await db.prepare(
    `SELECT l.id, l.box_id, b.name AS box_name, l.topic, l.ai_topic, l.content, l.day, l.sat
     FROM fb_letters l JOIN fb_boxes b ON b.id = l.box_id WHERE ${where.join(" AND ")} ORDER BY l.id DESC LIMIT ?`)
    .bind(...params, limit).all()).results;
}

const runKey = (ownerId, scope, period) => `fb:${ownerId}:${scope}:${period}`;

async function checkRun(db, b, user, key) {
  const run = await db.prepare("SELECT * FROM analysis_runs WHERE id = ?").bind(String(b.run || "")).first();
  if (!run || run.survey_id !== key || run.user_id !== user.id || run.created < now() - 3600) {
    throw new HttpError(400, "Phiên phân tích không hợp lệ hoặc đã hết hạn. Hãy bấm phân tích lại.");
  }
  if (run.steps >= MAX_STEPS) throw new HttpError(429, "Phiên phân tích đã dùng quá số bước cho phép. Hãy bấm phân tích lại.");
  return run;
}

async function runStep(db, run, user, quota, fn) {
  await db.prepare("UPDATE analysis_runs SET steps = steps + 1 WHERE id = ?").bind(run.id).run();
  const usage = { tokens: 0, calls: 0 };
  try {
    const result = await fn(usage);
    await quota.add(user.id, "ana", 0, usage.tokens);
    return { result, usage };
  } catch (e) {
    if (e instanceof WaitSignal) await db.prepare("UPDATE analysis_runs SET steps = steps - 1 WHERE id = ?").bind(run.id).run();
    if (usage.tokens) await quota.add(user.id, "ana", 0, usage.tokens);
    throw e;
  }
}

export async function handleFeedback({ request, env, url, path, method, db, cfg, llm, quota }) {
  let m;

  // ---------------- Cong khai: trang hop thu cho nhan vien ----------------
  m = /^\/api\/fb\/hub\/([a-f0-9]{10})$/.exec(path);
  if (m && method === "GET") {
    const o = await db.prepare("SELECT id, fb_title, locked FROM users WHERE fb_hub = ?").bind(m[1]).first();
    if (!o || o.locked) throw new HttpError(404, "Không tìm thấy hộp thư góp ý.");
    const { results } = await db.prepare("SELECT id, name, description, status FROM fb_boxes WHERE owner_id = ? ORDER BY name").bind(o.id).all();
    return json({ title: o.fb_title || "", boxes: results });
  }

  m = /^\/api\/fb\/box\/([a-f0-9]{10})(\/letters)?$/.exec(path);
  if (m) {
    const box = await db.prepare(`SELECT b.*, u.fb_title, u.fb_hub, u.locked FROM fb_boxes b JOIN users u ON u.id = b.owner_id WHERE b.id = ?`)
      .bind(m[1]).first();
    if (!box || box.locked) throw new HttpError(404, "Không tìm thấy hộp thư góp ý.");
    const user = await currentUser(request, env);
    const sentToday = async () => user
      ? (await db.prepare("SELECT COUNT(*) AS n FROM fb_letters WHERE user_id = ? AND day = ?").bind(user.id, vnDay()).first()).n : 0;
    if (method === "GET" && !m[2]) {
      return json({ id: box.id, name: box.name, description: box.description, status: box.status, title: box.fb_title || "", hub: box.fb_hub,
        topics: FB_TOPICS, daily_limit: DAILY_LIMIT,
        viewer: { logged_in: !!user, is_owner: user?.id === box.owner_id, sent_today: await sentToday() } });
    }
    if (method === "POST" && m[2]) {
      if (!user) throw new HttpError(401, "Bạn cần đăng nhập để gửi góp ý.");
      if (user.id === box.owner_id) throw new HttpError(403, "Bạn là người tạo hộp thư này nên không thể tự gửi góp ý.");
      if (box.status !== "open") throw new HttpError(403, "Hộp thư này đang đóng, tạm thời không nhận góp ý.");
      const b = await readJson(request);
      const content = String(b.content ?? "").replace(/\r\n/g, "\n").trim();
      if (content.length < 10) throw new HttpError(400, "Nội dung góp ý cần ít nhất 10 ký tự.");
      if (content.length > MAX_CHARS) throw new HttpError(400, `Nội dung góp ý tối đa ${MAX_CHARS} ký tự.`);
      if (await sentToday() >= DAILY_LIMIT) throw new HttpError(429, `Bạn đã gửi ${DAILY_LIMIT} góp ý hôm nay. Hãy thử lại vào ngày mai.`);
      const topic = FB_TOPICS[b.topic] ? b.topic : "khac";
      const r = await db.prepare("INSERT INTO fb_letters (box_id, user_id, topic, content, day, created) VALUES (?, ?, ?, ?, ?, ?)")
        .bind(box.id, user.id, topic, content, vnDay(), now()).run();
      return json({ ok: true, id: r.meta.last_row_id });
    }
    throw new HttpError(405, "Phương thức không hỗ trợ.");
  }

  const user = await requireUser(request, env);

  // ---------------- Nhan vien: thu toi da gui ----------------
  if (path === "/api/fb/mine" && method === "GET") {
    const { results } = await db.prepare(
      `SELECT l.id, l.topic, l.ai_topic, l.content, l.created, l.status, l.reply, l.replied_at, b.name AS box_name, u.fb_title
       FROM fb_letters l JOIN fb_boxes b ON b.id = l.box_id JOIN users u ON u.id = b.owner_id
       WHERE l.user_id = ? ORDER BY l.id DESC LIMIT 200`).bind(user.id).all();
    return json(results.map(l => ({ id: l.id, topic_label: FB_TOPICS[l.topic] || FB_TOPICS.khac, content: l.content, created: l.created,
      status: l.status, reply: l.reply || "", replied_at: l.replied_at, box_name: l.box_name, title: l.fb_title || "" })));
  }

  // ---------------- HR (admin xem duoc cua nguoi khac qua ?owner=) ----------------
  const o = parseInt(url.searchParams.get("owner"), 10);
  const ownerId = user.is_admin && o > 0 ? o : user.id;
  // Chi tai khoan HR (hoac admin) moi tao hop thu. Nguoi bi go quyen HR van quan ly duoc hop thu da tao.
  const NOT_HR = "Chỉ tài khoản HR mới tạo được hộp thư góp ý. Hãy liên hệ quản trị viên để được cấp quyền.";
  const hasBoxes = async () => !!await db.prepare("SELECT 1 FROM fb_boxes WHERE owner_id = ?").bind(ownerId).first();
  if (!user.is_hr && !await hasBoxes()) throw Object.assign(new HttpError(403, NOT_HR), { code: "not_hr" });

  if (path === "/api/fb/boxes" && method === "GET") {
    const hub = await ensureHub(db, ownerId);
    const { results } = await db.prepare(
      `SELECT b.id, b.name, b.description, b.status, b.created,
              (SELECT COUNT(*) FROM fb_letters l WHERE l.box_id = b.id AND l.hidden = 0) AS n,
              (SELECT COUNT(*) FROM fb_letters l WHERE l.box_id = b.id AND l.hidden = 0 AND l.status = 'new') AS n_new
       FROM fb_boxes b WHERE b.owner_id = ? ORDER BY b.created`).bind(ownerId).all();
    return json({ hub: hub.fb_hub, title: hub.fb_title || "", boxes: results, topics: FB_TOPICS, sat_labels: SAT_LABELS,
      is_own: ownerId === user.id, can_create: user.is_hr });
  }

  if (path === "/api/fb/boxes" && method === "POST") {
    if (!user.is_hr) throw new HttpError(403, NOT_HR);
    const b = await readJson(request);
    const name = clean(b.name, 80).replace(/\s+/g, " "), description = clean(b.description, 300);
    if (name.length < 2) throw new HttpError(400, "Tên hộp thư cần ít nhất 2 ký tự (vd. tên phòng ban).");
    const n = (await db.prepare("SELECT COUNT(*) AS n FROM fb_boxes WHERE owner_id = ?").bind(ownerId).first()).n;
    if (n >= MAX_BOXES) throw new HttpError(400, `Tối đa ${MAX_BOXES} hộp thư.`);
    if (await db.prepare("SELECT 1 FROM fb_boxes WHERE owner_id = ? AND name = ?").bind(ownerId, name).first()) {
      throw new HttpError(409, "Đã có hộp thư trùng tên.");
    }
    const id = randomHex(5);
    await db.prepare("INSERT INTO fb_boxes (id, owner_id, name, description, created, updated) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(id, ownerId, name, description, now(), now()).run();
    return json({ id });
  }

  if (path === "/api/fb/hub" && method === "POST") {
    const title = clean((await readJson(request)).title, 100).replace(/\s+/g, " ");
    await db.prepare("UPDATE users SET fb_title = ? WHERE id = ?").bind(title || null, ownerId).run();
    return json({ ok: true, title });
  }

  m = /^\/api\/fb\/boxes\/([a-f0-9]{10})(\/delete)?$/.exec(path);
  if (m && method === "POST") {
    const box = await ownBox(db, user, m[1]);
    if (m[2]) {
      await db.batch([
        db.prepare("DELETE FROM fb_letters WHERE box_id = ?").bind(box.id),
        db.prepare("DELETE FROM fb_analyses WHERE owner_id = ? AND scope = ?").bind(box.owner_id, box.id),
        db.prepare("DELETE FROM fb_boxes WHERE id = ?").bind(box.id),
      ]);
      return json({ ok: true });
    }
    const b = await readJson(request);
    const name = "name" in b ? clean(b.name, 80).replace(/\s+/g, " ") : box.name;
    if (name.length < 2) throw new HttpError(400, "Tên hộp thư cần ít nhất 2 ký tự.");
    if (name !== box.name && await db.prepare("SELECT 1 FROM fb_boxes WHERE owner_id = ? AND name = ?").bind(box.owner_id, name).first()) {
      throw new HttpError(409, "Đã có hộp thư trùng tên.");
    }
    const description = "description" in b ? clean(b.description, 300) : box.description;
    const status = b.status === "open" || b.status === "closed" ? b.status : box.status;
    await db.prepare("UPDATE fb_boxes SET name = ?, description = ?, status = ?, updated = ? WHERE id = ?")
      .bind(name, description, status, now(), box.id).run();
    return json({ ok: true });
  }

  if (path === "/api/fb/letters" && method === "GET") {
    const p = url.searchParams;
    const where = ["b.owner_id = ?"], params = [ownerId];
    where.push(p.get("hidden") === "1" ? "l.hidden = 1" : "l.hidden = 0");
    if (p.get("box")) { await ownBox(db, user, p.get("box")); where.push("l.box_id = ?"); params.push(p.get("box")); }
    if (FB_TOPICS[p.get("topic")]) { where.push(`${TOPIC_SQL} = ?`); params.push(p.get("topic")); }
    if (STATUSES.includes(p.get("status"))) { where.push("l.status = ?"); params.push(p.get("status")); }
    const sat = p.get("sat");
    if (sat === "none") where.push("l.sat IS NULL");
    else if (SATS.includes(+sat)) { where.push("l.sat = ?"); params.push(+sat); }
    if (PERIOD_DAYS[p.get("period")]) { where.push("l.created >= ?"); params.push(now() - PERIOD_DAYS[p.get("period")] * 86400); }
    const page = Math.max(0, parseInt(p.get("page"), 10) || 0), size = 30;
    const total = (await db.prepare(`SELECT COUNT(*) AS n FROM fb_letters l JOIN fb_boxes b ON b.id = l.box_id WHERE ${where.join(" AND ")}`)
      .bind(...params).first()).n;
    const { results } = await db.prepare(
      `SELECT l.*, b.name AS box_name FROM fb_letters l JOIN fb_boxes b ON b.id = l.box_id
       WHERE ${where.join(" AND ")} ORDER BY l.id DESC LIMIT ? OFFSET ?`).bind(...params, size, page * size).all();
    return json({ total, page, more: (page + 1) * size < total, items: results.map(hrLetter) });
  }

  m = /^\/api\/fb\/letters\/(\d+)$/.exec(path);
  if (m && method === "POST") {
    const l = await db.prepare("SELECT l.id, l.box_id, b.owner_id FROM fb_letters l JOIN fb_boxes b ON b.id = l.box_id WHERE l.id = ?")
      .bind(+m[1]).first();
    if (!l || (l.owner_id !== user.id && !user.is_admin)) throw new HttpError(404, "Không tìm thấy thư góp ý.");
    const b = await readJson(request), stmts = [];
    if (STATUSES.includes(b.status)) stmts.push(db.prepare("UPDATE fb_letters SET status = ? WHERE id = ?").bind(b.status, l.id));
    if ("reply" in b) {
      const reply = clean(b.reply, MAX_CHARS);
      stmts.push(db.prepare("UPDATE fb_letters SET reply = ?, replied_at = ? WHERE id = ?").bind(reply || null, reply ? now() : null, l.id));
    }
    if ("hidden" in b) stmts.push(db.prepare("UPDATE fb_letters SET hidden = ? WHERE id = ?").bind(b.hidden ? 1 : 0, l.id));
    if ("sat" in b) {
      if (!SATS.includes(b.sat)) throw new HttpError(400, "Mức hài lòng phải từ 1 đến 5.");
      stmts.push(db.prepare("UPDATE fb_letters SET sat = ?, sat_by = 'hr' WHERE id = ?").bind(b.sat, l.id));
    }
    if (stmts.length) await db.batch(stmts);
    const row = await db.prepare("SELECT l.*, b.name AS box_name FROM fb_letters l JOIN fb_boxes b ON b.id = l.box_id WHERE l.id = ?").bind(l.id).first();
    return json(hrLetter(row));
  }

  if (path === "/api/fb/stats" && method === "GET") {
    const scope = url.searchParams.get("scope") || "all", period = url.searchParams.get("period") || "30";
    const { boxes } = await resolveScope(db, ownerId, scope, period);
    const letters = await scopeLetters(db, ownerId, scope, period, 5000);
    return json(fbStats(letters, boxes, period));
  }

  if (path === "/api/fb/analysis" && method === "GET") {
    const row = await db.prepare("SELECT data FROM fb_analyses WHERE owner_id = ? AND scope = ? AND period = ?")
      .bind(ownerId, url.searchParams.get("scope") || "all", url.searchParams.get("period") || "30").first();
    return json({ analysis: row ? JSON.parse(row.data) : null });
  }

  m = /^\/api\/fb\/analyze\/(start|score|summary)$/.exec(path);
  if (m && method === "POST") {
    const b = await readJson(request);
    const scope = String(b.scope || "all"), period = String(b.period || "30");
    const sc = await resolveScope(db, ownerId, scope, period);
    const key = runKey(ownerId, scope, period);

    if (m[1] === "start") {
      const letters = await scopeLetters(db, ownerId, scope, period, MAX_LETTERS);
      if (!letters.length) throw new HttpError(400, "Chưa có thư góp ý nào trong phạm vi và khoảng thời gian này để phân tích.");
      await quota.assert(user, "ana");
      const run = randomHex(8);
      await db.batch([
        db.prepare("INSERT INTO analysis_runs (id, survey_id, user_id, created) VALUES (?, ?, ?, ?)").bind(run, key, user.id, now()),
        db.prepare("DELETE FROM analysis_runs WHERE created < ?").bind(now() - 86400),
      ]);
      await quota.add(user.id, "ana", 1, 0);
      return json({ run, total: letters.length, unscored: letters.filter(l => !l.sat).length, quota: await quota.info(user) });
    }

    const run = await checkRun(db, b, user, key);
    const letters = await scopeLetters(db, ownerId, scope, period, MAX_LETTERS);

    if (m[1] === "score") {
      const todo = letters.filter(l => !l.sat).slice(0, SCORE_BATCH);
      if (!todo.length) return json({ scored: 0, remaining: 0, usage: { tokens: 0, calls: 0 } });
      const { result, usage } = await runStep(db, run, user, quota, (usage) => scoreLetters({ db, cfg, usage }, llm, todo));
      const byId = new Map(todo.map(l => [l.id, l]));
      if (result.length) {
        await db.batch(result.map(r => db.prepare(
          "UPDATE fb_letters SET sat = ?, sat_by = 'ai', ai_topic = COALESCE(ai_topic, ?) WHERE id = ? AND sat IS NULL")
          .bind(r.sat, byId.get(r.id).topic === "khac" && r.topic !== "khac" ? r.topic : null, r.id)));
      }
      const remaining = letters.filter(l => !l.sat).length - result.length;
      return json({ scored: result.length, remaining, usage });
    }

    // summary
    const stats = fbStats(letters, sc.boxes, period);
    if (!stats.scored) throw new HttpError(400, "Chưa có thư nào được chấm mức hài lòng. Hãy bấm phân tích lại.");
    const { result, usage } = await runStep(db, run, user, quota, (usage) => summarizeFeedback({ db, cfg, usage }, llm,
      { letters, stats, isAll: sc.isAll, scopeName: sc.scopeName, boxNames: sc.boxes.map(x => x.name) }));
    const prev = b.usage || {};
    const analysis = { at: now(), provider: llm.provider, model: llm.model, scope, scope_name: sc.scopeName, period, period_label: PERIODS[period],
      n: stats.n, scored: stats.scored, mean: stats.mean, ...result,
      usage: { tokens: usage.tokens + (parseInt(prev.tokens, 10) || 0), calls: usage.calls + (parseInt(prev.calls, 10) || 0) } };
    await db.prepare(`INSERT INTO fb_analyses (owner_id, scope, period, data, created) VALUES (?, ?, ?, ?, ?)
                      ON CONFLICT (owner_id, scope, period) DO UPDATE SET data = excluded.data, created = excluded.created`)
      .bind(ownerId, scope, period, JSON.stringify(analysis), now()).run();
    return json(analysis);
  }

  throw new HttpError(404, "Không tìm thấy.");
}
