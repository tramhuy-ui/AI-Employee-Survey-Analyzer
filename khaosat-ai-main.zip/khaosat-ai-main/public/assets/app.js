// Tien ich dung chung cho moi trang.
const APP_NAME = "KhảoSát AI";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const fmtInt = (n) => Number(n || 0).toLocaleString("vi-VN");
const fmtDate = (ts) => (ts ? new Date(ts * 1000).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" }) : "–");
const qs = (k) => new URLSearchParams(location.search).get(k);

const TYPE_LABEL = { single_choice: "Chọn 1", multiple_choice: "Chọn nhiều", dropdown: "Danh sách thả xuống", scale: "Thang 1–5",
  rating: "Đánh giá sao", nps: "NPS 0–10", open_text: "Câu hỏi mở" };
const STATUS_LABEL = { draft: "Nháp", published: "Đang nhận trả lời", closed: "Đã đóng" };
const SENT = { tich_cuc: "tích cực", tieu_cuc: "tiêu cực", trung_lap: "trung lập" };
const SEV = { cao: "Cao", trung_binh: "Trung bình", thap: "Thấp" };
const RISK = { cao: "Cao", trung_binh: "Trung bình", thap: "Thấp", khong_ro: "Không rõ" };
const statusBadge = (s) => `<span class="badge ${esc(s)}">${STATUS_LABEL[s] || esc(s)}</span>`;

class ApiError extends Error { constructor(msg, status) { super(msg); this.status = status; } }

async function api(path, body, method) {
  const opts = body === undefined && !method ? {} :
    { method: method || "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body ?? {}) };
  let res;
  try { res = await fetch(path, opts); } catch { throw new ApiError("Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.", 0); }
  const data = await res.json().catch(() => ({ error: "Phản hồi không hợp lệ từ máy chủ." }));
  if (!res.ok || data.error) throw new ApiError(data.error || res.statusText, res.status);
  return data;
}

// Goi mot buoc dung AI; neu server bao "cho" (gioi han toc do cua Groq) thi dem nguoc roi goi lai
async function aiStep(path, body, onStatus) {
  let waited = 0;
  for (;;) {
    const r = await api(path, body);
    if (!r.wait) return { r, waited };
    if (waited + r.wait > 300) throw new Error(`${r.label}: phải chờ giới hạn quá lâu, hãy thử lại sau ít phút.`);
    for (let left = r.wait; left > 0; left--) { onStatus?.(`Đang chờ giới hạn tốc độ của ${r.label}… còn ${left} giây`); await sleep(1000); }
    waited += r.wait;
  }
}

async function busy(btn, label, fn) {
  const old = btn.innerHTML; btn.disabled = true;
  btn.innerHTML = `<span class="spinner"></span> ${esc(label)}`;
  try { return await fn(); } finally { btn.disabled = false; btn.innerHTML = old; }
}

// ------------------------------------------------------------ dieu huong ----
let ME = null, GOOGLE = false;
const ICON = {
  list: '<path d="M7 4h12M7 12h12M7 20h12"/><circle cx="3" cy="4" r="1"/><circle cx="3" cy="12" r="1"/><circle cx="3" cy="20" r="1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  tpl: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  check: '<path d="M4 12l5 5L20 6"/>',
  idea: '<path d="M9 18h6M10 21h4M12 3a6 6 0 00-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0012 3z"/>',
  pen: '<path d="M4 20l4-1 11-11-3-3L5 16z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
};
const svgI = (k, size = 20) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[k]}</svg>`;
const initials = (name) => String(name || "?").trim().split(/[\s@.]+/).filter(Boolean).slice(-2).map(w => w[0]).join("").toUpperCase();
const avatar = (u) => u.avatar ? `<img src="${esc(u.avatar)}" alt="" referrerpolicy="no-referrer">` : esc(initials(u.name));

async function initPage({ active = "", requireLogin = false, requireAdmin = false, sidebar = "" } = {}) {
  const me = await api("/api/me").catch(() => ({ user: null, google: false }));
  ME = me.user; GOOGLE = !!me.google;
  const here = encodeURIComponent(location.pathname + location.search);
  const tab = (href, text, key) => `<a class="tn ${active === key ? "on" : ""}" href="${href}">${text}</a>`;
  const bar = document.createElement("header");
  bar.className = "ab";
  bar.innerHTML = `<a class="logo" href="/"><i></i>KhảoSát AI</a>
    ${tab("/", "Trang chủ", "search")}
    ${ME ? tab("/dashboard", "Khảo sát của tôi", "dashboard") + tab("/create?mode=tpl", "Thư viện mẫu", "templates") + tab("/answered", "Đã trả lời", "answered") + (ME.can_feedback ? tab("/feedback", "Hộp thư góp ý", "feedback") : "") : ""}
    ${ME?.is_admin ? tab("/admin", "Quản trị", "admin") : ""}
    <div class="ar">
      ${ME ? `<a class="btn ol small" href="/create">+ Tạo khảo sát</a>
        <div class="dd" id="userMenu"><span class="avt" tabindex="0" title="${esc(ME.name)}">${avatar(ME)}</span>
          <div class="dm2"><div class="who"><b>${esc(ME.name)}</b><span>${esc(ME.email)}</span></div>
            <a href="/dashboard">Khảo sát của tôi</a><a href="/answered">Khảo sát đã trả lời</a>${ME.can_feedback ? '<a href="/feedback">Hộp thư góp ý</a>' : ""}<a href="/my-feedback">Thư góp ý tôi đã gửi</a><a href="/account">Tài khoản, đổi mật khẩu</a>${ME.is_admin ? '<a href="/admin">Quản trị hệ thống</a>' : ""}
            <button id="navLogout">Đăng xuất</button></div></div>`
        : `<a class="lk" href="/login?next=${here}">Đăng nhập</a><a class="btn small" href="/register?next=${here}">Đăng ký miễn phí</a>`}
      ${ME || active === "search" ? `<button class="navtog" id="navTog" aria-label="Mở menu">☰</button>` : ""}
    </div>`;
  document.body.prepend(bar);
  $("navTog")?.addEventListener("click", () => bar.classList.toggle("open"));
  $("userMenu")?.addEventListener("click", (e) => { if (!e.target.closest(".dm2")) $("userMenu").classList.toggle("open"); });
  document.addEventListener("click", (e) => { if (!e.target.closest("#userMenu")) $("userMenu")?.classList.remove("open"); });
  $("navLogout")?.addEventListener("click", async () => { await api("/api/logout", {}).catch(() => {}); location.href = "/"; });

  if (sidebar && ME) {
    const item = (href, icon, text, key) => `<a class="si2 ${sidebar === key ? "on" : ""}" href="${href}">${svgI(icon)}${text}</a>`;
    const main = document.querySelector("main"), app = document.createElement("div");
    app.className = "app";
    app.innerHTML = `<aside class="sd">${item("/dashboard", "list", "Khảo sát của tôi", "dashboard")}${item("/create", "plus", "Tạo khảo sát", "create")}
      ${item("/create?mode=tpl", "tpl", "Thư viện mẫu", "templates")}${item("/answered", "check", "Đã trả lời", "answered")}${ME.can_feedback ? item("/feedback", "mail", "Hộp thư góp ý", "feedback") : ""}
      <div class="quota" id="sideQuota"></div></aside>`;
    main.before(app); main.classList.add("mc"); app.append(main);
    api("/api/my/quota").then(q => {
      const f = (x) => (x.limit === null ? "không giới hạn" : `còn ${Math.max(0, x.limit - x.used)}/${x.limit}`);
      $("sideQuota").innerHTML = `<b>Lượt AI hôm nay</b><br>Gợi ý câu hỏi: ${f(q.gen)}<br>Phân tích: ${f(q.ana)}`;
    }).catch(() => {});
  }
  setTimeout(() => { document.documentElement.dataset.ready = "1"; }); // danh dau trang da khoi tao xong (dung cho kiem thu)
  // Khong du quyen: chuyen huong / bao loi roi dung han script cua trang (promise khong bao gio xong, khong nem loi)
  const halt = () => new Promise(() => {});
  // Tai khoan moi tao bang Google: phai dong y dieu khoan truoc khi dung
  if (ME?.needs_terms && !/^\/(welcome|terms|privacy)/.test(location.pathname)) { location.href = `/welcome?next=${here}`; return halt(); }
  if ((requireLogin || requireAdmin) && !ME) { location.href = `/login?next=${here}`; return halt(); }
  if (requireAdmin && !ME.is_admin) { document.querySelector("main").innerHTML = `<div class="card empty">Chỉ quản trị viên mới truy cập được trang này.</div>`; return halt(); }
  return ME;
}

// Thanh tren cac trang cua mot khao sat: 1. Thiet ke -> 2. Chia se -> 3. Ket qua
function surveyBar(S, step) {
  const draft = S.status === "draft";
  const steps = [
    ["Thiết kế", draft ? `/edit?id=${S.id}` : `/s/${S.id}`],
    ["Chia sẻ", `/share?id=${S.id}`],
    ["Kết quả", draft ? null : `/results?id=${S.id}`],
  ].map(([label, href], i) => i === step ? `<a class="on" href="${href}" aria-current="page">${i + 1}. ${label}</a>`
    : href ? `<a href="${href}">${i + 1}. ${label}</a>` : `<span title="Đăng khảo sát để xem kết quả">${i + 1}. ${label}</span>`).join("");
  const el = document.createElement("div");
  el.className = "sbar";
  el.innerHTML = `<div class="sbt"><a class="crumb" href="${S.is_owner === false ? "/admin" : "/dashboard"}">${S.is_owner === false ? "Quản trị" : "Khảo sát của tôi"} ›</a>
    <b>${esc(S.title || "(Chưa có tiêu đề)")}</b>${statusBadge(S.status)}${S.anonymous ? '<span class="badge anon">Ẩn danh</span>' : ""}
    ${S.version > 1 ? `<span class="badge">Phiên bản ${S.version}</span>` : ""}</div><nav class="st4">${steps}</nav>`;
  document.querySelector("main").before(el);
}

async function copyText(btn, text) {
  const old = btn.textContent;
  try { await navigator.clipboard.writeText(text); btn.textContent = "Đã sao chép ✓"; }
  catch { btn.textContent = "Nhấn Ctrl+C để sao chép"; }
  setTimeout(() => { btn.textContent = old; }, 2000);
}

const fmtDuration = (sec) => {
  if (!sec && sec !== 0) return "–";
  const m = Math.floor(sec / 60), s = sec % 60;
  return m ? `${m} phút ${String(s).padStart(2, "0")} giây` : `${s} giây`;
};

// Han chot khao sat: "con 3 ngay 4 gio" / "con 5 gio 20 phut"
function fmtLeft(ts) {
  const sec = ts - Date.now() / 1000;
  if (sec <= 0) return "đã hết hạn";
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.max(1, Math.floor((sec % 3600) / 60));
  return d ? `còn ${d} ngày${h ? ` ${h} giờ` : ""}` : h ? `còn ${h} giờ${m ? ` ${m} phút` : ""}` : `còn ${m} phút`;
}
// <input type="datetime-local"> <-> giay (theo gio may nguoi dung)
const toLocalInput = (ts) => { const d = new Date(ts * 1000); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
const fromLocalInput = (v) => (v ? Math.floor(new Date(v).getTime() / 1000) : null);

// Chi chuyen huong ve duong dan noi bo (chong open redirect)
const safeNext = (n) => (n && n.startsWith("/") && !n.startsWith("//") && !n.startsWith("/\\") ? n : "/dashboard");

// Nut "Dang nhap bang Google" (chi hien khi server da cau hinh Google)
const GOOGLE_SVG = '<svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
function googleButton(el, label, next) {
  if (!GOOGLE) { el.innerHTML = ""; return; }
  el.innerHTML = `<div class="or"><span>HOẶC</span></div>
    <a class="sb" id="btnGoogle" href="/api/auth/google/start?next=${encodeURIComponent(next)}">${GOOGLE_SVG}${label}</a>`;
}
const OAUTH_ERRORS = {
  cancelled: "Bạn đã hủy đăng nhập bằng Google.",
  state: "Phiên đăng nhập Google đã hết hạn hoặc không hợp lệ. Hãy thử lại.",
  token: "Không xác thực được với Google. Hãy thử lại sau.",
  unverified: "Email Google của bạn chưa được xác minh.",
  locked: "Tài khoản của bạn đã bị quản trị viên khóa.",
  linked: "Email này đã được liên kết với một tài khoản Google khác.",
};

// ---------------------------------------------- hien thi cau hoi (tra loi) ----
function renderQuestionInputs(container, questions) {
  container.innerHTML = questions.map((q, i) => {
    const name = esc(q.id);
    let body;
    if (q.type === "single_choice" || q.type === "multiple_choice") {
      const t = q.type === "single_choice" ? "radio" : "checkbox";
      body = q.options.map(o => `<label class="opt"><input type="${t}" name="${name}" value="${esc(o)}"><span>${esc(o)}</span></label>`).join("");
    } else if (q.type === "dropdown") {
      body = `<select name="${name}" style="max-width:420px"><option value="">— Chọn —</option>${q.options.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join("")}</select>`;
    } else if (q.type === "scale") {
      const [lo, hi] = q.scale || ["Rất thấp", "Rất cao"];
      body = `<div class="scale" role="radiogroup">${[1, 2, 3, 4, 5].map(n => `<label><input type="radio" name="${name}" value="${n}" aria-label="${n}"><span>${n}</span></label>`).join("")}</div>
        <div class="scale-hint"><span>1 = ${esc(lo)}</span><span>5 = ${esc(hi)}</span></div>`;
    } else if (q.type === "rating") {
      body = `<div class="stars" role="radiogroup">${[5, 4, 3, 2, 1].map(n => `<input type="radio" id="${name}-s${n}" name="${name}" value="${n}"><label for="${name}-s${n}" title="${n} sao" aria-label="${n} sao">★</label>`).join("")}</div>`;
    } else if (q.type === "nps") {
      body = `<div class="scale nps" role="radiogroup">${[...Array(11).keys()].map(n => `<label><input type="radio" name="${name}" value="${n}" aria-label="${n}"><span>${n}</span></label>`).join("")}</div>
        <div class="scale-hint"><span>0 = Chắc chắn không</span><span>10 = Chắc chắn có</span></div>`;
    } else {
      body = `<textarea name="${name}" maxlength="2000" placeholder="Nhập câu trả lời của bạn…"></textarea>`;
    }
    return `<div class="q" data-q="${name}"><div class="q-title">${i + 1}. ${esc(q.question)}${q.required ? '<span class="req" title="Bắt buộc">*</span>' : ""}</div>${body}</div>`;
  }).join("");
}

function collectAnswers(form, questions) {
  const fd = new FormData(form), a = {};
  for (const q of questions) {
    if (q.type === "multiple_choice") a[q.id] = fd.getAll(q.id);
    else {
      const v = fd.get(q.id);
      a[q.id] = ["scale", "rating", "nps"].includes(q.type) && v !== null && v !== "" ? Number(v) : v;
    }
  }
  return a;
}

// Danh dau cau bat buoc chua tra loi; tra ve so thu tu cac cau thieu
function checkRequired(form, questions, answers) {
  const missing = [];
  questions.forEach((q, i) => {
    const v = answers[q.id];
    const empty = v === null || v === undefined || v === "" || (Array.isArray(v) && !v.length);
    form.querySelector(`[data-q="${q.id}"]`)?.classList.toggle("invalid", q.required && empty);
    if (q.required && empty) missing.push(i + 1);
  });
  return missing;
}

// -------------------------------------------------------- bieu do ket qua ----
const PAL = ["#005BAA", "#F36F21", "#1fc16b", "#f2c230", "#3bb4c1", "#9b6fd0", "#4a7fd0", "#f08a4b"];
const pctText = (p) => String(Math.round(p * 10) / 10).replace(".", ",");

// rows: [nhan, so luong, mau?]; total: so nguoi tra loi cau hoi
function chart(rows, total, mode = "h") {
  const data = rows.map(([label, c, color], k) => {
    const p = total ? (100 * c / total) : 0;
    return { label, c, p, color: color || PAL[k % PAL.length],
      tip: `${label}: ${pctText(p)}% (${c} phản hồi) trong tổng số ${total} câu trả lời` };
  });
  if (mode === "v") {
    const max = Math.max(1, ...data.map(d => d.p));
    return `<div class="vch">${data.map(d => `<div title="${esc(d.tip)}"><b>${pctText(d.p)}%</b><i style="height:${Math.max(1, 85 * d.p / max)}%;background:${d.color}"></i><span>${esc(d.label)}</span></div>`).join("")}</div>`;
  }
  return data.map(d => `<div class="hr" title="${esc(d.tip)}"><span>${esc(d.label)}</span><div class="hb"><i style="width:${d.p}%;background:${d.color}"></i></div>
    <b>${pctText(d.p)}% <small>(${d.c})</small></b></div>`).join("");
}

function renderStat(st, mode = "h") {
  const a = st.answered || 0;
  if (st.counts) return chart(Object.entries(st.counts), a, mode);
  if (st.type === "nps") {
    const g = st.groups;
    return `<div class="row" style="margin-bottom:.4rem"><span class="kpi">${st.nps ?? "–"}</span><span class="muted">Điểm ${st.question.includes("công ty") ? "eNPS" : "NPS"} (−100 → 100) · TB ${st.mean ?? "–"}/10</span></div>` +
      (mode === "v" ? chart(Object.entries(st.distribution).map(([k, v]) => [k, v, +k >= 9 ? "#1fc16b" : +k >= 7 ? "#9aa7b5" : "#d9534f"]), a, "v")
        : chart([["Ủng hộ (9–10)", g.promoters, "#1fc16b"], ["Trung lập (7–8)", g.passives, "#9aa7b5"], ["Phản đối (0–6)", g.detractors, "#d9534f"]], a));
  }
  if (st.distribution) {
    const [lo, hi] = st.scale || ["Rất thấp", "Rất cao"];
    const label = (k) => (st.type === "rating" ? `${k} sao` : k === "1" ? `1 – ${lo}` : k === "5" ? `5 – ${hi}` : k);
    return `<div class="muted" style="margin-bottom:.3rem">Trung bình: <b style="color:var(--bd);font-size:1.05rem">${st.mean ?? "–"}</b>/5 · 1 = ${esc(lo)}, 5 = ${esc(hi)}</div>` +
      chart(Object.entries(st.distribution).map(([k, v]) => [label(k), v]), a, mode);
  }
  if (st.texts) return st.texts.length ? `<div class="texts">${st.texts.map(t => `<div class="quote">“${esc(t)}”</div>`).join("")}</div>` : `<p class="muted">Chưa có ý kiến.</p>`;
  return "";
}

// ------------------------------------------------------ hop thu gop y ----
const SAT = { 1: "Rất không hài lòng", 2: "Không hài lòng", 3: "Trung lập", 4: "Hài lòng", 5: "Rất hài lòng" };
const SAT_EMO = { 1: "😠", 2: "🙁", 3: "😐", 4: "🙂", 5: "😄" };
const SAT_COLOR = { 1: "#d9534f", 2: "#f08a4b", 3: "#9aa7b5", 4: "#7cc96b", 5: "#1fc16b" };
const FB_STATUS = { new: "Mới", doing: "Đang xử lý", done: "Đã xử lý" };
const satBadge = (k) => (k ? `<span class="satb s${k}" title="${SAT[k]}">${SAT_EMO[k]} ${SAT[k]}</span>` : `<span class="satb">Chưa chấm</span>`);
const fmtDay = (d) => (d ? d.split("-").reverse().join("/") : "–");

// Thanh xep chong ty le 5 muc hai long (dist: {1..5: so thu}). Bam vao doan -> data-sat
function satStack(dist, extra = "") {
  const total = [1, 2, 3, 4, 5].reduce((a, k) => a + (dist[k] || 0), 0);
  if (!total) return `<div class="stk empty"><i style="width:100%"></i></div>`;
  return `<div class="stk">${[1, 2, 3, 4, 5].filter(k => dist[k]).map(k => {
    const p = 100 * dist[k] / total;
    return `<i style="width:${p}%;background:${SAT_COLOR[k]}" data-sat="${k}" ${extra}
      title="${SAT[k]}: ${dist[k]} thư (${pctText(p)}%)">${p >= 12 ? Math.round(p) + "%" : ""}</i>`;
  }).join("")}</div>`;
}

// Bieu do + bao cao danh gia hop thu (dung chung cho trang Hop thu gop y va trang in bao cao)
function weekLabel(t, unit) {
  if (unit === "month") { const [y, m] = t.key.split("-"); return `${m}/${y}`; }
  const [, m, d] = t.key.split("-"); return `Tuần ${d}/${m}`;
}

function fbChartsHtml(s, all) {
  if (!s.n) return `<div class="card empty"><div class="ico">✉</div><p>Chưa có thư góp ý nào trong phạm vi và khoảng thời gian này.</p></div>`;
  const meanK = s.mean ? Math.round(s.mean) : null;
  let html = `<div class="stat-grid" style="margin-bottom:1rem">
    <div class="stat"><div class="label">Số thư góp ý</div><div class="kpi">${fmtInt(s.n)}</div></div>
    <div class="stat"><div class="label">Chỉ số hài lòng (1–5)</div><div class="kpi">${s.mean ?? "–"}${meanK ? ` <span style="font-size:1.4rem">${SAT_EMO[meanK]}</span>` : ""}</div></div>
    <div class="stat"><div class="label">Thư tiêu cực (mức 1–2)</div><div class="kpi" style="color:${(s.neg_pct ?? 0) >= 50 ? "var(--bad)" : "var(--bd)"}">${s.neg_pct ?? "–"}${s.neg_pct !== null ? "%" : ""}</div></div>
    <div class="stat"><div class="label">Đã chấm mức hài lòng</div><div class="kpi">${s.scored}<span class="muted" style="font-size:1rem">/${s.n}</span></div></div></div>`;
  if (!s.scored) {
    return html + `<div class="card empty"><p>Chưa có thư nào được chấm mức hài lòng. Bấm <b>✨ Phân tích bằng AI</b> để AI chấm từng thư và vẽ biểu đồ.</p></div>`;
  }
  if (s.scored < s.n) html += `<div class="notice">${s.n - s.scored} thư chưa được chấm (thư mới gửi sau lần phân tích trước). Bấm phân tích lại để chấm thêm.</div>`;

  // 1. Phan bo
  html += `<div class="qc"><div class="qh"><small>Biểu đồ 1 · Bấm vào một dòng để xem các thư</small></div><h3>Phân bố mức hài lòng</h3>` +
    [1, 2, 3, 4, 5].map(k => {
      const p = 100 * s.dist[k] / s.scored;
      return `<div class="hr click" data-sat="${k}" title="${SAT[k]}: ${s.dist[k]} thư (${pctText(p)}%)"><span>${SAT_EMO[k]} ${SAT[k]}</span>
        <div class="hb"><i style="width:${p}%;background:${SAT_COLOR[k]}"></i></div><b>${pctText(p)}% <small>(${s.dist[k]})</small></b></div>`;
    }).join("") + `</div>`;

  // 2. So sanh phong ban
  if (all && s.by_box.length) {
    const rated = s.by_box.filter(b => b.scored);
    const lo = rated.length > 1 ? Math.min(...rated.map(b => b.mean)) : null, hi = rated.length > 1 ? Math.max(...rated.map(b => b.mean)) : null;
    html += `<div class="qc"><div class="qh"><small>Biểu đồ 2 · Bấm vào tên phòng hoặc một đoạn màu để xem thư</small></div><h3>So sánh giữa các phòng ban</h3>
      <div class="tbl-wrap"><table class="cmp"><thead><tr><th>Phòng ban</th><th class="n">Số thư</th><th class="n">Chỉ số</th><th class="n">Tiêu cực</th>
        <th style="min-width:200px">Tỷ lệ 5 mức</th><th>Chủ đề nổi bật</th></tr></thead><tbody>` +
      s.by_box.map(b => `<tr data-box="${b.id}"><td><a href="#letters" data-box-link="${b.id}">${esc(b.name)}</a></td><td class="n">${b.n}</td>
        <td class="n ${b.scored && b.mean === lo && lo !== hi ? "lo" : b.scored && b.mean === hi && lo !== hi ? "hi" : ""}">${b.mean ?? "–"}${b.scored && b.mean === lo && lo !== hi ? " 🔴" : b.scored && b.mean === hi && lo !== hi ? " 🟢" : ""}</td>
        <td class="n">${b.neg_pct === null ? "–" : b.neg_pct + "%"}</td><td>${b.scored ? satStack(b.dist) : '<span class="muted">chưa có</span>'}</td>
        <td>${esc(b.top_topic || "–")}</td></tr>`).join("") +
      `</tbody></table></div><p class="muted" style="margin-bottom:0">🔴 chỉ số thấp nhất · 🟢 cao nhất. Phòng ít thư thì con số dễ dao động, hãy xem kèm cột “Số thư”.</p></div>`;
  }

  // 3. Theo chu de
  html += `<div class="qc"><div class="qh"><small>Biểu đồ ${all && s.by_box.length ? 3 : 2}</small></div><h3>Theo chủ đề</h3>
    <div class="tbl-wrap"><table class="cmp"><thead><tr><th>Chủ đề</th><th class="n">Số thư</th><th class="n">Chỉ số</th><th class="n">Tiêu cực</th><th style="min-width:200px">Tỷ lệ 5 mức</th></tr></thead><tbody>` +
    [...s.by_topic].sort((a, b) => b.n - a.n).map(t => `<tr data-topic="${t.key}"><td>${esc(t.label)}</td><td class="n">${t.n}</td><td class="n">${t.mean ?? "–"}</td>
      <td class="n">${t.neg_pct === null ? "–" : t.neg_pct + "%"}</td><td>${t.scored ? satStack(t.dist) : '<span class="muted">chưa có</span>'}</td></tr>`).join("") +
    `</tbody></table></div></div>`;

  // 4. Xu huong
  const tr = s.trend.filter(t => t.scored);
  html += `<div class="qc"><div class="qh"><small>Biểu đồ ${all && s.by_box.length ? 4 : 3}</small></div><h3>Xu hướng chỉ số hài lòng theo ${s.unit === "month" ? "tháng" : "tuần"}</h3>` +
    (tr.length ? `<div class="vch">${tr.map(t => `<div title="${weekLabel(t, s.unit)}: chỉ số ${t.mean}/5 (${t.scored} thư đã chấm)">
        <b>${t.mean}</b><i style="height:${Math.max(2, 85 * t.mean / 5)}%;background:${SAT_COLOR[Math.round(t.mean)]}"></i><span>${weekLabel(t, s.unit)}<br>${t.scored} thư</span></div>`).join("")}</div>` +
      (tr.length < 2 ? `<p class="muted" style="margin-bottom:0">Cần dữ liệu từ ít nhất 2 ${s.unit === "month" ? "tháng" : "tuần"} để thấy xu hướng.</p>` : "")
      : `<p class="muted">Chưa có dữ liệu.</p>`) + `</div>`;
  return html;
}


function fbReportHtml(a) {
  const s = a.summary, r = s.retention_risk;
  let html = `<h2 style="margin-bottom:.2rem">Đánh giá tình hình: ${esc(a.scope_name)}</h2>
    <p class="muted" style="margin-top:0">${esc(a.period_label)} · ${a.n} thư (${a.scored} đã chấm) · Phân tích bởi <b>${esc(a.model)}</b> lúc ${fmtDate(a.at)}` +
    (a.usage ? ` · ${fmtInt(a.usage.tokens)} token, ${a.usage.calls} lần gọi AI` : "") + `</p>`;
  if (s.note) html += `<div class="notice warn">${esc(s.note)}</div>`;
  html += `<div class="risk ${esc(r.level)}"><b>Mức nguy cơ nghỉ việc:</b><span class="lvl">${RISK[r.level] || "Không rõ"}</span>
    <p>${esc(r.reason) || "Chưa đủ dữ liệu trong thư góp ý để đánh giá."}${evChips(r.evidence)}</p></div>`;
  html += `<h3>Tổng quan</h3><p class="summary">${esc(s.overview)}</p>`;
  if (s.focus) html += `<div class="notice warn"><b>Phòng cần chú ý nhất: ${esc(s.focus.name)}.</b> ${esc(s.focus.reason)}</div>`;
  html += `<div class="actions-box"><h3>Việc nên làm ngay <span class="muted" style="font-weight:400">(30 ngày tới)</span></h3>${reportItems(s.quick_actions)}</div>`;
  if (s.departments.length) html += `<h3>Vấn đề chính của từng phòng ban</h3><div class="tbl-wrap"><table><thead><tr><th>Phòng ban</th><th>Vấn đề chính</th></tr></thead><tbody>` +
    s.departments.map(d => `<tr><td>${esc(d.name)}</td><td>${esc(d.main_issue)}</td></tr>`).join("") + `</tbody></table></div>`;
  html += `<h3 class="sent-tieu_cuc">Vấn đề nổi bật <span class="muted" style="font-weight:400">(xếp theo mức nghiêm trọng)</span></h3>${reportItems(s.issues, true)}
    <h3 class="sent-tich_cuc">Điểm tích cực</h3>${reportItems(s.positives)}`;
  if (s.limitations) html += `<h3>Hạn chế của dữ liệu</h3><p class="muted" style="font-size:14px">${esc(s.limitations)}</p>`;
  const q = Object.entries(a.quotes || {});
  if (q.length) html += `<h3 style="margin-top:28px">Thư được trích dẫn</h3><p class="muted">Bấm vào mã như <span class="code">T12</span> ở trên để nhảy tới thư tương ứng.</p>` +
    q.map(([code, t]) => `<div class="theme" id="ev-${esc(code)}"><div class="theme-head"><span><span class="code">${esc(code)}</span>${esc(t.box)} · ${esc(t.topic)}</span>
      <span style="font-size:13px">${satBadge(t.sat)} · ${fmtDay(t.day)}</span></div><div class="quote" style="white-space:pre-wrap">${esc(t.text)}</div></div>`).join("");
  return html;
}


// ------------------------------------------------------- bao cao AI ----
const evChips = (ev) => ev && ev.length
  ? `<span class="ev">${ev.map(c => `<a href="#ev-${esc(c)}" data-ev="${esc(c)}" title="Xem bằng chứng ${esc(c)}">${esc(c)}</a>`).join("")}</span>` : "";

function reportItems(list, withSev) {
  if (!list || !list.length) return `<p class="muted">Không có</p>`;
  return `<ul class="list">${list.map(it => {
    const sev = withSev && it.severity ? `<span class="sev sev-${esc(it.severity)}">${SEV[it.severity] || esc(it.severity)}</span>` : "";
    return `<li>${sev}${esc(it.text)}${evChips(it.evidence)}</li>`;
  }).join("")}</ul>`;
}

function renderSegments(seg) {
  if (!seg) return "";
  let html = `<h3>So sánh theo nhóm</h3><p class="muted">Theo câu [${esc(seg.qid)}] ${esc(seg.question)}. ` +
    `Nhóm dưới ${seg.min_group} người được làm mờ: chỉ để tham khảo, AI không kết luận dựa trên các nhóm này.</p>`;
  if (!seg.scale_questions.length) return html + `<p class="muted">Khảo sát không có câu thang điểm / sao / NPS để so sánh.</p>`;
  html += `<div class="tbl-wrap"><table><thead><tr><th>Nhóm</th><th class="n">Số người</th>` +
    seg.scale_questions.map(q => `<th class="n" title="${esc(q.question)}">TB [${esc(q.id)}]</th>`).join("") + `</tr></thead><tbody>`;
  for (const g of seg.groups) {
    html += `<tr class="${g.enough ? "" : "dim"}"><td>${esc(g.group)}</td><td class="n">${g.n}</td>` +
      seg.scale_questions.map(q => `<td class="n">${g.means[q.id] ?? "–"}</td>`).join("") + `</tr>`;
  }
  return html + `</tbody></table></div>`;
}

function renderReport(el, a) {
  const s = a.summary, u = a.usage;
  let html = `<p class="muted">Phân tích bởi <b>${esc(a.model)}</b> · ${a.n} câu trả lời · ${fmtDate(a.at)}` +
    (u ? ` · ${fmtInt(u.tokens)} token, ${u.calls} lần gọi AI, ${u.seconds} giây` + (u.waited ? ` (chờ giới hạn ${Math.round(u.waited)} giây)` : "") : "") + `</p>`;
  if (a.decision) html += `<p class="muted">Quyết định cần đưa ra: <b>${esc(a.decision)}</b></p>`;
  if (s.note) html += `<div class="notice warn">${esc(s.note)}</div>`;
  if (s.retention_risk) {
    const r = s.retention_risk;
    html += `<div class="risk ${esc(r.level)}"><b>Mức nguy cơ nghỉ việc:</b><span class="lvl">${RISK[r.level] || "Không rõ"}</span>
      <p>${esc(r.reason) || (r.level === "khong_ro" ? "Khảo sát chưa có câu hỏi đủ để đánh giá nguy cơ nghỉ việc (vd. ý định gắn bó, eNPS)." : "")}${evChips(r.evidence)}</p></div>`;
  }
  html += `<h3>Tóm tắt</h3><p class="summary">${esc(s.summary)}</p>`;
  if (s.quick_actions) html += `<div class="actions-box"><h3>Việc nên làm ngay <span class="muted" style="font-weight:400">(30 ngày tới)</span></h3>${reportItems(s.quick_actions)}</div>`;
  html += `
    <h3>Điểm nổi bật</h3>${reportItems(s.highlights)}
    <h3 class="sent-tieu_cuc">Vấn đề <span class="muted" style="font-weight:400">(xếp theo mức nghiêm trọng)</span></h3>${reportItems(s.issues, true)}
    <h3 class="sent-tich_cuc">Điểm tích cực</h3>${reportItems(s.positives)}
    <h3>Ý kiến đáng chú ý</h3>${reportItems(s.notable)}
    <h3>Đề xuất dài hạn</h3>${reportItems(s.recommendations)}`;
  if (s.limitations) html += `<h3>Hạn chế của dữ liệu</h3><p class="muted" style="font-size:14px">${esc(s.limitations)}</p>`;
  html += renderSegments(a.segments);
  html += `<h3 style="margin-top:28px">Bằng chứng chi tiết</h3>
    <p class="muted">Ngưỡng "nổi bật": từ ${a.threshold} người trở lên. Bấm vào mã như <span class="code">q3</span>, <span class="code">C1</span> ở trên để nhảy tới đây.</p>`;
  for (const st of a.stats) {
    html += `<div class="qc" id="ev-${esc(st.id)}"><div class="qh"><small><span class="code">${esc(st.id)}</span>${TYPE_LABEL[st.type]} · ${st.answered} trả lời</small></div>
      <h3>${esc(st.question)}</h3>`;
    if (st.type === "open_text") {
      html += (st.themes || []).length ? st.themes.map(t => `<div class="theme" id="ev-${esc(t.code)}">
        <div class="theme-head"><span><span class="code">${esc(t.code)}</span>${esc(t.name)}</span>
        <span class="sent-${esc(t.sentiment)}" style="font-size:13px">${SENT[t.sentiment] || ""} · ${t.count} người</span></div>
        ${t.description ? `<div class="theme-desc">${esc(t.description)}</div>` : ""}
        ${t.examples.map(e => `<div class="quote">“${esc(e)}”</div>`).join("")}</div>`).join("") : `<p class="muted">Không có ý kiến cụ thể.</p>`;
      if (st.no_content) html += `<p class="muted">${st.no_content} người trả lời không có nội dung cụ thể (vd. "không có ý kiến").</p>`;
    } else html += renderStat(st);
    html += `</div>`;
  }
  el.innerHTML = html;
}

// Bam ma bang chung -> cuon toi muc chi tiet
document.addEventListener("click", (e) => {
  const a = e.target.closest("a[data-ev]");
  if (!a) return;
  e.preventDefault();
  const el = document.getElementById("ev-" + a.dataset.ev);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
});

// ------------------------------------------------------------- ma QR ----
// Dung thu vien qrcode-generator (nap tu cdnjs) roi ve len canvas de tai ve dang PNG
function drawQR(canvas, text) {
  const qr = qrcode(0, "M");
  qr.addData(text);
  qr.make();
  const n = qr.getModuleCount(), margin = 3, scale = 8, size = (n + margin * 2) * scale;
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = "#000";
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) ctx.fillRect((c + margin) * scale, (r + margin) * scale, scale, scale);
}
