// AI goi y cau hoi, thong ke (tinh bang code, khong giao cho LLM), nhom chu de, tom tat.
import { llmJson, LLMError } from "./llm.js";
import { QTYPES, CHOICE_TYPES, NUMERIC_TYPES, TOPICS, isHrTopic } from "./questions.js";

const SENTIMENTS = ["tich_cuc", "tieu_cuc", "trung_lap"];
const BATCH = 50;             // so y kien (da gop trung) moi lan gui LLM
const MAX_ANSWER_CHARS = 300; // cat y kien qua dai truoc khi gui LLM
export const MIN_GROUP = 8;   // nhom < 8 nguoi: chi hien so lieu, khong ket luan

// ------------------------------------------------------ AI goi y cau hoi ----
const SUGGEST_SCHEMA = {
  type: "object",
  properties: {
    title: { type: "string" },
    description: { type: "string" },
    topic: { type: "string", enum: Object.keys(TOPICS) },
    questions: {
      type: "array",
      items: {
        type: "object",
        properties: {
          question: { type: "string" },
          type: { type: "string", enum: QTYPES },
          options: { type: "array", items: { type: "string" } },
          scale_min_label: { type: "string" },
          scale_max_label: { type: "string" },
        },
        required: ["question", "type", "options", "scale_min_label", "scale_max_label"],
      },
    },
  },
  required: ["title", "description", "topic", "questions"],
};

export const maxOpenQuestions = (count) => (count <= 4 ? 1 : Math.min(3, Math.max(2, Math.floor(count / 4))));

// Chi tra ve cau hoi MAU; nguoi tao se kiem tra va sua truoc khi dang
export async function suggestQuestions(ctx, llm, { purpose, count, audience, decision }) {
  const maxOpen = maxOpenQuestions(count);
  const system = "Bạn là chuyên gia nhân sự và thiết kế bảng khảo sát nhân viên, giúp doanh nghiệp hiểu nhân viên và giữ chân người giỏi. " +
    "Luôn viết bằng tiếng Việt có dấu. Câu hỏi phải rõ ràng, cụ thể, trung lập, không dẫn dắt.";
  const topics = Object.entries(TOPICS).map(([k, v]) => `${k} (${v})`).join(", ");
  const user = `Mục đích khảo sát: "${purpose}"
Đối tượng trả lời: ${audience || "nhân viên trong công ty"}
Kết quả sẽ dùng để quyết định: ${decision || "không nêu"}

Hãy tạo đúng ${count} câu hỏi theo các quy tắc:
- Nếu đối tượng là nhân viên trong công ty: 2-3 câu đầu là câu single_choice phân nhóm người trả lời (phòng ban, thâm niên, cấp bậc), tính vào tổng số câu. Các câu này giúp so sánh giữa các nhóm.
- Có từ 1 đến ${maxOpen} câu open_text (KHÔNG nhiều hơn), đặt ở cuối.
- Mỗi câu chỉ hỏi MỘT ý, dùng từ ngữ cụ thể, không mơ hồ. Nhân viên phải dám trả lời thật: không hỏi điều có thể làm lộ danh tính.
- Các loại câu hỏi:
  + single_choice (chọn 1) / dropdown (chọn 1 từ danh sách dài, >6 lựa chọn): lựa chọn không chồng lấn, bao quát mọi khả năng.
  + multiple_choice: 3-7 lựa chọn; câu hỏi nêu rõ tiêu chí chọn (vd. "Những yếu tố nào bạn CHƯA hài lòng?").
  + scale: thang 1-5; scale_min_label = ý nghĩa mức 1, scale_max_label = ý nghĩa mức 5. Với câu nhận định (vd. "Tôi được ghi nhận khi làm tốt."), dùng 1 = "Rất không đồng ý", 5 = "Rất đồng ý".
  + rating: đánh giá 1-5 sao (vd. đánh giá chung).
  + nps: thang 0-10, dùng cho eNPS "Bạn có sẵn lòng giới thiệu công ty là nơi đáng làm việc cho bạn bè, người thân không?" (tối đa 1 câu, chỉ khi phù hợp).
  + open_text: câu hỏi mở.
- Câu không phải scale: scale_min_label và scale_max_label là chuỗi rỗng. Câu không phải single_choice/multiple_choice/dropdown: options = [].
- Ưu tiên các câu giúp đưa ra quyết định nêu trên và giúp phát hiện nguy cơ nghỉ việc.
"title": tiêu đề ngắn. "description": 1-2 câu giới thiệu khảo sát cho người trả lời (nêu rõ khảo sát ẩn danh nếu phù hợp).
"topic": chủ đề phù hợp nhất, một trong: ${topics}.`;
  const out = await llmJson(ctx, llm, system, user, SUGGEST_SCHEMA, { temperature: 0.7 });

  const questions = [];
  for (const q of out.questions || []) {
    const text = String(q.question || "").trim();
    let type = QTYPES.includes(q.type) ? q.type : "open_text";
    const opts = [...new Set((q.options || []).map(o => String(o).trim()).filter(Boolean))];
    if (CHOICE_TYPES.includes(type) && opts.length < 2) type = "open_text";
    if (!text) continue;
    const item = { id: `q${questions.length + 1}`, question: text, type, required: false,
      options: CHOICE_TYPES.includes(type) ? opts : [] };
    if (type === "multiple_choice" && !/chọn (nhiều|tất cả|các)/i.test(text)) item.question += " (có thể chọn nhiều)";
    if (type === "scale") item.scale = [String(q.scale_min_label || "").trim() || "Rất thấp", String(q.scale_max_label || "").trim() || "Rất cao"];
    questions.push(item);
  }
  if (!questions.length) throw new LLMError("AI không tạo được câu hỏi nào, hãy thử lại.");
  return { title: String(out.title || "").trim(), description: String(out.description || "").trim(),
    topic: TOPICS[out.topic] ? out.topic : "khac", questions };
}

// ------------------------------------------------------ Thong ke ----
const mean = (vals) => (vals.length ? Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 100) / 100 : null);

export function computeStats(questions, responses) {
  return questions.map(q => {
    const vals = responses.filter(r => q.id in r).map(r => r[q.id]);
    const item = { id: q.id, question: q.question, type: q.type, answered: vals.length };
    if (CHOICE_TYPES.includes(q.type)) {
      const counts = Object.fromEntries(q.options.map(o => [o, 0]));
      for (const v of vals) for (const o of (Array.isArray(v) ? v : [v])) counts[o] = (counts[o] || 0) + 1;
      item.counts = counts;
    } else if (q.type === "scale" || q.type === "rating") {
      const dist = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
      for (const v of vals) dist[v] += 1;
      item.distribution = dist;
      item.mean = mean(vals);
      item.scale = q.type === "scale" ? q.scale || ["Rất thấp", "Rất cao"] : ["1 sao", "5 sao"];
    } else if (q.type === "nps") {
      const dist = Object.fromEntries([...Array(11).keys()].map(k => [k, 0]));
      for (const v of vals) dist[v] += 1;
      const promoters = vals.filter(v => v >= 9).length, detractors = vals.filter(v => v <= 6).length;
      item.distribution = dist;
      item.mean = mean(vals);
      item.nps = vals.length ? Math.round(100 * (promoters - detractors) / vals.length) : null;
      item.groups = { promoters, passives: vals.length - promoters - detractors, detractors };
    } else {
      item.texts = vals;
    }
    return item;
  });
}

// Cau tra loi khong co noi dung -> dem rieng, khong gui LLM
const NO_CONTENT = new RegExp("^(không|ko|k|kh|hok|hông|ok|oke|okay|ổn|không có|không có gì|không có ý kiến|không ý kiến|" +
  "không góp ý|chưa có|chưa có ý kiến|bình thường|mọi thứ ổn|mọi thứ đều ổn|tất cả đều ổn|" +
  "không có gì để góp ý|n a|na|none|no|nothing)$");

const normText = (t) => t.toLowerCase().replace(/[^\p{L}\p{N}\s_]/gu, " ").replace(/\s+/g, " ").trim();

export function prepareTexts(texts) {
  const groups = new Map(), uniq = [];
  let skipped = 0;
  texts.forEach((t, i) => {
    const n = normText(t);
    if (!n || NO_CONTENT.test(n)) skipped++;
    else if (groups.has(n)) groups.get(n).idx.push(i);
    else { const e = { text: t.slice(0, MAX_ANSWER_CHARS), idx: [i] }; groups.set(n, e); uniq.push(e); }
  });
  return { uniq, skipped };
}

// ------------------------------------------------------ Chu de ----
const themeItem = (extra) => ({
  type: "object",
  properties: { name: { type: "string" }, description: { type: "string" }, sentiment: { type: "string", enum: SENTIMENTS },
    [extra]: { type: "array", items: { type: "integer" } } },
  required: ["name", "description", "sentiment", extra],
});
const THEMES_SCHEMA = { type: "object", properties: { themes: { type: "array", items: themeItem("ids") } }, required: ["themes"] };
const MERGE_SCHEMA = { type: "object", properties: { themes: { type: "array", items: themeItem("sources") } }, required: ["themes"] };

const themeRange = (n) => (n <= 3 ? [1, Math.max(1, n)] : [3, Math.min(7, Math.max(3, Math.floor((n + 1) / 2)))]);
const sentimentOf = (s) => (SENTIMENTS.includes(s) ? s : "trung_lap");

async function themesForBatch(ctx, llm, purpose, question, entries, offset) {
  const listing = entries.map((e, i) => `[${offset + i}] ${e.text}` + (e.idx.length > 1 ? ` (x${e.idx.length} người)` : "")).join("\n");
  const [lo, hi] = themeRange(entries.length);
  const system = "Bạn là nhà phân tích dữ liệu khảo sát, chuyên mã hóa ý kiến mở thành chủ đề. Viết tiếng Việt có dấu.";
  const user = `Mục đích khảo sát: ${purpose}
Câu hỏi: ${question}
Các ý kiến (số trong ngoặc vuông là mã; "(x3 người)" nghĩa là 3 người trả lời giống nhau):
${listing}

Yêu cầu:
- Gộp thành ${lo}-${hi} chủ đề LỚN. Gộp các ý gần nghĩa vào cùng chủ đề (vd. "giá đắt" và "không đáng tiền" cùng thuộc chủ đề giá cả).
- "name": 2-6 từ. "description": 1 câu ngắn (tối đa 15 từ) mô tả chủ đề.
- Ý kiến lẻ không hợp chủ đề nào: đưa vào chủ đề tên "Khác". Riêng ý kiến lẻ nhưng NGHIÊM TRỌNG (ảnh hưởng sức khỏe, an toàn, quyền lợi) thì giữ thành chủ đề riêng.
- "ids": mã các ý kiến thuộc chủ đề. Một ý kiến nói nhiều ý có thể thuộc nhiều chủ đề. Không bỏ sót ý kiến nào.`;
  const out = await llmJson(ctx, llm, system, user, THEMES_SCHEMA, { temperature: 0.2, effort: "low" });
  const valid = new Set(entries.map((_, i) => offset + i));
  const themes = [];
  for (const t of out.themes || []) {
    const ids = [...new Set((t.ids || []).filter(i => Number.isInteger(i) && valid.has(i)))].sort((a, b) => a - b);
    if (ids.length && String(t.name || "").trim()) {
      themes.push({ name: t.name.trim(), description: String(t.description || "").trim(), sentiment: sentimentOf(t.sentiment), ids });
    }
  }
  return themes;
}

async function mergeThemes(ctx, llm, question, themes) {
  const listing = themes.map((t, i) => `[${i}] ${t.name}: ${t.description} (${t.ids.length} ý kiến)`).join("\n");
  const user = `Câu hỏi: ${question}
Các chủ đề được trích từ nhiều lô (có thể trùng ý nhau):
${listing}

Gộp các chủ đề trùng hoặc gần nghĩa thành tối đa 7 chủ đề. Mỗi chủ đề mới liệt kê mã ("sources") của các chủ đề cũ được gộp vào.
Mỗi chủ đề cũ phải nằm trong đúng một chủ đề mới.`;
  const out = await llmJson(ctx, llm, "Bạn là nhà phân tích dữ liệu khảo sát. Viết tiếng Việt có dấu.", user, MERGE_SCHEMA,
    { temperature: 0.1, effort: "low" });
  const merged = [], used = new Set();
  for (const t of out.themes || []) {
    const src = (t.sources || []).filter(i => Number.isInteger(i) && i >= 0 && i < themes.length && !used.has(i));
    if (!src.length) continue;
    src.forEach(i => used.add(i));
    merged.push({ name: String(t.name || "").trim() || themes[src[0]].name, description: String(t.description || "").trim(),
      sentiment: sentimentOf(t.sentiment), ids: [...new Set(src.flatMap(i => themes[i].ids))].sort((a, b) => a - b) });
  }
  themes.forEach((t, i) => { if (!used.has(i)) merged.push(t); }); // khong de mat chu de nao
  return merged;
}

// Mot buoc phan tich: nhom chu de cho 1 cau hoi mo
export async function analyzeOpenText(ctx, llm, purpose, question, texts) {
  const { uniq, skipped } = prepareTexts(texts);
  let themes = [];
  for (let off = 0; off < uniq.length; off += BATCH) {
    themes.push(...await themesForBatch(ctx, llm, purpose, question, uniq.slice(off, off + BATCH), off));
  }
  if (uniq.length > BATCH && themes.length > 1) themes = await mergeThemes(ctx, llm, question, themes);
  // Dem nguoi va lay trich dan nguyen van bang code -> khong the bi "bia"
  const result = themes.map(t => ({
    name: t.name, description: t.description, sentiment: t.sentiment,
    count: new Set(t.ids.flatMap(u => uniq[u].idx)).size,
    examples: t.ids.slice(0, 3).map(u => uniq[u].text),
  }));
  result.sort((a, b) => (a.name.toLowerCase() === "khác") - (b.name.toLowerCase() === "khác") || b.count - a.count);
  return { themes: result, no_content: skipped };
}

// Lam sach chu de do trinh duyet gui lai o buoc tom tat
export function sanitizeThemes(input) {
  const out = { themes: [], no_content: Math.max(0, parseInt(input?.no_content, 10) || 0) };
  for (const t of (Array.isArray(input?.themes) ? input.themes : []).slice(0, 20)) {
    const name = String(t?.name || "").trim().slice(0, 80);
    if (!name) continue;
    out.themes.push({
      name, description: String(t.description || "").trim().slice(0, 200), sentiment: sentimentOf(t.sentiment),
      count: Math.max(0, parseInt(t.count, 10) || 0),
      examples: (Array.isArray(t.examples) ? t.examples : []).slice(0, 3).map(e => String(e).slice(0, MAX_ANSWER_CHARS)),
    });
  }
  return out;
}

// ------------------------------------------------------ Tom tat ----
const EVIDENCE = { type: "array", items: { type: "string" } };
const ITEM = { type: "object", properties: { text: { type: "string" }, evidence: EVIDENCE }, required: ["text", "evidence"] };
const ISSUE = {
  type: "object",
  properties: { text: { type: "string" }, severity: { type: "string", enum: ["cao", "trung_binh", "thap"] }, evidence: EVIDENCE },
  required: ["text", "severity", "evidence"],
};
const SUMMARY_SCHEMA = {
  type: "object",
  properties: {
    summary: { type: "string" },
    highlights: { type: "array", items: ITEM },
    issues: { type: "array", items: ISSUE },
    positives: { type: "array", items: ITEM },
    notable: { type: "array", items: ITEM },
    recommendations: { type: "array", items: ITEM },
    limitations: { type: "string" },
  },
  required: ["summary", "highlights", "issues", "positives", "notable", "recommendations", "limitations"],
};
// Khao sat nhan su: them muc nguy co nghi viec + viec nen lam ngay
const RISK_LEVELS = ["cao", "trung_binh", "thap", "khong_ro"];
const HR_SUMMARY_SCHEMA = {
  ...SUMMARY_SCHEMA,
  properties: {
    ...SUMMARY_SCHEMA.properties,
    retention_risk: { type: "object", properties: { level: { type: "string", enum: RISK_LEVELS }, reason: { type: "string" }, evidence: EVIDENCE },
      required: ["level", "reason", "evidence"] },
    quick_actions: { type: "array", items: ITEM },
  },
  required: [...SUMMARY_SCHEMA.required, "retention_risk", "quick_actions"],
};
const SEVERITY_ORDER = { cao: 0, trung_binh: 1, thap: 2 };

export const notableThreshold = (n) => Math.max(n < 20 ? 2 : 3, Math.ceil(0.1 * n));

export function computeSegments(questions, responses, stats, segQid) {
  const q = questions.find(q => q.id === segQid && (q.type === "single_choice" || q.type === "dropdown"));
  if (!q) return null;
  const numQs = stats.filter(st => NUMERIC_TYPES.includes(st.type));
  const groups = q.options.map(opt => {
    const members = responses.filter(r => r[segQid] === opt);
    const means = {};
    for (const st of numQs) means[st.id] = mean(members.filter(r => st.id in r).map(r => r[st.id]));
    return { group: opt, n: members.length, means, enough: members.length >= MIN_GROUP };
  });
  return { qid: segQid, question: q.question, min_group: MIN_GROUP,
    scale_questions: numQs.map(st => ({ id: st.id, question: st.question, type: st.type })), groups };
}

const LABELS = { single_choice: "chọn 1", multiple_choice: "chọn nhiều", dropdown: "chọn 1 từ danh sách", scale: "thang 1-5",
  rating: "đánh giá 1-5 sao", nps: "NPS 0-10", open_text: "câu hỏi mở" };
const SENT = { tich_cuc: "tích cực", tieu_cuc: "tiêu cực", trung_lap: "trung lập" };

export function describeStats(stats, n, segments) {
  const lines = [`Tổng số người trả lời: ${n} (mỗi người ≈ ${(100 / n).toFixed(1)}%).`,
    `Ngưỡng "nổi bật": chủ đề/lựa chọn có từ ${notableThreshold(n)} người trở lên.`];
  for (const st of stats) {
    const a = st.answered;
    const head = `\n[${st.id}] ${st.question} (${LABELS[st.type]}, ${a} người trả lời`;
    if (st.counts) {
      lines.push(head + ")");
      for (const [o, c] of Object.entries(st.counts).sort((x, y) => y[1] - x[1])) lines.push(`   - ${o}: ${c} (${a ? Math.round(100 * c / a) : 0}%)`);
    } else if (st.type === "nps") {
      lines.push(head + "; 0 = chắc chắn không, 10 = chắc chắn có)");
      lines.push(`   Điểm NPS ${st.nps} (ủng hộ 9-10: ${st.groups.promoters}, trung lập 7-8: ${st.groups.passives}, phản đối 0-6: ${st.groups.detractors}); TB ${st.mean}/10`);
    } else if (st.distribution) {
      lines.push(head + `; 1 = ${st.scale[0]}, 5 = ${st.scale[1]})`);
      lines.push(`   Trung bình ${st.mean}/5; phân bố: ` + Object.entries(st.distribution).map(([k, v]) => `${k}đ: ${v}`).join(", "));
    } else {
      lines.push(head + (st.no_content ? `; ${st.no_content} người không góp ý cụ thể)` : ")"));
      for (const t of st.themes || []) {
        const ex = t.examples[0] ? ` VD: "${t.examples[0].slice(0, 120)}"` : "";
        lines.push(`   - [${t.code}] ${t.name} (${SENT[t.sentiment]}): ${t.count} người (${Math.round(100 * t.count / n)}%) — ${t.description}.${ex}`);
      }
    }
  }
  if (segments) {
    const ok = segments.groups.filter(g => g.enough);
    lines.push(`\nSO SÁNH THEO NHÓM (theo [${segments.qid}]), chỉ tính nhóm có từ ${MIN_GROUP} người:`);
    if (ok.length >= 2 && segments.scale_questions.length) {
      for (const g of ok) lines.push(`   - ${g.group} (n=${g.n}): ` + Object.entries(g.means).filter(([, v]) => v !== null).map(([k, v]) => `[${k}] TB ${v}`).join("; "));
    } else {
      lines.push(`   Không đủ nhóm có từ ${MIN_GROUP} người để so sánh → KHÔNG kết luận về khác biệt giữa các nhóm.`);
    }
  }
  return lines.join("\n");
}

// Chi giu ma bang chung hop le; bo nhan dinh khong co bang chung
export function cleanSummary(summary, validCodes, hr = false) {
  const canon = new Map(validCodes.map(c => [c.toLowerCase(), c]));
  const cleanEv = (list) => {
    const ev = [];
    for (const c of Array.isArray(list) ? list : []) {
      const code = canon.get(String(c).trim().replace(/^\[|\]$/g, "").toLowerCase());
      if (code && !ev.includes(code)) ev.push(code);
    }
    return ev;
  };
  const keys = ["highlights", "issues", "positives", "notable", "recommendations", ...(hr ? ["quick_actions"] : [])];
  for (const key of keys) {
    const items = [];
    for (const it of Array.isArray(summary[key]) ? summary[key] : []) {
      if (!it || typeof it !== "object" || !String(it.text || "").trim()) continue;
      it.evidence = cleanEv(it.evidence);
      if (it.evidence.length || key === "recommendations" || key === "quick_actions") items.push(it);
    }
    summary[key] = items;
  }
  if (hr) {
    const r = summary.retention_risk && typeof summary.retention_risk === "object" ? summary.retention_risk : {};
    const evidence = cleanEv(r.evidence);
    let level = RISK_LEVELS.includes(r.level) ? r.level : "khong_ro";
    if (!evidence.length) level = "khong_ro"; // khong co bang chung -> khong ket luan
    summary.retention_risk = { level, reason: String(r.reason || "").trim(), evidence };
  } else {
    delete summary.retention_risk; delete summary.quick_actions;
  }
  summary.issues.sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 3) - (SEVERITY_ORDER[b.severity] ?? 3));
  summary.summary = String(summary.summary || "");
  summary.limitations = String(summary.limitations || "");
  return summary;
}

// Buoc cuoi: ghep thong ke + chu de -> nho LLM viet tom tat. KHONG gui ten/email len AI.
export async function summarize(ctx, llm, survey, responses, themesByQ, decision, segQid) {
  const n = responses.length;
  const stats = computeStats(survey.questions, responses);
  let code = 0;
  for (const st of stats) {
    if (st.type !== "open_text") continue;
    if (st.texts.length && !themesByQ[st.id]) throw Object.assign(new Error(`Thiếu kết quả nhóm chủ đề cho câu ${st.id}.`), { status: 400 });
    const t = sanitizeThemes(st.texts.length ? themesByQ[st.id] : null);
    for (const th of t.themes) th.code = `C${++code}`;
    st.themes = t.themes;
    st.no_content = t.no_content;
    delete st.texts;
  }
  const segments = segQid ? computeSegments(survey.questions, responses, stats, segQid) : null;
  const purpose = survey.purpose || `${survey.title}. ${survey.description}`.trim();
  const hr = isHrTopic(survey.topic);

  const system = "Bạn là nhà phân tích khảo sát cẩn thận. Chỉ dựa vào dữ liệu được cung cấp, không bịa thêm. " +
    "Không tự tính lại hay làm tròn khác các con số đã cho. Viết tiếng Việt có dấu, súc tích.";
  const user = `Mục đích khảo sát: ${purpose}
Quyết định cần đưa ra từ kết quả: ${decision || "không nêu"}

KẾT QUẢ (đã tính chính xác):
${describeStats(stats, n, segments)}

Hãy viết:
- summary: 3-5 câu tóm tắt kết quả chung${decision ? ", hướng vào quyết định cần đưa ra" : ""}.
- highlights: 3-5 điểm nổi bật nhất. Đây là DỮ KIỆN: mỗi điểm kèm con số đã cho, chỉ nêu điều đạt ngưỡng nổi bật.
- issues: các vấn đề. "severity" (cao/trung_binh/thap) dựa trên mức ảnh hưởng (sức khỏe, an toàn, mức độ bức xúc), không chỉ dựa vào số người nhắc.
- positives: các điểm tích cực.
- notable: 0-3 ý kiến trái chiều, hoặc ít người nêu nhưng đáng chú ý. Để trống nếu không có.
- recommendations: 3-5 đề xuất cụ thể, mỗi đề xuất giải quyết một vấn đề. Đây là DIỄN GIẢI của bạn.
- limitations: 1-2 câu về hạn chế của dữ liệu (cỡ mẫu, cách hỏi...).
${hr ? `\nĐây là khảo sát NHÂN SỰ, mục tiêu cuối cùng là giữ chân nhân viên. Viết thêm:
- retention_risk: mức nguy cơ nghỉ việc chung (cao/trung_binh/thap) dựa trên các câu liên quan (ý định gắn bó, eNPS, mức hài lòng, căng thẳng, lý do muốn rời đi...). "reason": 1-2 câu giải thích kèm con số; nếu có nhóm (đủ ${MIN_GROUP} người) nguy cơ cao hơn hẳn thì nêu ra. Nếu khảo sát không có câu nào liên quan thì level = "khong_ro".
- quick_actions: 2-4 việc cụ thể làm được ngay trong 30 ngày tới, ưu tiên vấn đề nghiêm trọng nhất. Khác với recommendations (dài hạn).
` : ""}Mỗi mục trong highlights/issues/positives/notable/recommendations${hr ? "/quick_actions và retention_risk" : ""} có "evidence": danh sách mã làm bằng chứng — mã câu hỏi (vd. "q3") hoặc mã chủ đề (vd. "C1"). Không có bằng chứng thì không viết mục đó.
Nếu dữ liệu không đủ để kết luận điều gì, hãy nói rõ "không đủ dữ liệu".`;
  let summary = await llmJson(ctx, llm, system, user, hr ? HR_SUMMARY_SCHEMA : SUMMARY_SCHEMA, { temperature: 0.2 });
  const valid = [...stats.map(st => st.id), ...stats.flatMap(st => (st.themes || []).map(t => t.code))];
  summary = cleanSummary(summary, valid, hr);
  if (n < 5) summary.note = `Chỉ có ${n} câu trả lời, kết quả chỉ mang tính tham khảo.`;
  else if (n < 30) summary.note = `Mẫu nhỏ (${n} người): không nên khái quát cho toàn bộ đối tượng.`;
  return { at: Date.now() / 1000, provider: llm.provider, model: llm.model, n, threshold: notableThreshold(n),
    decision, hr, stats, segments, summary };
}
