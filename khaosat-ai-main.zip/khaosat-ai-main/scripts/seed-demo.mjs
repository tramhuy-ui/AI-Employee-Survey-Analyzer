// Du lieu DEMO de thu tinh nang phan tich AI (cong ty gia "Cong ty ABC", chu so huu: tai khoan Hr_account).
//   PASSWORD='...' node scripts/seed-demo.mjs seed > demo.sql   -> 40 tai khoan User1..User40 (dang nhap duoc, mat khau chung = PASSWORD),
//                                                                  1 khao sat eNPS da dang + ~34 cau tra loi, 4 hop thu + 40 thu gop y (12 tuan)
//   node scripts/seed-demo.mjs clean > clean.sql                 -> xoa sach du lieu demo
//   npx wrangler d1 execute khaosat-db --remote --file=demo.sql
// Chay "seed" lai nhieu lan cung duoc (tu xoa du lieu demo cu truoc). Noi dung viet san, khong ton token AI.
// Thu gop y de CHUA CHAM diem: bam "Phan tich bang AI" de AI cham tu dau.
import { hashPassword } from "../src/auth.js";
import { TEMPLATES } from "../src/templates.js";
import { searchNorm } from "../src/questions.js";

const MODE = process.argv[2];
const HR = "Hr_account";
const SURVEY_ID = "deadbeef01";
const BOX = { kt: "deadbe0b01", kd: "deadbe0b02", ns: "deadbe0b03", kto: "deadbe0b04" };
const BOX_NAME = { kt: "Phòng Kỹ thuật", kd: "Phòng Kinh doanh", ns: "Phòng Nhân sự", kto: "Phòng Kế toán" };
const USERS = Array.from({ length: 40 }, (_, i) => `User${i + 1}`);
const q = (v) => (v === null || v === undefined ? "NULL" : typeof v === "number" ? String(v) : `'${String(v).replace(/'/g, "''")}'`);
const hrId = `(SELECT id FROM users WHERE username = '${HR}')`;
const demoIds = `(SELECT id FROM users WHERE username IN (${USERS.map(q).join(",")}))`;

const CLEAN = [
  `DELETE FROM responses WHERE survey_id = '${SURVEY_ID}' OR user_id IN ${demoIds};`,
  `DELETE FROM analyses WHERE survey_id = '${SURVEY_ID}';`,
  `DELETE FROM analysis_runs WHERE survey_id = '${SURVEY_ID}' OR user_id IN ${demoIds};`,
  `DELETE FROM reports WHERE survey_id = '${SURVEY_ID}' OR user_id IN ${demoIds};`,
  `DELETE FROM surveys WHERE id = '${SURVEY_ID}';`,
  `DELETE FROM fb_letters WHERE box_id IN (${Object.values(BOX).map(q).join(",")}) OR user_id IN ${demoIds};`,
  `DELETE FROM fb_analyses WHERE owner_id = ${hrId};`,
  `DELETE FROM fb_boxes WHERE id IN (${Object.values(BOX).map(q).join(",")});`,
  `DELETE FROM sessions WHERE user_id IN ${demoIds};`,
  `DELETE FROM ai_usage WHERE user_id IN ${demoIds};`,
  `DELETE FROM users WHERE username IN (${USERS.map(q).join(",")});`,
];
if (MODE === "clean") { console.log(CLEAN.join("\n")); process.exit(0); }
if (MODE !== "seed") { console.error("Cách dùng: PASSWORD='...' node scripts/seed-demo.mjs seed | clean"); process.exit(1); }
const PASSWORD = process.env.PASSWORD || "";
if (PASSWORD.length < 8) { console.error("Cần biến môi trường PASSWORD (ít nhất 8 ký tự)."); process.exit(1); }

// So ngau nhien co dinh (chay lai ra cung du lieu)
let seed = 20261126;
const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
const pick = (a) => a[Math.floor(rnd() * a.length)];
const between = (lo, hi) => lo + Math.floor(rnd() * (hi - lo + 1));
const NOW = Math.floor(Date.now() / 1000), DAY = 86400;
const vnDay = (ts) => new Date((ts + 7 * 3600) * 1000).toISOString().slice(0, 10);

// ------------------------------------------------------------ nhan vien ----
const NAMES = ["Nguyễn Văn An", "Trần Thị Bình", "Lê Hoàng Minh", "Phạm Quốc Huy", "Hoàng Thị Lan", "Vũ Đức Thắng", "Đặng Minh Tuấn",
  "Bùi Thị Hà", "Đỗ Văn Khoa", "Ngô Thanh Tùng", "Dương Thị Mai", "Lý Quang Vinh", "Phan Thị Ngọc", "Trịnh Văn Long",
  "Mai Thị Hương", "Võ Minh Khang", "Đinh Thị Thu", "Hồ Văn Phúc", "Lâm Thị Yến", "Cao Đức Anh", "Tạ Thị Linh",
  "Lương Văn Hải", "Châu Thị Nhung", "Kiều Minh Đức", "Quách Thị Vân", "Trương Văn Nam", "Hà Thị Thảo", "Tô Minh Quân",
  "Đoàn Thị Hạnh", "La Văn Sơn", "Nghiêm Thị Trang", "Văn Đức Hiếu", "Thái Thị Kim", "Mạc Văn Toàn", "Âu Thị Diệu",
  "Ninh Văn Bảo", "Giang Thị Loan", "Lục Minh Trí", "Khổng Thị Huyền", "Doãn Văn Lộc"];
// User1-14: Ky thuat, 15-26: Kinh doanh, 27-32: Nhan su, 33-40: Ke toan
const deptOf = (i) => (i < 14 ? "kt" : i < 26 ? "kd" : i < 32 ? "ns" : "kto");
const users = USERS.map((u, i) => ({ username: u, name: NAMES[i], dept: deptOf(i), created: NOW - between(60, 120) * DAY }));

const out = [...CLEAN];
for (const u of users) {
  out.push(`INSERT INTO users (email, name, pass_hash, username, role, terms_at, created) VALUES (${q("@" + u.username)}, ${q(u.name)}, ` +
    `${q(await hashPassword(PASSWORD))}, ${q(u.username)}, NULL, ${u.created}, ${u.created});`);
}
out.push(`UPDATE users SET fb_title = 'Công ty ABC' WHERE username = '${HR}';`);

// ------------------------------------------------------------ khao sat ----
const T = TEMPLATES.enps;
const DEPT_OPT = { kt: "Kỹ thuật / Công nghệ", kd: "Kinh doanh / Bán hàng", ns: "Hành chính / Nhân sự / Kế toán", kto: "Hành chính / Nhân sự / Kế toán" };
const PROFILE = { // nps, 3 cau thang diem (tu hao, dong luc, o lai 1 nam)
  kt: { nps: [1, 2, 3, 4, 5, 5, 6, 6, 7, 8], sc: [[1, 2, 2, 3, 3, 4], [2, 2, 3, 3, 4], [1, 1, 2, 2, 3, 4]] },
  kd: { nps: [4, 5, 6, 7, 7, 8, 8, 9], sc: [[3, 3, 4, 4, 5], [2, 3, 3, 4], [2, 3, 3, 4, 4]] },
  ns: { nps: [8, 9, 9, 10, 10], sc: [[4, 4, 5, 5], [4, 5, 5], [4, 4, 5, 5]] },
  kto: { nps: [6, 7, 8, 8, 9, 9, 10], sc: [[3, 4, 4, 5], [3, 4, 4], [3, 4, 4, 5]] },
};
const REASON = {
  kt: ["Thường xuyên phải OT đến tối muộn mà không được tính lương làm thêm.", "Lương thấp hơn mặt bằng thị trường khoảng 20%, hai năm chưa được tăng.",
    "Trưởng nhóm hay la mắng trước mặt mọi người, không ai dám góp ý.", "Dự án gấp liên tục, deadline thay đổi mà không báo trước.",
    "Đồng nghiệp tốt, học được nhiều kỹ thuật mới.", "Máy tính cấu hình yếu, làm việc rất chậm.", "Lương thấp, OT nhiều, đang cân nhắc chuyển việc.",
    "Không thấy lộ trình thăng tiến rõ ràng cho kỹ sư."],
  kd: ["Thưởng doanh số tốt, chi trả đúng hạn.", "Chỉ tiêu doanh số tăng quá nhanh, áp lực rất lớn.", "Đồng nghiệp vui vẻ, hỗ trợ nhau khi chốt đơn.",
    "Chỉ tiêu tăng 50% mà không giải thích lý do.", "Được đi gặp khách hàng, học hỏi nhiều.", "Không có ý kiến"],
  ns: ["Môi trường thân thiện, quản lý lắng nghe.", "Công việc ổn định, giờ giấc linh hoạt.", "Được đào tạo bài bản khi mới vào.", "Không có ý kiến"],
  kto: ["Công việc ổn định, đồng nghiệp hòa đồng.", "Cuối tháng và cuối năm hơi quá tải.", "Quản lý tận tâm, hướng dẫn kỹ.", "Phần mềm kế toán cũ, hay lỗi."],
};
const CHANGE = {
  kt: ["Trả lương làm thêm giờ đầy đủ và giảm OT.", "Điều chỉnh lương theo mặt bằng thị trường.", "Đào tạo kỹ năng quản lý cho trưởng nhóm.",
    "Nâng cấp máy tính cho kỹ sư.", "Lên kế hoạch dự án rõ ràng, hạn chế việc gấp.", "Cho làm việc từ xa 1–2 ngày mỗi tuần."],
  kd: ["Đặt chỉ tiêu hợp lý hơn và giải thích cách tính.", "Thêm ngày nghỉ sau các đợt cao điểm bán hàng.", "Hỗ trợ chi phí đi lại gặp khách hàng.", "Không có ý kiến"],
  ns: ["Tổ chức thêm hoạt động gắn kết các phòng ban.", "Không có ý kiến", "Cập nhật quy trình nội bộ cho gọn hơn."],
  kto: ["Thay phần mềm kế toán mới.", "Tăng người hỗ trợ vào mùa quyết toán.", "Không có ý kiến"],
};
const TENURE = ["Dưới 6 tháng", "6 tháng – 1 năm", "1 – 3 năm", "1 – 3 năm", "3 – 5 năm", "Trên 5 năm"];
const LEVEL = ["Nhân viên", "Nhân viên", "Nhân viên", "Nhân viên", "Trưởng nhóm / Giám sát", "Quản lý cấp trung trở lên"];
const published = NOW - 21 * DAY;
out.push(`INSERT INTO surveys (id, owner_id, status, title, description, topic, visibility, anonymous, purpose, questions, search_text, root_id, created, updated, published_at)
  VALUES ('${SURVEY_ID}', ${hrId}, 'published', ${q(T.title + " – Quý 4/2026")}, ${q(T.description)}, ${q(T.topic)}, 'link', 1, ${q(T.description)},
  ${q(JSON.stringify(T.questions))}, ${q(searchNorm(T.title + " " + T.description))}, '${SURVEY_ID}', ${published - DAY}, ${published}, ${published});`);
let nResp = 0;
for (const u of users) {
  if (rnd() < 0.15) continue; // co nguoi khong tra loi
  const p = PROFILE[u.dept];
  const a = { q1: DEPT_OPT[u.dept], q2: pick(TENURE), q3: pick(LEVEL), q4: pick(p.nps), q5: pick(p.sc[0]), q6: pick(p.sc[1]), q7: pick(p.sc[2]) };
  if (rnd() < 0.9) a.q8 = pick(REASON[u.dept]);
  if (rnd() < 0.8) a.q9 = pick(CHANGE[u.dept]);
  const created = published + between(1, 18) * DAY + between(0, 50000);
  out.push(`INSERT INTO responses (survey_id, user_id, answers, created, duration) VALUES ('${SURVEY_ID}', (SELECT id FROM users WHERE username = '${u.username}'), ` +
    `${q(JSON.stringify(a))}, ${created}, ${between(90, 600)});`);
  nResp++;
}

// ------------------------------------------------------- hop thu gop y ----
const BOX_DESC = { kt: "Góp ý về công việc, quản lý, dự án của phòng Kỹ thuật.", kd: "Góp ý cho phòng Kinh doanh.", ns: "Góp ý cho phòng Nhân sự.", kto: "Góp ý cho phòng Kế toán." };
for (const [k, id] of Object.entries(BOX)) {
  out.push(`INSERT INTO fb_boxes (id, owner_id, name, description, status, created, updated) VALUES ('${id}', ${hrId}, ${q(BOX_NAME[k])}, ${q(BOX_DESC[k])}, 'open', ${NOW - 90 * DAY}, ${NOW - 90 * DAY});`);
}
// [phong, chu de nhan vien chon, noi dung, so tuan truoc]. Phong Ky thuat xau dan theo thoi gian.
const LETTERS = [
  ["kt", "dong_nghiep", "Team mình rất đoàn kết, mọi người sẵn sàng hỗ trợ nhau khi có lỗi gấp.", 11],
  ["kt", "phat_trien", "Mong công ty tổ chức thêm các buổi chia sẻ kỹ thuật nội bộ hàng tháng.", 10],
  ["kt", "moi_truong", "Máy tính cấu hình yếu, mỗi lần build code mất gần 15 phút.", 9],
  ["kt", "khac", "Đề xuất cho làm việc từ xa 1–2 ngày mỗi tuần để đỡ thời gian đi lại.", 8],
  ["kt", "luong_thuong", "Lương kỹ sư thấp hơn thị trường, hai năm rồi chưa được xét tăng lương.", 7],
  ["kt", "quan_ly", "Deadline dự án bị đổi liên tục mà không ai giải thích lý do.", 6],
  ["kt", "khac", "Tuần nào cũng phải ở lại đến 9–10 giờ tối nhưng không được tính lương làm thêm.", 5],
  ["kt", "quan_ly", "Trưởng nhóm hay la mắng nhân viên trước mặt cả phòng, rất mất tinh thần.", 4],
  ["kt", "luong_thuong", "Nhiều bạn trong team đang đi phỏng vấn chỗ khác vì lương và OT quá nhiều.", 3],
  ["kt", "khac", "Mệt mỏi vì làm thêm giờ triền miên, cuối tuần cũng phải trực hệ thống.", 2],
  ["kt", "quan_ly", "Góp ý bị bỏ qua, cảm giác không ai lắng nghe nhân viên kỹ thuật.", 2],
  ["kt", "moi_truong", "Phòng làm việc nóng, máy lạnh hỏng hơn hai tuần chưa sửa.", 1],
  ["kt", "luong_thuong", "Nếu quý sau vẫn không điều chỉnh lương thì em sẽ nghỉ việc.", 1],
  ["kt", "phat_trien", "Không có lộ trình thăng tiến rõ ràng cho kỹ sư, làm lâu cũng không lên được.", 0],
  ["kd", "luong_thuong", "Cảm ơn công ty đã chi thưởng quý đúng hạn, cả phòng rất vui.", 11],
  ["kd", "phat_trien", "Muốn có khóa đào tạo kỹ năng đàm phán và chăm sóc khách hàng.", 10],
  ["kd", "khac", "Phòng họp hay bị trùng lịch, nhiều lần phải gặp khách ở quán cà phê.", 9],
  ["kd", "quan_ly", "Chỉ tiêu doanh số quý này tăng 50% mà không giải thích cách tính.", 7],
  ["kd", "dong_nghiep", "Đồng nghiệp hỗ trợ nhau rất tốt trong các đợt chốt đơn cuối tháng.", 6],
  ["kd", "luong_thuong", "Đề xuất hỗ trợ chi phí xăng xe cho nhân viên phải đi gặp khách hàng nhiều.", 5],
  ["kd", "quan_ly", "Áp lực doanh số quá lớn, tuần nào cũng bị nhắc chỉ tiêu trong nhóm chat.", 4],
  ["kd", "moi_truong", "Cần thêm khu vực tiếp khách riêng tại văn phòng.", 3],
  ["kd", "khac", "Sau đợt cao điểm bán hàng nên có thêm ngày nghỉ bù cho nhân viên.", 2],
  ["kd", "dong_nghiep", "Không khí phòng vui vẻ, trưởng phòng hay động viên mọi người.", 1],
  ["kd", "quan_ly", "Mong quản lý họp ít lại, dành thời gian cho nhân viên đi gặp khách.", 1],
  ["kd", "luong_thuong", "Cách tính hoa hồng mới khó hiểu, mong được giải thích rõ hơn.", 0],
  ["ns", "dong_nghiep", "Cảm ơn mọi người đã hỗ trợ tổ chức tiệc cuối năm rất thành công.", 10],
  ["ns", "moi_truong", "Văn phòng sạch sẽ, thoáng mát, làm việc rất thoải mái.", 8],
  ["ns", "phat_trien", "Mong được tham gia khóa học về luật lao động mới.", 6],
  ["ns", "khac", "Quy trình duyệt nghỉ phép trên hệ thống còn nhiều bước, nên rút gọn.", 4],
  ["ns", "quan_ly", "Quản lý luôn lắng nghe và phản hồi nhanh các đề xuất.", 2],
  ["ns", "dong_nghiep", "Mọi người trong phòng rất thân thiện, hỗ trợ nhân viên mới tận tình.", 0],
  ["kto", "moi_truong", "Phần mềm kế toán cũ hay bị lỗi khi xuất báo cáo cuối tháng.", 11],
  ["kto", "khac", "Mùa quyết toán thuế quá tải, cần thêm người hỗ trợ tạm thời.", 9],
  ["kto", "dong_nghiep", "Đồng nghiệp hòa đồng, giúp đỡ nhau khi chốt sổ sách.", 8],
  ["kto", "quan_ly", "Kế toán trưởng hướng dẫn rất kỹ, cảm ơn chị nhiều.", 6],
  ["kto", "luong_thuong", "Phụ cấp ăn trưa nên được điều chỉnh theo giá cả hiện nay.", 5],
  ["kto", "phat_trien", "Mong công ty hỗ trợ học phí chứng chỉ kế toán chuyên nghiệp.", 3],
  ["kto", "moi_truong", "Cảm ơn công ty đã lắp thêm màn hình phụ, làm việc nhanh hơn nhiều.", 1],
  ["kto", "khac", "Đề xuất số hóa hóa đơn để giảm giấy tờ lưu trữ.", 0],
];
const REPLY = {
  moi_truong: "Cảm ơn bạn đã góp ý. Phòng Hành chính đã ghi nhận và sẽ xử lý trong tháng này.",
  luong_thuong: "Cảm ơn bạn. HR đã chuyển đề xuất lên Ban giám đốc trong đợt xét lương sắp tới.",
  phat_trien: "Cảm ơn bạn. HR đang lên kế hoạch đào tạo quý tới và sẽ thông báo sớm.",
  khac: "Cảm ơn bạn đã góp ý, HR đã ghi nhận.", quan_ly: "Cảm ơn bạn. HR sẽ trao đổi riêng với quản lý trực tiếp.",
  dong_nghiep: "Cảm ơn bạn đã chia sẻ điều tích cực!",
};
const sentPerDay = new Map();
for (const [dept, topic, content, weeks] of LETTERS) {
  const pool = users.filter(u => u.dept === dept);
  let created, author;
  for (let t = 0; t < 20; t++) {
    created = NOW - (weeks * 7 + between(0, 6)) * DAY - between(0, 30000);
    if (created > NOW - 3600) created = NOW - between(2, 10) * 3600;
    author = pick(pool);
    const k = author.username + vnDay(created);
    if ((sentPerDay.get(k) || 0) < 5) { sentPerDay.set(k, (sentPerDay.get(k) || 0) + 1); break; }
  }
  const old = weeks >= 4;
  const status = old ? pick(["done", "done", "doing"]) : pick(["new", "new", "doing"]);
  const reply = status === "done" && rnd() < 0.8 ? REPLY[topic] : null;
  out.push(`INSERT INTO fb_letters (box_id, user_id, topic, content, day, created, status, reply, replied_at) VALUES ('${BOX[dept]}', ` +
    `(SELECT id FROM users WHERE username = '${author.username}'), ${q(topic)}, ${q(content)}, ${q(vnDay(created))}, ${created}, ${q(status)}, ` +
    `${q(reply)}, ${reply ? created + 2 * DAY : "NULL"});`);
}
console.log(out.join("\n"));
console.error(`Đã sinh: ${users.length} tài khoản, 1 khảo sát + ${nResp} câu trả lời, ${Object.keys(BOX).length} hộp thư + ${LETTERS.length} thư góp ý.`);
