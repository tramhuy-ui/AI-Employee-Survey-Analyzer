// Kiem tra du lieu khao sat do nguoi dung gui len (khong tin du lieu tu trinh duyet).
import { HttpError } from "./http.js";

// Chu de nhan su (nen tang khao sat nhan vien). "khac" = khong thuoc nhom nhan su nao.
export const TOPICS = {
  tuyen_dung: "Tuyển dụng & hội nhập", gan_ket: "Gắn kết", dai_ngo: "Đãi ngộ & phát triển",
  quan_ly: "Quản lý & đội nhóm", suc_khoe: "Sức khỏe & cân bằng", nghi_viec: "Nguy cơ nghỉ việc", khac: "Khác",
};
export const isHrTopic = (t) => !!TOPICS[t] && t !== "khac";

export const QTYPES = ["single_choice", "multiple_choice", "dropdown", "scale", "rating", "nps", "open_text"];
export const CHOICE_TYPES = ["single_choice", "multiple_choice", "dropdown"];
export const NUMERIC_TYPES = ["scale", "rating", "nps"];
const LIMITS = { questions: 50, questionText: 500, options: 20, optionText: 200, title: 200, description: 2000 };

const str = (v, max) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, max);

// Bo dau tieng Viet + chu thuong -> tim "cang tin" ra "Căng tin"
export const searchNorm = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
  .replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().replace(/\s+/g, " ").trim();

export function validateQuestions(input) {
  if (!Array.isArray(input)) throw new HttpError(400, "Danh sách câu hỏi không hợp lệ.");
  if (input.length > LIMITS.questions) throw new HttpError(400, `Tối đa ${LIMITS.questions} câu hỏi.`);
  const ids = new Set();
  return input.map((q, i) => {
    const n = i + 1;
    const type = QTYPES.includes(q?.type) ? q.type : null;
    if (!type) throw new HttpError(400, `Câu ${n}: loại câu hỏi không hợp lệ.`);
    const question = str(q.question, LIMITS.questionText);
    let id = /^q[\w-]{1,20}$/.test(q.id || "") && !ids.has(q.id) ? q.id : null;
    if (!id) { let k = n; while (ids.has(`q${k}`)) k++; id = `q${k}`; }
    ids.add(id);
    const item = { id, question, type, required: !!q.required, options: [] };
    if (CHOICE_TYPES.includes(type)) {
      const opts = [];
      for (const o of Array.isArray(q.options) ? q.options : []) {
        const t = str(o, LIMITS.optionText);
        if (t && !opts.includes(t)) opts.push(t);
      }
      item.options = opts.slice(0, LIMITS.options);
    }
    if (type === "scale") {
      const s = Array.isArray(q.scale) ? q.scale : [];
      item.scale = [str(s[0], 60) || "Rất thấp", str(s[1], 60) || "Rất cao"];
    }
    return item;
  });
}

// Kiem tra chat hon khi dang khao sat
export function assertPublishable(s) {
  if (!s.title.trim()) throw new HttpError(400, "Khảo sát cần có tiêu đề trước khi đăng.");
  if (!s.questions.length) throw new HttpError(400, "Khảo sát cần ít nhất 1 câu hỏi.");
  s.questions.forEach((q, i) => {
    if (!q.question) throw new HttpError(400, `Câu ${i + 1} chưa có nội dung.`);
    if (CHOICE_TYPES.includes(q.type) && q.options.length < 2) throw new HttpError(400, `Câu ${i + 1} cần ít nhất 2 đáp án.`);
  });
}

export function validateMeta(b) {
  const out = {};
  if ("title" in b) out.title = str(b.title, LIMITS.title);
  if ("description" in b) out.description = String(b.description ?? "").trim().slice(0, LIMITS.description);
  if ("topic" in b) out.topic = TOPICS[b.topic] ? b.topic : "khac";
  if ("visibility" in b) out.visibility = b.visibility === "link" ? "link" : "public";
  if ("anonymous" in b) out.anonymous = b.anonymous ? 1 : 0;
  if ("purpose" in b) out.purpose = str(b.purpose, 1000);
  if ("decision" in b) out.decision = str(b.decision, 500);
  if ("questions" in b) out.questions = validateQuestions(b.questions);
  return out;
}

// Cau tra loi: loc theo cau hoi, kiem tra cau bat buoc
export function cleanAnswers(questions, raw) {
  const answers = {}, missing = [];
  questions.forEach((q, i) => {
    const v = raw?.[q.id];
    if (q.type === "single_choice" || q.type === "dropdown") {
      if (q.options.includes(v)) answers[q.id] = v;
    } else if (q.type === "multiple_choice") {
      if (Array.isArray(v)) {
        const picked = q.options.filter(o => v.includes(o));
        if (picked.length) answers[q.id] = picked;
      }
    } else if (q.type === "scale" || q.type === "rating") {
      const n = Number(v);
      if (Number.isInteger(n) && n >= 1 && n <= 5) answers[q.id] = n;
    } else if (q.type === "nps") {
      const n = Number(v);
      if (Number.isInteger(n) && n >= 0 && n <= 10 && v !== "" && v !== null) answers[q.id] = n;
    } else {
      const t = String(v ?? "").trim();
      if (t) answers[q.id] = t.slice(0, 2000);
    }
    if (q.required && !(q.id in answers)) missing.push(i + 1);
  });
  if (missing.length) throw new HttpError(400, `Vui lòng trả lời các câu bắt buộc: ${missing.join(", ")}.`);
  if (!Object.keys(answers).length) throw new HttpError(400, "Bạn chưa trả lời câu nào.");
  return answers;
}
