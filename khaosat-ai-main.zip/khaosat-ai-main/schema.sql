-- Cau truc CSDL (app tu tao bang khi chay lan dau, sinh tu src/db.js). File nay de tham khao / tao thu cong:
--   npx wrangler d1 execute khaosat-db --remote --file=schema.sql
CREATE TABLE IF NOT EXISTS users (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     email TEXT NOT NULL UNIQUE,
     name TEXT NOT NULL,
     pass_hash TEXT NOT NULL,
     locked INTEGER NOT NULL DEFAULT 0,
     quota_gen INTEGER,              -- NULL = dung mac dinh
     quota_ana INTEGER,
     created INTEGER NOT NULL, avatar TEXT, google_sub TEXT, terms_at INTEGER, fb_hub TEXT, fb_title TEXT, username TEXT, role TEXT);

CREATE TABLE IF NOT EXISTS sessions (
     token_hash TEXT PRIMARY KEY,    -- chi luu hash cua token, khong luu token goc
     user_id INTEGER NOT NULL,
     expires INTEGER NOT NULL, via TEXT);

CREATE TABLE IF NOT EXISTS surveys (
     id TEXT PRIMARY KEY,
     owner_id INTEGER NOT NULL,
     status TEXT NOT NULL DEFAULT 'draft',      -- draft | published | closed
     title TEXT NOT NULL DEFAULT '',
     description TEXT NOT NULL DEFAULT '',
     topic TEXT NOT NULL DEFAULT 'khac',
     visibility TEXT NOT NULL DEFAULT 'public', -- public | link
     anonymous INTEGER NOT NULL DEFAULT 0,
     purpose TEXT NOT NULL DEFAULT '',
     decision TEXT NOT NULL DEFAULT '',
     questions TEXT NOT NULL DEFAULT '[]',
     search_text TEXT NOT NULL DEFAULT '',      -- tieu de + mo ta da bo dau, de tim kiem
     root_id TEXT NOT NULL,                     -- nhom cac phien ban cua cung mot khao sat
     parent_id TEXT,                            -- phien ban truoc
     successor_id TEXT,                         -- phien ban moi (khi da dang)
     hidden INTEGER NOT NULL DEFAULT 0,         -- admin an khoi trang tim kiem
     created INTEGER NOT NULL,
     updated INTEGER NOT NULL,
     published_at INTEGER,
     closed_at INTEGER, closes_at INTEGER);

CREATE TABLE IF NOT EXISTS responses (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     survey_id TEXT NOT NULL,
     user_id INTEGER NOT NULL,
     answers TEXT NOT NULL,
     created INTEGER NOT NULL, duration INTEGER,
     UNIQUE (survey_id, user_id));

CREATE TABLE IF NOT EXISTS analyses (survey_id TEXT PRIMARY KEY, data TEXT NOT NULL, created INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS analysis_runs (
     id TEXT PRIMARY KEY, survey_id TEXT NOT NULL, user_id INTEGER NOT NULL,
     steps INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS reports (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     survey_id TEXT NOT NULL,
     user_id INTEGER NOT NULL,
     reason TEXT NOT NULL,
     resolved INTEGER NOT NULL DEFAULT 0,
     created INTEGER NOT NULL,
     UNIQUE (survey_id, user_id));

CREATE TABLE IF NOT EXISTS ai_usage (
     user_id INTEGER NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL,
     count INTEGER NOT NULL DEFAULT 0, tokens INTEGER NOT NULL DEFAULT 0,
     PRIMARY KEY (user_id, day, kind));

CREATE TABLE IF NOT EXISTS hits (key TEXT NOT NULL, ts INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS fb_boxes (
     id TEXT PRIMARY KEY,
     owner_id INTEGER NOT NULL,
     name TEXT NOT NULL,
     description TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'open',       -- open | closed
     created INTEGER NOT NULL,
     updated INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS fb_letters (
     id INTEGER PRIMARY KEY AUTOINCREMENT,
     box_id TEXT NOT NULL,
     user_id INTEGER NOT NULL,                  -- chi dung cho gioi han gui + "Thu toi da gui"; KHONG bao gio tra ve cho HR
     topic TEXT NOT NULL DEFAULT 'khac',        -- nhan vien chon
     ai_topic TEXT,                             -- AI gan khi nhan vien chon "Khac"
     content TEXT NOT NULL,
     day TEXT NOT NULL,                         -- ngay gui (gio VN) - HR chi thay ngay, khong thay gio
     created INTEGER NOT NULL,
     status TEXT NOT NULL DEFAULT 'new',        -- new | doing | done
     reply TEXT,
     replied_at INTEGER,
     hidden INTEGER NOT NULL DEFAULT 0,
     sat INTEGER,                               -- muc hai long 1..5 (AI cham, HR sua duoc)
     sat_by TEXT);

CREATE TABLE IF NOT EXISTS fb_analyses (
     owner_id INTEGER NOT NULL, scope TEXT NOT NULL, period TEXT NOT NULL,
     data TEXT NOT NULL, created INTEGER NOT NULL,
     PRIMARY KEY (owner_id, scope, period));

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions (user_id);

CREATE INDEX IF NOT EXISTS idx_surveys_owner ON surveys (owner_id);

CREATE INDEX IF NOT EXISTS idx_surveys_public ON surveys (status, visibility, hidden);

CREATE INDEX IF NOT EXISTS idx_surveys_root ON surveys (root_id);

CREATE INDEX IF NOT EXISTS idx_responses_user ON responses (user_id);

CREATE INDEX IF NOT EXISTS idx_hits ON hits (key, ts);

CREATE INDEX IF NOT EXISTS idx_fb_boxes_owner ON fb_boxes (owner_id);

CREATE INDEX IF NOT EXISTS idx_fb_letters_box ON fb_letters (box_id, id);

CREATE INDEX IF NOT EXISTS idx_fb_letters_user ON fb_letters (user_id, day);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_google ON users (google_sub) WHERE google_sub IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users (username) WHERE username IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_fbhub ON users (fb_hub) WHERE fb_hub IS NOT NULL;
