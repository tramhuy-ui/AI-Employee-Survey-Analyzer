// Tien ich HTTP dung chung.
export class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

export const now = () => Math.floor(Date.now() / 1000);
const enc = new TextEncoder();
const MAX_BODY = 256 * 1024;

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers },
  });
}

// Chi nhan JSON: form gui cheo trang khong gui duoc JSON -> chong CSRF
export async function readJson(request) {
  if (!(request.headers.get("content-type") || "").includes("application/json")) throw new HttpError(415, "Yêu cầu phải là JSON.");
  const text = await request.text();
  if (text.length > MAX_BODY) throw new HttpError(413, "Dữ liệu quá lớn.");
  try { return text ? JSON.parse(text) : {}; } catch { throw new HttpError(400, "JSON không hợp lệ."); }
}

export function cookies(request) {
  const out = {};
  for (const part of (request.headers.get("cookie") || "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
export const b64urlDecode = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), c => c.charCodeAt(0));

export const sha256 = async (text) => b64url(await crypto.subtle.digest("SHA-256", enc.encode(text)));
export const randomToken = (bytes = 32) => b64url(crypto.getRandomValues(new Uint8Array(bytes)));
export const randomHex = (bytes) => [...crypto.getRandomValues(new Uint8Array(bytes))].map(b => b.toString(16).padStart(2, "0")).join("");

export function clientIp(request) {
  return request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
}

export const isHttps = (request) => new URL(request.url).protocol === "https:";

export function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

// Ngay theo gio Viet Nam (UTC+7), dung cho han muc AI moi ngay
export const vnDay = () => new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
