// Dang nhap bang Google (OAuth 2.0, luong "authorization code" + PKCE, xu ly hoan toan o server).
// Can: GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET. Redirect URI: <origin>/api/auth/google/callback
import { HttpError, now, cookies, b64url, b64urlDecode, randomToken, isHttps } from "./http.js";

const AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const COOKIE = "ks_oauth";
const enc = new TextEncoder();

export const googleEnabled = (env) => !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET);
const redirectUri = (request) => `${new URL(request.url).origin}/api/auth/google/callback`;
const tempCookie = (request, value, maxAge) =>
  `${COOKIE}=${value}; Path=/api/auth/google; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isHttps(request) ? "; Secure" : ""}`;

export const redirect = (location, headers = {}) => new Response(null, { status: 302, headers: { Location: location, "Cache-Control": "no-store", ...headers } });

// Buoc 1: chuyen nguoi dung sang trang chon tai khoan Google
export async function googleStart(request, env, next) {
  if (!googleEnabled(env)) throw new HttpError(404, "Chưa bật đăng nhập Google.");
  const state = randomToken(16), verifier = randomToken(32);
  const challenge = b64url(await crypto.subtle.digest("SHA-256", enc.encode(verifier)));
  const params = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID, redirect_uri: redirectUri(request), response_type: "code",
    scope: "openid email profile", state, code_challenge: challenge, code_challenge_method: "S256", prompt: "select_account",
  });
  // state + verifier + trang can quay lai: luu trong cookie tam (10 phut), chi gui ve duong dan callback
  const value = [state, verifier, b64url(enc.encode(next))].join(".");
  return redirect(`${AUTH_URL}?${params}`, { "Set-Cookie": tempCookie(request, value, 600) });
}

// Buoc 2: Google tra ve "code" -> doi lay id_token, kiem tra, tra ve thong tin tai khoan Google
export async function googleCallback(request, env) {
  const url = new URL(request.url);
  const [state, verifier, nextB64] = String(cookies(request)[COOKIE] || "").split(".");
  const clear = tempCookie(request, "", 0);
  const fail = (code) => Object.assign(new Error(code), { oauth: code, clear });
  let next = "/dashboard";
  try { next = new TextDecoder().decode(b64urlDecode(nextB64 || "")) || next; } catch { /* mac dinh */ }
  if (url.searchParams.get("error")) throw fail("cancelled"); // nguoi dung bam Huy
  if (!state || !verifier || url.searchParams.get("state") !== state) throw fail("state");
  const code = url.searchParams.get("code");
  if (!code) throw fail("state");

  const res = await fetch(TOKEN_URL, {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ code, client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET,
      redirect_uri: redirectUri(request), grant_type: "authorization_code", code_verifier: verifier }),
  });
  const tok = await res.json().catch(() => ({}));
  if (!res.ok || !tok.id_token) { console.error("google token", res.status, tok.error); throw fail("token"); }

  // id_token nhan TRUC TIEP tu Google qua HTTPS (kem client_secret) nen khong can kiem chu ky,
  // nhung van kiem tra nguoi nhan (aud), noi phat hanh (iss), han dung va email da xac minh.
  let p;
  try { p = JSON.parse(new TextDecoder().decode(b64urlDecode(tok.id_token.split(".")[1]))); } catch { throw fail("token"); }
  if (p.aud !== env.GOOGLE_CLIENT_ID || !["accounts.google.com", "https://accounts.google.com"].includes(p.iss) || !(p.exp > now())) throw fail("token");
  if (!p.sub || !p.email || p.email_verified !== true) throw fail("unverified");
  return { profile: { sub: String(p.sub), email: String(p.email).toLowerCase(), name: String(p.name || p.email.split("@")[0]).slice(0, 80),
    picture: /^https:\/\//.test(p.picture || "") ? String(p.picture).slice(0, 500) : null }, next, clear };
}
