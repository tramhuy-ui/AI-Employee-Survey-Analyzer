-- XOA TOAN BO DU LIEU (dung khi doi cau truc CSDL). Chay: npx wrangler d1 execute khaosat-db --remote --file=reset.sql
DROP TABLE IF EXISTS analysis_runs;
DROP TABLE IF EXISTS ai_usage;
DROP TABLE IF EXISTS reports;
DROP TABLE IF EXISTS analyses;
DROP TABLE IF EXISTS responses;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS surveys;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS hits;
DROP TABLE IF EXISTS kv;
DROP TABLE IF EXISTS fb_analyses;
DROP TABLE IF EXISTS fb_letters;
DROP TABLE IF EXISTS fb_boxes;
