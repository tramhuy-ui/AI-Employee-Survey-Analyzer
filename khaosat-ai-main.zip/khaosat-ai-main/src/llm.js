// Goi LLM (Groq / Gemini) voi structured output + dieu tiet theo gioi han toc do.
// Trang thai gioi han luu trong D1 (bang kv) vi moi request co the chay o isolate khac nhau.

export const PROVIDERS = { groq: "Groq", gemini: "Gemini" };
const UA = "survey-app/1.0"; // Cloudflare (truoc Groq) chan UA mac dinh cua mot so thu vien (loi 1010)

export class LLMError extends Error {}

export class RateLimited extends LLMError {
  constructor(name, detail, wait) {
    const daily = /per day|\(RPD\)|\(TPD\)|daily/i.test(detail);
    super(daily
      ? `${name}: đã hết hạn mức trong ngày của model này. Hãy chọn model khác (mỗi model có hạn mức riêng) hoặc thử lại sau ${fmtSeconds(wait)}. Chi tiết: ${detail.slice(0, 200)}`
      : `${name}: vượt giới hạn tốc độ. Chi tiết: ${detail.slice(0, 200)}`);
    this.wait = wait;
    this.daily = daily;
  }
}

// Bao cho trinh duyet: "hay cho `wait` giay roi goi lai buoc nay"
export class WaitSignal extends Error {
  constructor(wait, label) {
    super("wait");
    this.wait = wait;
    this.label = label;
  }
}

export function config(env) {
  return {
    defaultProvider: PROVIDERS[env.LLM_PROVIDER] ? env.LLM_PROVIDER : "groq",
    groqUrl: (env.GROQ_URL || "https://api.groq.com/openai/v1").replace(/\/$/, ""),
    geminiUrl: "https://generativelanguage.googleapis.com/v1beta",
    models: { groq: env.GROQ_MODEL || "openai/gpt-oss-120b", gemini: env.GEMINI_MODEL || "gemini-flash-latest" },
    keys: { groq: env.GROQ_API_KEY || "", gemini: env.GEMINI_API_KEY || "" },
  };
}

function fmtSeconds(s) {
  s = Math.round(s || 0);
  return s >= 3600 ? `${Math.floor(s / 3600)} giờ ${Math.floor((s % 3600) / 60)} phút` : `${Math.floor(s / 60)} phút ${s % 60} giây`;
}

// '1m26.4s' / '659ms' / '7.5s' -> so giay, hoac null
export function parseDuration(text) {
  let found = false, total = 0;
  for (const m of String(text || "").matchAll(/(\d+(?:\.\d+)?)(ms|h|m|s)/g)) {
    found = true;
    total += parseFloat(m[1]) * { ms: 0.001, s: 1, m: 60, h: 3600 }[m[2]];
  }
  return found ? total : null;
}

function retryAfter(headers, detail) {
  const h = headers?.get("retry-after");
  if (h && !isNaN(parseFloat(h))) return parseFloat(h);
  const m = /try again in ([\dhms.]+)/i.exec(detail || "") || /retry in ([\dhms.]+)/i.exec(detail || "");
  const d = m ? parseDuration(m[1]) : null;
  return d ?? 20;
}

async function httpJson(url, { body, headers = {}, name, timeoutMs = 120000 } = {}) {
  let res;
  try {
    res = await fetch(url, {
      method: body !== undefined ? "POST" : "GET",
      headers: { "Content-Type": "application/json", "User-Agent": UA, ...headers },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (e) {
    throw new LLMError(`Không kết nối được ${name} (${e.message}).`);
  }
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { /* xu ly ben duoi */ }
  if (!res.ok) {
    const detail = String(data?.error?.message || text).slice(0, 400);
    if (res.status === 429) throw new RateLimited(name, detail, retryAfter(res.headers, detail));
    throw new LLMError(`${name} lỗi ${res.status}: ${detail.slice(0, 300)}`);
  }
  if (data === null) throw new LLMError(`${name} trả về dữ liệu không hợp lệ.`);
  return { data, headers: res.headers };
}

// Structured Outputs che do strict cua Groq can additionalProperties=false o moi object
export function strictSchema(schema) {
  if (Array.isArray(schema)) return schema.map(strictSchema);
  if (schema && typeof schema === "object") {
    const out = Object.fromEntries(Object.entries(schema).map(([k, v]) => [k, strictSchema(v)]));
    if (out.type === "object" && out.properties && typeof out.properties === "object") out.additionalProperties = false;
    return out;
  }
  return schema;
}

// Gemini responseSchema dung kieu viet hoa (STRING, OBJECT, ...)
export function toGeminiSchema(schema) {
  if (Array.isArray(schema)) return schema.map(toGeminiSchema);
  if (schema && typeof schema === "object") {
    return Object.fromEntries(Object.entries(schema).map(([k, v]) =>
      [k, k === "type" && typeof v === "string" ? v.toUpperCase() : toGeminiSchema(v)]));
  }
  return schema;
}

async function groqCall(cfg, model, system, user, schema, temperature, effort) {
  if (!cfg.keys.groq) throw new LLMError("Chưa có GROQ_API_KEY. Hãy thêm secret GROQ_API_KEY cho dự án Cloudflare Pages.");
  const body = {
    model, temperature,
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
    response_format: { type: "json_schema", json_schema: { name: "result", strict: true, schema: strictSchema(schema) } },
  };
  if (effort && model.startsWith("openai/gpt-oss")) body.reasoning_effort = effort; // giam token "suy nghi"
  const headers = { Authorization: `Bearer ${cfg.keys.groq}` };
  let r;
  try {
    r = await httpJson(cfg.groqUrl + "/chat/completions", { body, headers, name: "Groq" });
  } catch (e) {
    // Model khong ho tro json_schema -> dung JSON mode va dua schema vao prompt
    if (e instanceof RateLimited || !String(e.message).includes("lỗi 400")) throw e;
    delete body.reasoning_effort;
    body.response_format = { type: "json_object" };
    body.messages[1].content = user + "\n\nChỉ trả về một đối tượng JSON đúng theo JSON schema sau:\n" + JSON.stringify(schema);
    r = await httpJson(cfg.groqUrl + "/chat/completions", { body, headers, name: "Groq" });
  }
  const choice = r.data.choices?.[0];
  if (!choice) throw new LLMError(`Groq không trả kết quả: ${JSON.stringify(r.data).slice(0, 300)}`);
  return { content: choice.message?.content || "", tokens: r.data.usage?.total_tokens || 0, headers: r.headers };
}

async function geminiCall(cfg, model, system, user, schema, temperature) {
  if (!cfg.keys.gemini) throw new LLMError("Chưa có GEMINI_API_KEY. Hãy thêm secret GEMINI_API_KEY cho dự án Cloudflare Pages.");
  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ role: "user", parts: [{ text: user }] }],
    generationConfig: { temperature, responseMimeType: "application/json", responseSchema: toGeminiSchema(schema) },
  };
  const url = `${cfg.geminiUrl}/models/${encodeURIComponent(model)}:generateContent`;
  const r = await httpJson(url, { body, headers: { "x-goog-api-key": cfg.keys.gemini }, name: "Gemini" });
  const cand = r.data.candidates?.[0];
  if (!cand) throw new LLMError(`Gemini không trả kết quả (có thể bị chặn bởi bộ lọc): ${JSON.stringify(r.data.promptFeedback || "")}`);
  const text = (cand.content?.parts || []).filter(p => !p.thought).map(p => p.text || "").join("");
  if (!text) throw new LLMError(`Gemini trả về rỗng (finishReason: ${cand.finishReason})`);
  return { content: text, tokens: r.data.usageMetadata?.totalTokenCount || 0, headers: null };
}

const CALLS = { groq: groqCall, gemini: geminiCall };

// ---------------------------------------------------------- dieu tiet ----
async function getRate(db, key) {
  const row = await db.prepare("SELECT value FROM kv WHERE key = ?").bind(key).first();
  return row ? JSON.parse(row.value) : null;
}

async function setRate(db, key, value) {
  await db.prepare("INSERT INTO kv (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
    .bind(key, JSON.stringify(value)).run();
}

function rateFromHeaders(headers) {
  const rem = headers?.get("x-ratelimit-remaining-tokens");
  if (!rem || !/^\d+$/.test(rem)) return null;
  const now = Date.now() / 1000;
  const limit = headers.get("x-ratelimit-limit-tokens");
  return {
    remaining: parseInt(rem, 10), at: now,
    reset_at: now + (parseDuration(headers.get("x-ratelimit-reset-tokens")) || 0),
    limit: limit && /^\d+$/.test(limit) ? parseInt(limit, 10) : null,
  };
}

// So giay can cho de han muc token (hoi dan theo thoi gian) du cho request sap gui
export function neededWait(st, need, now = Date.now() / 1000) {
  if (!st) return 0;
  const fullWait = st.reset_at - now;
  if (fullWait <= 0) return 0;
  const rate = st.limit ? st.limit / 60 : null; // token hoi lai moi giay
  const have = st.remaining + (rate ? rate * (now - st.at) : 0);
  if (have >= need) return 0;
  return (rate ? Math.min(fullWait, (need - have) / rate) : fullWait) + 1;
}

// ctx = { db, cfg, usage: {tokens, calls} }
export async function llmJson(ctx, llm, system, user, schema, { temperature = 0.3, effort } = {}) {
  const label = PROVIDERS[llm.provider];
  const key = `rate:${llm.provider}:${llm.model}`;
  const need = Math.round((system.length + user.length) / 2.5) + 1500; // uoc luong token cua request
  const st = await getRate(ctx.db, key);
  const wait = neededWait(st, need);
  if (wait > 0) throw new WaitSignal(wait, label);

  for (let attempt = 1; ; attempt++) {
    let r;
    try {
      r = await CALLS[llm.provider](ctx.cfg, llm.model, system, user, schema, temperature, effort);
    } catch (e) {
      if (e instanceof RateLimited && !e.daily) {
        const now = Date.now() / 1000;
        await setRate(ctx.db, key, { remaining: 0, at: now, reset_at: now + e.wait, limit: st?.limit ?? null });
        throw new WaitSignal(e.wait + 1, label);
      }
      throw e;
    }
    const rate = rateFromHeaders(r.headers);
    if (rate) await setRate(ctx.db, key, rate);
    ctx.usage.tokens += r.tokens;
    ctx.usage.calls += 1;
    try {
      return JSON.parse(r.content);
    } catch (e) {
      if (attempt >= 2) throw new LLMError(`Model trả về JSON không hợp lệ, hãy thử lại: ${e.message}`);
    }
  }
}

const GROQ_SKIP = ["whisper", "tts", "guard", "orpheus", "playai", "distil", "compound"];
const GEMINI_SKIP = ["tts", "image", "embedding", "live", "audio", "robotics", "computer-use", "native"];

export async function listModels(cfg, provider) {
  try {
    if (provider === "groq") {
      if (!cfg.keys.groq) return { ok: false, models: [], error: "Chưa có GROQ_API_KEY" };
      const r = await httpJson(cfg.groqUrl + "/models", { headers: { Authorization: `Bearer ${cfg.keys.groq}` }, name: "Groq", timeoutMs: 10000 });
      const models = (r.data.data || []).filter(m => m.active !== false && !GROQ_SKIP.some(x => m.id.toLowerCase().includes(x)))
        .map(m => m.id).sort();
      return { ok: true, models, error: null };
    }
    if (!cfg.keys.gemini) return { ok: false, models: [], error: "Chưa có GEMINI_API_KEY" };
    const r = await httpJson(`${cfg.geminiUrl}/models?pageSize=1000`, { headers: { "x-goog-api-key": cfg.keys.gemini }, name: "Gemini", timeoutMs: 10000 });
    const models = (r.data.models || []).filter(m => (m.supportedGenerationMethods || []).includes("generateContent")
      && m.name.startsWith("models/gemini") && !GEMINI_SKIP.some(x => m.name.includes(x)))
      .map(m => m.name.replace(/^models\//, "")).sort();
    return { ok: true, models, error: null };
  } catch (e) {
    return { ok: false, models: [], error: e.message };
  }
}

export function pickLlm(cfg, body, fallback = {}) {
  const provider = body.provider || fallback.provider || cfg.defaultProvider;
  if (!PROVIDERS[provider]) throw Object.assign(new Error(`Nhà cung cấp không hợp lệ: ${provider}`), { status: 400 });
  const model = String(body.model || (fallback.provider === provider ? fallback.model : "") || cfg.models[provider])
    .trim().replace(/^models\//, "");
  if (!/^[\w.:\-/]{1,100}$/.test(model)) throw Object.assign(new Error("Tên model không hợp lệ"), { status: 400 });
  return { provider, model };
}
