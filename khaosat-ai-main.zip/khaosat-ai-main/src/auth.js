// Dang ky, dang nhap, phien dang nhap, gioi han so lan thu.
import { HttpError, now, cookies, b64url, b64urlDecode, sha256, randomToken, isHttps, safeEqual, clientIp } from "./http.js";

export const SESSION_COOKIE = "ks_sess";
const SESSION_DAYS = 7;
// 10.000 vong ~6 ms CPU: vua gioi han 10 ms CPU/request cua goi free Cloudflare.
// So vong duoc luu trong chuoi hash nen co the tang ve sau ma khong hong tai khoan cu.
const PBKDF2_ITERATIONS = 10000;
const enc = new TextEncoder();

async function pbkdf2(password, salt, iterations) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  return b64url(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, 256));
}

export async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `pbkdf2$${PBKDF2_ITERATIONS}$${b64url(salt)}$${await pbkdf2(password, salt, PBKDF2_ITERATIONS)}`;
}

export async function verifyPassword(password, stored) {
  const [alg, it, salt, hash] = String(stored).split("$");
  if (alg !== "pbkdf2") return false;
  return safeEqual(await pbkdf2(password, b64urlDecode(salt), parseInt(it, 10)), hash);
}

// Hash gia de thoi gian phan hoi giong nhau khi email khong ton tai (chong do email)
export const DUMMY_HASH = "pbkdf2$10000$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

export const normEmail = (e) => String(e || "").trim().toLowerCase();
// Ten dang nhap (tai khoan do admin tao, vd. Admin_account): PHAN BIET hoa thuong. Tai khoan nay khong co email that,
// cot email luu "@<ten dang nhap>" (khong bao gio trung voi email that vi khong dung dinh dang email).
export const USERNAME_RE = /^[A-Za-z0-9_.-]{3,32}$/;
export const usernameEmail = (username) => `@${username}`;
export const ROLES = ["admin", "hr"]; // NULL = nguoi dung thuong

// via: "password" | "google". Quyen admin chi co khi dang nhap bang Google (Google da xac minh chu email).
export async function createSession(db, userId, via = "password") {
  const token = randomToken();
  await db.batch([
    db.prepare("INSERT INTO sessions (token_hash, user_id, expires, via) VALUES (?, ?, ?, ?)").bind(await sha256(token), userId, now() + SESSION_DAYS * 86400, via),
    db.prepare("DELETE FROM sessions WHERE expires < ?").bind(now()),
  ]);
  return token;
}

export function sessionCookie(request, token, maxAge = SESSION_DAYS * 86400) {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isHttps(request) ? "; Secure" : ""}`;
}

// Nguoi dung dang dang nhap (hoac null). Quyen theo vai tro luu trong CSDL: admin | hr | NULL.
export async function currentUser(request, env) {
  const token = cookies(request)[SESSION_COOKIE];
  if (!token || token.length > 100) return null;
  const row = await env.DB.prepare(
    `SELECT u.id, u.email, u.name, u.avatar, u.locked, u.quota_gen, u.quota_ana, u.terms_at, u.role, u.username, u.pass_hash, s.via FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires > ?`).bind(await sha256(token), now()).first();
  if (!row || row.locked) return null;
  return { id: row.id, email: row.email, name: row.name, avatar: row.avatar, quota_gen: row.quota_gen, quota_ana: row.quota_ana,
    terms_at: row.terms_at, via: row.via || "password", role: row.role || null, username: row.username || null, has_password: !!row.pass_hash,
    is_admin: row.role === "admin", is_hr: row.role === "admin" || row.role === "hr", token };
}

export async function requireUser(request, env) {
  const u = await currentUser(request, env);
  if (!u) throw new HttpError(401, "Bạn cần đăng nhập.");
  return u;
}

export async function requireAdmin(request, env) {
  const u = await requireUser(request, env);
  if (!u.is_admin) throw new HttpError(403, "Chỉ quản trị viên mới được truy cập.");
  return u;
}

// ------------------------------------------------------- gioi han so lan ----
export const ipKey = async (env, request) => sha256(`${env.APP_SECRET || "khaosat"}|${clientIp(request)}`);

export async function countHits(db, key, window) {
  const row = await db.prepare("SELECT COUNT(*) AS n FROM hits WHERE key = ? AND ts > ?").bind(key, now() - window).first();
  return row?.n || 0;
}

export async function addHit(db, key) {
  await db.batch([
    db.prepare("INSERT INTO hits (key, ts) VALUES (?, ?)").bind(key, now()),
    db.prepare("DELETE FROM hits WHERE ts < ?").bind(now() - 86400),
  ]);
}

export async function limit(db, key, max, window, message) {
  if (await countHits(db, key, window) >= max) throw new HttpError(429, message);
}
